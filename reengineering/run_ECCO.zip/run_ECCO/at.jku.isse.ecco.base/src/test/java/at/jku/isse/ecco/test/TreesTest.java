package at.jku.isse.ecco.test;

public class TreesTest {

	// TODO

}
