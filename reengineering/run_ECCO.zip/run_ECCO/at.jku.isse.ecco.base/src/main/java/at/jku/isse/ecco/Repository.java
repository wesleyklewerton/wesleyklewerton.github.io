package at.jku.isse.ecco;

public class Repository extends EccoService {

}
