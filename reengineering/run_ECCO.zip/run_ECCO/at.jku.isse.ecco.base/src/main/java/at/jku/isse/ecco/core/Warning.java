package at.jku.isse.ecco.core;

public interface Warning {

}
