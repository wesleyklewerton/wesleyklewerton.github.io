package at.jku.isse.ecco.plugin.artifact;

import java.io.Serializable;

public interface ArtifactData extends Serializable {

}
