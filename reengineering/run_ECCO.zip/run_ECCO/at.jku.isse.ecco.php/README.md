
# ECCO PHP Adapter
by Timea Kovacs

Uses [PhpParser](https://github.com/oliverklee/phpparser "PhpParser").
