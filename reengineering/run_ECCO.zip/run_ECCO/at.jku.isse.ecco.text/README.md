
# ECCO Text Adapter

Artifact plugin for ECCO that provides reader, writer and viewer for text files.

