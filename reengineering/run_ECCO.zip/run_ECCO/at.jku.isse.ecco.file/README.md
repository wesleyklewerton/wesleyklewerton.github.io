
# ECCO File Adapter

Artifact plugin for ECCO that provides reader, writer and viewer for binary files.

