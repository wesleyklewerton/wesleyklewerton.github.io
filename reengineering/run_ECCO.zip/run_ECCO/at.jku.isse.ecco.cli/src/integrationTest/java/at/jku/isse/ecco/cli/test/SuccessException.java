package at.jku.isse.ecco.cli.test;

public class SuccessException extends RuntimeException {

	public SuccessException(String message) {
		super(message);
	}

}
