package at.jku.isse.ecco.core;

import org.garret.perst.Persistent;

public class PerstWarning extends Persistent implements Warning {

}
