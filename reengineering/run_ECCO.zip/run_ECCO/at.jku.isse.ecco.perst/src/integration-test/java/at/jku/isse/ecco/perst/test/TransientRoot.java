package at.jku.isse.ecco.perst.test;

public class TransientRoot {

	public transient int transientInt = 0;

	public int normalInt = 0;

}
