
# ECCO JPA Backend

Java Persistence API (JPA) backend plugin for ECCO.

