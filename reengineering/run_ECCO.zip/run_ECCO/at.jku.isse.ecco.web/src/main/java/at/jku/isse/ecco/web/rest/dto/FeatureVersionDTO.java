package at.jku.isse.ecco.web.rest.dto;

public class FeatureVersionDTO {

	private int version;
	private String description;

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
