package at.jku.isse.ecco.web.rest;

public class EccoResource {

}
