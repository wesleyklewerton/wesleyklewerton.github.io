
# ECCO WEB SERVER / REST API

Web server that serves static files and provides a REST API for ECCO.

