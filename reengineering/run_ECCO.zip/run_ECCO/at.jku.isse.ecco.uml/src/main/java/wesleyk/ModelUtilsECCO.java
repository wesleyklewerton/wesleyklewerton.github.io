package wesleyk;

import org.eclipse.emf.diffmerge.util.ModelImplUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.uml2.uml.Association;
import org.eclipse.uml2.uml.ClassifierTemplateParameter;
import org.eclipse.uml2.uml.Dependency;
import org.eclipse.uml2.uml.Generalization;
import org.eclipse.uml2.uml.InterfaceRealization;
import org.eclipse.uml2.uml.LiteralInteger;
import org.eclipse.uml2.uml.LiteralUnlimitedNatural;
import org.eclipse.uml2.uml.NamedElement;
import org.eclipse.uml2.uml.Operation;
import org.eclipse.uml2.uml.Parameter;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.TemplateBinding;
import org.eclipse.uml2.uml.TemplateParameterSubstitution;
import org.eclipse.uml2.uml.internal.impl.AssociationClassImpl;
import org.eclipse.uml2.uml.internal.impl.AssociationImpl;
import org.eclipse.uml2.uml.internal.impl.ClassImpl;
import org.eclipse.uml2.uml.internal.impl.ClassifierTemplateParameterImpl;
import org.eclipse.uml2.uml.internal.impl.CommentImpl;
import org.eclipse.uml2.uml.internal.impl.DependencyImpl;
import org.eclipse.uml2.uml.internal.impl.EnumerationImpl;
import org.eclipse.uml2.uml.internal.impl.EnumerationLiteralImpl;
import org.eclipse.uml2.uml.internal.impl.GeneralizationImpl;
import org.eclipse.uml2.uml.internal.impl.InterfaceImpl;
import org.eclipse.uml2.uml.internal.impl.InterfaceRealizationImpl;
import org.eclipse.uml2.uml.internal.impl.LiteralIntegerImpl;
import org.eclipse.uml2.uml.internal.impl.LiteralUnlimitedNaturalImpl;
import org.eclipse.uml2.uml.internal.impl.ModelImpl;
import org.eclipse.uml2.uml.internal.impl.OperationImpl;
import org.eclipse.uml2.uml.internal.impl.PackageImpl;
import org.eclipse.uml2.uml.internal.impl.ParameterImpl;
import org.eclipse.uml2.uml.internal.impl.PrimitiveTypeImpl;
import org.eclipse.uml2.uml.internal.impl.PropertyImpl;
import org.eclipse.uml2.uml.internal.impl.RedefinableTemplateSignatureImpl;
import org.eclipse.uml2.uml.internal.impl.TemplateBindingImpl;
import org.eclipse.uml2.uml.internal.impl.UsageImpl;

public class ModelUtilsECCO {
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	
	public static String getUniqueId(EObject element_p) {
		String result = null;
		
		if ( (result == null) && (element_p instanceof ModelImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((ModelImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof PackageImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((PackageImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof EnumerationImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((EnumerationImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof EnumerationLiteralImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((EnumerationLiteralImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof ClassImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((ClassImpl) element_p).getQualifiedName();
		}

		if ( (result == null) && (element_p instanceof InterfaceImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((InterfaceImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof PropertyImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((PropertyImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof OperationImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((OperationImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof ParameterImpl) ) {
			result = "[" + element_p.getClass().toString() + "] ";
		    result += ((ParameterImpl) element_p).getOperation().getQualifiedName();
		    result += " Direction:" + ((ParameterImpl) element_p).getDirection();
		    result += " Name:" + ((ParameterImpl) element_p).getName();
		    if(((ParameterImpl) element_p).getType() != null){
		    	result += " Type:" + ((ParameterImpl) element_p).getType().getName();
		    }
		    
		}
		
		if ( (result == null) && (element_p instanceof LiteralIntegerImpl) ) {
			result = "[" + element_p.getClass().toString() + "] ";
			if( ((LiteralIntegerImpl)element_p).getOwner() instanceof PropertyImpl ){
				result += ((PropertyImpl) ((LiteralIntegerImpl)element_p).getOwner()).getQualifiedName();
			}else if( ((LiteralIntegerImpl)element_p).getOwner() instanceof ParameterImpl ){
			    result += ((ParameterImpl) ((LiteralIntegerImpl)element_p).getOwner()).getOperation().getQualifiedName();
			    result += " Direction:" + ((ParameterImpl) ((LiteralIntegerImpl)element_p).getOwner()).getDirection();
			    result += " Name:" + ((ParameterImpl) ((LiteralIntegerImpl)element_p).getOwner()).getName();
			    if(((ParameterImpl) ((LiteralIntegerImpl)element_p).getOwner()).getType() != null){
			    	result += " Type:" + ((ParameterImpl) ((LiteralIntegerImpl)element_p).getOwner()).getType().getName();
			    }
			}
			result +=  "=" + ((LiteralIntegerImpl) element_p).getValue();
		}
		
		if ( (result == null) && (element_p instanceof LiteralUnlimitedNaturalImpl) ) {
			result = "[" + element_p.getClass().toString() + "] ";
			if( ((LiteralUnlimitedNaturalImpl)element_p).getOwner() instanceof PropertyImpl ){
				result += ((PropertyImpl) ((LiteralUnlimitedNaturalImpl)element_p).getOwner()).getQualifiedName();
			}else if( ((LiteralUnlimitedNaturalImpl)element_p).getOwner() instanceof ParameterImpl ){
			    result += ((ParameterImpl) ((LiteralUnlimitedNaturalImpl)element_p).getOwner()).getOperation().getQualifiedName();
			    result += " Direction:" + ((ParameterImpl) ((LiteralUnlimitedNaturalImpl)element_p).getOwner()).getDirection();
			    result += " Name:" + ((ParameterImpl) ((LiteralUnlimitedNaturalImpl)element_p).getOwner()).getName();
			    if(((ParameterImpl) ((LiteralUnlimitedNaturalImpl)element_p).getOwner()).getType() != null){
			    	result += " Type:" + ((ParameterImpl) ((LiteralUnlimitedNaturalImpl)element_p).getOwner()).getType().getName();
			    }
			}
			result +=  "=" + ((LiteralUnlimitedNaturalImpl) element_p).getValue();
		}
		
		if ( (result == null) && (element_p instanceof PrimitiveTypeImpl) ) {
			result = "[" + element_p.getClass().toString() + "] " +((PrimitiveTypeImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof CommentImpl) ) {
			result = "[" + element_p.getClass().toString() + "] ";
			if(((CommentImpl) element_p).getOwner() instanceof NamedElement){
				result += ((NamedElement) ((CommentImpl) element_p).getOwner()).getQualifiedName() + " ";
			}
			 
			result += ((CommentImpl) element_p).getBody();
		}
		
		if ( (result == null) && (element_p instanceof RedefinableTemplateSignatureImpl) ) {
			result = "[" + element_p.getClass().toString() + "] ";
			if(((RedefinableTemplateSignatureImpl) element_p).getOwner() instanceof NamedElement){
				result += ((NamedElement) ((RedefinableTemplateSignatureImpl) element_p).getOwner()).getQualifiedName() + " ";
			}
			result +=  ((RedefinableTemplateSignatureImpl) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof ClassifierTemplateParameterImpl) ) {
			result = "[" + element_p.getClass().toString() + "] ";
			if(((ClassifierTemplateParameterImpl) element_p).getOwner() instanceof NamedElement){
				result += ((NamedElement) ((ClassifierTemplateParameterImpl) element_p).getOwner()).getQualifiedName() + " ";
			}
		}
		
		if ( (result == null)) {
			result = " --> " + element_p.getClass().toString();
		}
		
		return result;
	}
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	
	
	public static String getID(EObject element_p) {
		String result = ModelImplUtil.getIntrinsicID(element_p);
		

		if ( (result == null) && (element_p instanceof NamedElement) ) {
			result = ((NamedElement) element_p).getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof LiteralUnlimitedNatural) ) {
			String str = element_p.eClass().getName();
			result = str + "=" + ((LiteralUnlimitedNatural) element_p).getValue();
		}
		
		if ( (result == null) && (element_p instanceof LiteralInteger) ) {
			String str = element_p.eClass().getName();
			result = str + "=" + ((LiteralInteger) element_p).getValue();
		}
		
		if ( (result == null) && (element_p instanceof Parameter) ) {
			String str = element_p.eClass().getName();
			if(((Parameter) element_p).getType() == null){
				result = str;
			}else{
				result = str + "=" + ((Parameter) element_p).getType().getQualifiedName();
			}
		}
		
		if ( (result == null) && (element_p instanceof Generalization) ) {
			String str = element_p.eClass().getName();
			result = str + "=" + ((Generalization) element_p).getGeneral().getQualifiedName();
		}
		
		if ( (result == null) && (element_p instanceof InterfaceRealization) ) {
			String str = element_p.eClass().getName();
			if( ((InterfaceRealization) element_p).getContract() == null){
				result = str;
			}else{
				result = str + "=" + ((InterfaceRealization) element_p).getContract().getQualifiedName();
			}
		}
		
		if ( (result == null) && (element_p instanceof Dependency) ) {
			String str = element_p.eClass().getName();
			if( ((Dependency) element_p).getClient(null) == null){
				result = str;
			}else{
				result = str + "=" + ((Dependency) element_p).getClient(null).getQualifiedName();
			}
		}
		
		if ( (result == null) && (element_p instanceof Association) ) {
			String str = element_p.eClass().getName();
			if(((Association) element_p).getEndType(null) == null){
				result = str;
			}else{
				result = str + "=" + ((Association) element_p).getEndType(null).getQualifiedName();
			}
			
		}
		
		if ( (result == null) && (element_p instanceof Property) ) {
			String str = element_p.eClass().getName();
			if(((Property) element_p).getType() == null){
				result = str;
			}else{
				result = str + "=" + ((Property) element_p).getType().getQualifiedName();
			}
			
		}
		
		if ( (result == null) && (element_p instanceof ClassifierTemplateParameter) ) {
			String str = element_p.eClass().getName();
			//result = str + "=" + ((ClassifierTemplateParameter) element_p).getSignature().getParameters();
			//result = str + "=" + ((ClassifierTemplateParameter) element_p).getOwnedParameteredElement().get;
			result = str;
		}

		if ( (result == null) && (element_p instanceof TemplateBinding) ) {
			String str = element_p.eClass().getName();
			result = str;// + "=" + ((TemplateBinding) element_p).getSignature().;
		}
		
		if ( (result == null) && (element_p instanceof TemplateParameterSubstitution) ) {
			String str = element_p.eClass().getName();
			result = str;// + "=" + ((TemplateParameterSubstitution) element_p).getSignature().;
		}
		
		if ( (result == null) && (element_p instanceof Operation) ) {
			String str = element_p.eClass().getName();
			result = str + "=" + ((Operation) element_p).getVisibility();
		}
		

		//TODO get information based on object type
//		if (result == null){
//			result = getExtrinsicID(element_p, scope_p);
//		}
//		if (result == null){
//			result = getComparableURI(element_p);
//		}
		
//		if(result == null){
//			System.out.println("it stops here");
//			System.exit(0);
//		}
		
		return result;
	}

	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	
	public static boolean isRelationship(EObject eObj){
		
		if(eObj instanceof AssociationImpl || 
				eObj instanceof UsageImpl || 
				eObj instanceof DependencyImpl || 
				eObj instanceof GeneralizationImpl || 
				eObj instanceof InterfaceRealizationImpl || 
				eObj instanceof AssociationClassImpl || 
				eObj instanceof TemplateBindingImpl){ //TemplateBindingImpl is no considered in references
			return true;
		}
		
		return false;
	}
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
}
