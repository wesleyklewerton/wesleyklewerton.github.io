package wesleyk;

import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.uml2.uml.UMLPackage;
import org.eclipse.uml2.uml.resource.UMLResource;

import org.eclipse.uml2.uml.internal.impl.CommentImpl;
import org.eclipse.uml2.uml.internal.impl.PropertyImpl;
import org.eclipse.uml2.uml.internal.impl.UMLFactoryImpl;
import org.eclipse.uml2.uml.Comment;
import org.eclipse.uml2.uml.Element;

public class TestVariabilityGrafting {
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	public static void main(String[] args) {
		System.out.println("Processing Resources:");
		try {
			ResourceSet resourceSet = new ResourceSetImpl();
			resourceSet.getPackageRegistry().put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE);

			resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(UMLResource.FILE_EXTENSION, UMLResource.Factory.INSTANCE);
			Map<URI, URI> uriMap = resourceSet.getURIConverter().getURIMap();
			Resource resource = resourceSet.getResource(URI.createFileURI(
					"/home/wesley/workspaceNeon/ExampleApproach/model_merging/Example_model_best_tests.uml"), true);
			resource.load(uriMap);
			
			System.out.println(resource);
			System.out.println("---------------");
			
			resource.getAllContents().forEachRemaining(eobj -> {
//				System.out.println( ModelUtilsECCO.getUniqueId(eobj) );
				System.out.println( eobj );
				if (eobj instanceof PropertyImpl) {
//					UMLFactoryImpl factory = new UMLFactoryImpl();
//					Comment comment = factory.createComment();
					Comment comment = ((Element) eobj).createOwnedComment();
					comment.setBody("Meu primeiro comentario");
				}
			});
			
			System.out.println("---------------");
			
			;
			saveUML(
					URI.createURI("/home/wesley/workspaceNeon/ExampleApproach/model_merging/Example_model_best_tests_3.uml"), 
					resource);
			
			resource.getAllContents().forEachRemaining(eobj -> {
				System.out.println( eobj );
			});
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	public static synchronized boolean saveUML(URI modelURI, Resource resource){
		try {
			ResourceSet resourceSet = new ResourceSetImpl();
			resourceSet.getPackageRegistry().put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE);

			resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(UMLResource.FILE_EXTENSION, UMLResource.Factory.INSTANCE);
			Map<URI, URI> uriMap = resourceSet.getURIConverter().getURIMap();
//			URI uri = URI.createURI("jar:file:/home/wesley/eclipseKepler/plugins/org.eclipse.uml2.uml.resources_4.1.0.v20140202-2055.jar!/");
//			uriMap.put(URI.createURI(UMLResource.LIBRARIES_PATHMAP), uri.appendSegment("libraries").appendSegment(""));
//			uriMap.put(URI.createURI(UMLResource.METAMODELS_PATHMAP), uri.appendSegment("metamodels").appendSegment(""));
//			uriMap.put(URI.createURI(UMLResource.PROFILES_PATHMAP), uri.appendSegment("profiles").appendSegment(""));

			Resource r = resourceSet.createResource(modelURI);
			r.getContents().addAll(resource.getContents());
			r.save(uriMap);
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
