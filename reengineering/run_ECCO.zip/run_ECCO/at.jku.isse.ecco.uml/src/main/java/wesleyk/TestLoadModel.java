package wesleyk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.uml2.uml.UMLPackage;
import org.eclipse.uml2.uml.internal.impl.AssociationClassImpl;
import org.eclipse.uml2.uml.internal.impl.AssociationImpl;
import org.eclipse.uml2.uml.internal.impl.DependencyImpl;
import org.eclipse.uml2.uml.internal.impl.GeneralizationImpl;
import org.eclipse.uml2.uml.internal.impl.InterfaceRealizationImpl;
import org.eclipse.uml2.uml.internal.impl.PropertyImpl;
import org.eclipse.uml2.uml.internal.impl.TemplateBindingImpl;
import org.eclipse.uml2.uml.internal.impl.UsageImpl;
import org.eclipse.uml2.uml.resource.UMLResource;

public class TestLoadModel {
	
	public static List<EObject> tempAllEobjs = new ArrayList<>();

	public static void main(String[] args) {
		System.out.println("Processing Resources:");
		try {
			ResourceSet resourceSet = new ResourceSetImpl();
			resourceSet.getPackageRegistry().put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE);

			resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(UMLResource.FILE_EXTENSION, UMLResource.Factory.INSTANCE);
			Map<URI, URI> uriMap = resourceSet.getURIConverter().getURIMap();
//			URI uri = URI.createURI("jar:file:/home/wesley/eclipseKepler/plugins/org.eclipse.uml2.uml.resources_4.1.0.v20140202-2055.jar!/");
//			URI uri = URI.createURI("jar:file:/home/wesley/eclipseMars/plugins/org.eclipse.uml2.uml.resources_5.1.0.v20160201-0816!/");
//			uriMap.put(URI.createURI(UMLResource.LIBRARIES_PATHMAP), uri.appendSegment("libraries").appendSegment(""));
//			uriMap.put(URI.createURI(UMLResource.METAMODELS_PATHMAP), uri.appendSegment("metamodels").appendSegment(""));
//			uriMap.put(URI.createURI(UMLResource.PROFILES_PATHMAP), uri.appendSegment("profiles").appendSegment(""));

//			Resource resource = resourceSet.getResource(URI.createFileURI("/home/wesley/workspaceNeon/BankSystemVariants/Product5Bank.uml"), true);
			
			Resource resource = resourceSet.getResource(URI.createFileURI("/home/wesley/workspaceNeon/CaseStudies/Example_02/Example.uml"), true);
			
//			Resource resource = resourceSet.getResource(URI.createFileURI("/home/wesley/workspaceNeon/CaseStudies/DPL_P15/model2/DPL.uml"), true);
//			Resource resource = resourceSet.getResource(URI.createFileURI("/home/wesley/workspaceNeon/CaseStudies/DPL_P15/model/DPL_cleaned.uml"), true);
			
//			Resource resource = resourceSet.getResource(URI.createFileURI("/home/wesley/workspaceNeon/UmlDesinerProject/model.uml"), true);
//			Resource resource = resourceSet.getResource(URI.createFileURI("/home/wesley/workspaceNeon/UmlDesinerProject/my.uml"), true);
			resource.load(uriMap);
			
			System.out.println(resource);
			System.out.println("---------------");
			
			setReferences(resource);
			
			List<EObject> eobjs = resource.getContents();
			getContentWithoutRelationships(eobjs);
			
			System.out.println("---------------");
			System.out.println(tempAllEobjs.size());
			tempAllEobjs.forEach(eob -> {
				System.out.println( ModelUtilsECCO.getUniqueId(eob) );
			});

			System.exit(0);
			
//			System.out.println(eobjs.size());
//			System.out.println(eobjs.get(0).eContents().size());
//			System.out.println(eobjs.get(0).eContents().get(0).eContents().size());
			

			System.out.println("---------------");
			resource.getAllContents().forEachRemaining(eObj -> {
				//System.out.println( ModelUtilsECCO.getStringRepresentation(eObj) );
				System.out.println(eObj);
//				
//				
//				System.out.println("---> ID: " + ModelUtilsECCO.getID(eObj));
//				System.out.println("---> Type: " + eObj.getClass());
//				System.out.println("---> Parent: " + ModelUtilsECCO.getID(eObj.eContainer()));
//				System.out.println("---------------");
			});
			
			
			
			
			
			
			resource.getAllContents().forEachRemaining(eObj -> {
//				System.out.println(eObj);
//				System.out.println("---> ID: " + ModelUtilsECCO.getID(eObj));
//				System.out.println("---> Type: " + eObj.getClass());
//				System.out.println("---> Parent: " + ModelUtilsECCO.getID(eObj.eContainer()));
//				System.out.println("---------------");

				if(eObj instanceof AssociationImpl){
					System.out.println("\n\n-------------- "+eObj.getClass()+" -----------------");
					System.out.println(eObj);
//					System.out.println( "General --> "+((AssociationImpl) eObj).getEndTypes() );
					System.out.println("End Types");
					((AssociationImpl) eObj).getEndTypes().forEach(obj -> {
						System.out.println(obj);
					});
//					eObj.eAllContents().forEachRemaining(obj -> {
//						System.out.println(obj);
//					});
					System.out.println("\n");
				}
				
			
				if(eObj instanceof UsageImpl){
					System.out.println("\n\n-------------- "+eObj.getClass()+" -----------------");
					System.out.println(eObj);
					System.out.println("Container --> "+eObj.eContainer());
					System.out.println( "Sources --> "+((UsageImpl) eObj).getSources() );
					System.out.println( "Targets --> "+((UsageImpl) eObj).getTargets() );
					System.out.println("\n");
				}
				
				if(eObj instanceof DependencyImpl){
					System.out.println("\n\n-------------- "+eObj.getClass()+" -----------------");
					System.out.println(eObj);
					System.out.println("Container --> "+eObj.eContainer());
					System.out.println( "Sources --> "+((DependencyImpl) eObj).getSources() );
					System.out.println( "Targets --> "+((DependencyImpl) eObj).getTargets() );
					System.out.println("\n");
				}

				if(eObj instanceof GeneralizationImpl){
					System.out.println("\n\n-------------- "+eObj.getClass()+" -----------------");
					System.out.println(eObj);
					System.out.println("Container --> "+eObj.eContainer());
					System.out.println( "General --> "+((GeneralizationImpl) eObj).getGeneral() );
					System.out.println("\n");
				}
				
				if(eObj instanceof InterfaceRealizationImpl){
					System.out.println("\n\n-------------- "+eObj.getClass()+" -----------------");
					System.out.println(eObj);
					System.out.println("Container --> "+eObj.eContainer());
					System.out.println( "Contract --> "+((InterfaceRealizationImpl) eObj).getContract() );
					eObj.eAllContents().forEachRemaining(obj -> {
						System.out.println(obj);
					});
					System.out.println("\n");
				}
				
				if(eObj instanceof AssociationClassImpl){
					System.out.println("\n\n-------------- "+eObj.getClass()+" -----------------");
					System.out.println(eObj);

					System.out.println("End Types");
					((AssociationClassImpl) eObj).getEndTypes().forEach(obj -> {
						System.out.println(obj);
					});
				}
				
//				UmlArtifactData data = new UmlArtifactData(eObj.getName(), "LIST");
//				Artifact artifact = this.entityFactory.createArtifact(data);
//				Node node = this.entityFactory.createNode(artifact);
				
				
//				// ID
//				UMLItemProviderAdapterFactory up = new UMLItemProviderAdapterFactory();
//				AdapterFactoryLabelProvider p = new AdapterFactoryLabelProvider(up);
//				String idString = p.getText(eObj);
//				System.out.println("---> ID: " + idString);
//				Artifact<Um>
//				pluginNode.addChild(this.entityFactory.createNode(artifact));
			});
			
//			TreeIterator<EObject> eAllContents = resource.getAllContents();
//			while (eAllContents.hasNext()) {
//				EObject obj = eAllContents.next();
//				System.out.println(obj.toString());
//			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	

	
	public static void getContentWithoutRelationships(List<EObject> eobjs){
		eobjs.forEach(eobj -> {
			if(!ModelUtilsECCO.isRelationship(eobj)){
				tempAllEobjs.add(eobj);
				if( ((EObject)eobj).eContents().size() > 0){
					getContentWithoutRelationships(((EObject)eobj).eContents());
				}
			}
		});
	}
	
	public static void setReferences(Resource resource) throws IllegalArgumentException{
		resource.getAllContents().forEachRemaining(eObj -> {
			if(ModelUtilsECCO.isRelationship(eObj)){
				String type = eObj.getClass().toString();
				String source = null;
				String target = null;
				
				if(eObj instanceof AssociationImpl){
					if( ((AssociationImpl) eObj).getEndTypes().size() > 1 ){
						if(((AssociationImpl) eObj).getMemberEnds().get(0).getName() != null){
							String propertyName = ((AssociationImpl) eObj).getMemberEnds().get(0).getName();
							source = ModelUtilsECCO.getUniqueId( ((AssociationImpl) eObj).getMemberEnds().get(1).getType() ) + "::" + propertyName;
							source = source.replace("ClassImpl", "PropertyImpl");
							target = ModelUtilsECCO.getUniqueId( ((AssociationImpl) eObj).getMemberEnds().get(0).getType() );
						}else{
							String propertyName = ((AssociationImpl) eObj).getMemberEnds().get(1).getName();
							source = ModelUtilsECCO.getUniqueId( ((AssociationImpl) eObj).getMemberEnds().get(0).getType() ) + "::" + propertyName;
							source = source.replace("ClassImpl", "PropertyImpl");
							target = ModelUtilsECCO.getUniqueId( ((AssociationImpl) eObj).getMemberEnds().get(1).getType() );
						}
					}
				}else if(eObj instanceof UsageImpl){
					source = ModelUtilsECCO.getUniqueId( ((UsageImpl) eObj).getSources().get(0) );
					target = ModelUtilsECCO.getUniqueId( ((UsageImpl) eObj).getTargets().get(0) );
				}else if(eObj instanceof InterfaceRealizationImpl){
					source = ModelUtilsECCO.getUniqueId( eObj.eContainer() );
					if( ((InterfaceRealizationImpl) eObj).getContract() != null ){
						target = ModelUtilsECCO.getUniqueId( ((InterfaceRealizationImpl) eObj).getContract() );
					}else{
						target = null;
					}
				}else if(eObj instanceof DependencyImpl){
					source = ModelUtilsECCO.getUniqueId( ((DependencyImpl) eObj).getSources().get(0) );
					if( ((DependencyImpl) eObj).getTargets().size() > 0 ){
						target = ModelUtilsECCO.getUniqueId( ((DependencyImpl) eObj).getTargets().get(0) );
					}else{
						target = null;
					}
				}else if(eObj instanceof GeneralizationImpl){
					source = ModelUtilsECCO.getUniqueId( eObj.eContainer() );
					target = ModelUtilsECCO.getUniqueId( ((GeneralizationImpl) eObj).getGeneral() );
				}else if(eObj instanceof AssociationClassImpl){
					source = ModelUtilsECCO.getUniqueId( ((AssociationClassImpl) eObj).getEndTypes().get(0) );
					target = ModelUtilsECCO.getUniqueId( ((AssociationClassImpl) eObj).getEndTypes().get(1) );
				}else if(eObj instanceof TemplateBindingImpl){
					source = ModelUtilsECCO.getUniqueId( ((TemplateBindingImpl) eObj).getBoundElement() );
					target = ModelUtilsECCO.getUniqueId( ((TemplateBindingImpl) eObj).getSignature() );
				}
				
				if(source == null || target == null){
//					throw new IllegalArgumentException("Reference's Target or Source is empty");
				}
				
				//here we create the ecco reference
				System.out.println("Type:   " + type);
				System.out.println("Source: " + source);
				System.out.println("Target: " + target+"\n");
			}
		});
	}

}
