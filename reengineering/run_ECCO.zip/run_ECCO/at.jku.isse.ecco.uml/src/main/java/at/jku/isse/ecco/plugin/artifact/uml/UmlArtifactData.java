package at.jku.isse.ecco.plugin.artifact.uml;

import static com.google.common.base.Preconditions.checkNotNull;

import at.jku.isse.ecco.plugin.artifact.ArtifactData;

public class UmlArtifactData implements ArtifactData {

	private String id;

	public UmlArtifactData(String id) {
		checkNotNull(id);
		this.id = id;
	}
	
	public String getId() {
		return id;
	}
	
	
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		String objStr = ((UmlArtifactData) o).toString();

		return this.toString().equals(objStr);
	}

	@Override
//	public int hashCode() {
//		int result = id.hashCode();
//		result = 31 * result + id.hashCode();
//		return result;
//	}
	
	public String toString(){
		return this.id;
	}

}
