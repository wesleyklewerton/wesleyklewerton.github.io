package at.jku.isse.ecco.plugin.artifact.uml;

import static com.google.common.base.Preconditions.checkNotNull;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.uml2.uml.UMLPackage;
import org.eclipse.uml2.uml.internal.impl.AssociationClassImpl;
import org.eclipse.uml2.uml.internal.impl.AssociationImpl;
import org.eclipse.uml2.uml.internal.impl.DependencyImpl;
import org.eclipse.uml2.uml.internal.impl.GeneralizationImpl;
import org.eclipse.uml2.uml.internal.impl.InterfaceRealizationImpl;
import org.eclipse.uml2.uml.internal.impl.TemplateBindingImpl;
import org.eclipse.uml2.uml.internal.impl.UsageImpl;
import org.eclipse.uml2.uml.resource.UMLResource;

import com.google.inject.Inject;

import at.jku.isse.ecco.artifact.Artifact;
import at.jku.isse.ecco.artifact.ArtifactReference;
import at.jku.isse.ecco.dao.EntityFactory;
import at.jku.isse.ecco.listener.ReadListener;
import at.jku.isse.ecco.plugin.artifact.ArtifactReader;
import at.jku.isse.ecco.plugin.artifact.PluginArtifactData;
import at.jku.isse.ecco.tree.Node;
import wesleyk.ModelUtilsECCO;

public class UmlReader implements ArtifactReader<Path, Set<Node>> {

	private final EntityFactory entityFactory;
	
	private List<EObject> tempAllEobjs = null;
	private Artifact<?> tempArtifact = null;

	@Inject
	public UmlReader(EntityFactory entityFactory) {
		checkNotNull(entityFactory);

		this.entityFactory = entityFactory;
	}

	@Override
	public String getPluginId() {
		return UmlPlugin.class.getName();
	}

	private static final String[] typeHierarchy = new String[]{"xmi", "uml"};

	@Override
	public String[] getTypeHierarchy() {
		return typeHierarchy;
	}

	@Override
	public boolean canRead(Path path) {
		if (!Files.isDirectory(path) && Files.isRegularFile(path) && (path.getFileName().toString().toLowerCase().endsWith(".xmi") || path.getFileName().toString().toLowerCase().endsWith(".uml")))
			return true;
		else
			return false;
	}

	@Override
	public Set<Node> read(Path[] input) {
		return this.read(Paths.get("."), input);
	}

	@Override
	public Set<Node> read(Path base, Path[] input) {
		Set<Node> nodes = new HashSet<>();
		for (Path path : input) {
			Path resolvedPath = base.resolve(path);

			// PLUGIN NODE
			Artifact<PluginArtifactData> pluginArtifact = this.entityFactory.createArtifact(new PluginArtifactData(this.getPluginId(), path));
			Node pluginNode = this.entityFactory.createNode(pluginArtifact);
			nodes.add(pluginNode);
			
			System.out.println("Processing Resources: " + resolvedPath.toString());
			try {
				ResourceSet resourceSet = new ResourceSetImpl();
				resourceSet.getPackageRegistry().put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE);
	
				resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(UMLResource.FILE_EXTENSION, UMLResource.Factory.INSTANCE);
				Map<URI, URI> uriMap = resourceSet.getURIConverter().getURIMap();
				//Ready to load UML2 5.0.0 models
				Resource resource = resourceSet.getResource(URI.createFileURI(resolvedPath.toString()), true);
				resource.load(uriMap);
				
				List<EObject> eobjs = resource.getContents();
				tempAllEobjs = new ArrayList<>();
				getContentWithoutRelationships(eobjs);
				
				tempAllEobjs.forEach(eObj -> {
					String id = ModelUtilsECCO.getUniqueId(eObj);
					UmlArtifactData data = new UmlArtifactData(id);
					Artifact<UmlArtifactData> artifact = this.entityFactory.createArtifact(data);

					Node node = this.entityFactory.createNode(artifact);
					pluginNode.addChild(node);
					//System.out.println("-->" + (node.getArtifact().getData()) );
				});
				System.out.println("Number of Artifacts: " + pluginNode.countArtifacts());
			
				resolveReverences(resource, pluginNode);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		return nodes;
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public void getContentWithoutRelationships(List<EObject> eobjs){
		eobjs.forEach(eobj -> {
			if(!ModelUtilsECCO.isRelationship(eobj)){
				tempAllEobjs.add(eobj);
				if( ((EObject)eobj).eContents().size() > 0){
					getContentWithoutRelationships(((EObject)eobj).eContents());
				}
			}
		});
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public void resolveReverences(Resource resource, Node node) throws IllegalArgumentException{
		
		resource.getAllContents().forEachRemaining(eObj -> {
			if(ModelUtilsECCO.isRelationship(eObj)){
				String source = null;
				String target = null;
				
				if(eObj instanceof AssociationImpl){
					if( ((AssociationImpl) eObj).getEndTypes().size() > 1 ){
						if(((AssociationImpl) eObj).getMemberEnds().get(0).getName() != null){
							String propertyName = ((AssociationImpl) eObj).getMemberEnds().get(0).getName();
							source = ModelUtilsECCO.getUniqueId( ((AssociationImpl) eObj).getMemberEnds().get(1).getType() ) + "::" + propertyName;
							source = source.replace("ClassImpl", "PropertyImpl");
							target = ModelUtilsECCO.getUniqueId( ((AssociationImpl) eObj).getMemberEnds().get(0).getType() );
						}else{
							String propertyName = ((AssociationImpl) eObj).getMemberEnds().get(1).getName();
							source = ModelUtilsECCO.getUniqueId( ((AssociationImpl) eObj).getMemberEnds().get(0).getType() ) + "::" + propertyName;
							source = source.replace("ClassImpl", "PropertyImpl");
							target = ModelUtilsECCO.getUniqueId( ((AssociationImpl) eObj).getMemberEnds().get(1).getType() );
						}
					}
				}else if(eObj instanceof UsageImpl){
					source = ModelUtilsECCO.getUniqueId( ((UsageImpl) eObj).getSources().get(0) );
					target = ModelUtilsECCO.getUniqueId( ((UsageImpl) eObj).getTargets().get(0) );
				}else if(eObj instanceof InterfaceRealizationImpl){
					source = ModelUtilsECCO.getUniqueId( eObj.eContainer() );
					if( ((InterfaceRealizationImpl) eObj).getContract() != null ){
						target = ModelUtilsECCO.getUniqueId( ((InterfaceRealizationImpl) eObj).getContract() );
					}else{
						target = null;
					}
				}else if(eObj instanceof DependencyImpl){
					source = ModelUtilsECCO.getUniqueId( ((DependencyImpl) eObj).getSources().get(0) );
					if( ((DependencyImpl) eObj).getTargets().size() > 0 ){
						target = ModelUtilsECCO.getUniqueId( ((DependencyImpl) eObj).getTargets().get(0) );
					}else{
						target = null;
					}
				}else if(eObj instanceof GeneralizationImpl){
					source = ModelUtilsECCO.getUniqueId( eObj.eContainer() );
					target = ModelUtilsECCO.getUniqueId( ((GeneralizationImpl) eObj).getGeneral() );
				}else if(eObj instanceof AssociationClassImpl){
					source = ModelUtilsECCO.getUniqueId( ((AssociationClassImpl) eObj).getEndTypes().get(0) );
					target = ModelUtilsECCO.getUniqueId( ((AssociationClassImpl) eObj).getEndTypes().get(1) );
				}else if(eObj instanceof TemplateBindingImpl){
					source = ModelUtilsECCO.getUniqueId( ((TemplateBindingImpl) eObj).getBoundElement() );
					target = ModelUtilsECCO.getUniqueId( ((TemplateBindingImpl) eObj).getSignature() );
				}
				
				if(source == null || target == null){
					//throw new IllegalArgumentException("Reference's Target or Source is empty");
					System.err.println("Source or Target of relationship is null: " + eObj);
				}else{
//					System.out.println("  Type:   " + type + " \n Source: " + source + " \n Target: " + target + "\n");
					
					//find the source artifact
					this.tempArtifact = null;
					getArtifactByName(node, source);
					Artifact<?> artifactSource = this.tempArtifact;
					
					//find the target artifact
					this.tempArtifact = null;
					getArtifactByName(node, target);
					Artifact<?> artifactTarget = this.tempArtifact;
					
					//references (source uses target / target usedBy source)
//					System.out.println(artifactSource + " \n" + artifactTarget);
					ArtifactReference reference = entityFactory.createArtifactReference(artifactSource,artifactTarget);
					artifactSource.addUses(reference);
					artifactTarget.addUsedBy(reference);
					
					System.out.println(reference.toString());
				}
			}
		});
	}
	
	public void getArtifactByName(Node node, String name) {
		if (node.getArtifact() != null) {
//			System.out.println("--> " + name);
//			System.out.println("--> " + node.getArtifact().toString() + "\n");
			if(node.getArtifact().toString().equals(name)){
				this.tempArtifact = node.getArtifact();
			}
		}
		// traverse into children
		for (Node child : node.getChildren()) {
			getArtifactByName(child, name);
		}
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	private Collection<ReadListener> listeners = new ArrayList<ReadListener>();

	@Override
	public void addListener(ReadListener listener) {
		this.listeners.add(listener);
	}

	@Override
	public void removeListener(ReadListener listener) {
		this.listeners.remove(listener);
	}

}
