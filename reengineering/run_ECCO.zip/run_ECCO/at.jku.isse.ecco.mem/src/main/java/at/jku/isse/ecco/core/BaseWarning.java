package at.jku.isse.ecco.core;

public class BaseWarning implements Warning {

	@Override
	public String toString() {
		return "TODO";
	}

}
