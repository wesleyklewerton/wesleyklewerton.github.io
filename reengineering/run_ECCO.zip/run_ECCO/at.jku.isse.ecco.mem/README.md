
# ECCO In-Memory Backend

Volatile In-Memory backend plugin for ECCO.

