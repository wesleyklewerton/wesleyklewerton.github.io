package wesleyk;

import java.util.Collection;

import at.jku.isse.ecco.EccoService;
import at.jku.isse.ecco.artifact.Artifact;
import at.jku.isse.ecco.core.Association;
import at.jku.isse.ecco.core.DependencyGraph;
import at.jku.isse.ecco.plugin.artifact.ArtifactData;
import at.jku.isse.ecco.tree.Node;

public class ExportTraceability {
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public static void main(String[] args) {
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_Example/uml");
		
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_BS/uml");
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_DPL/uml");
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_VOD/uml");
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_ZipMe/uml");
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_MMv1/uml");
		
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_GOL/uml");
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_MMv2/uml");
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_MMv3/uml");
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_MMv4/uml");
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_MMv5/uml");
				
		
		System.out.println("----------------------");
		System.out.println("Number of Commits: " + eccoService.getCommits().size() );
		System.out.println("Number of Featues: " + eccoService.getFeatures().size() );
		System.out.print("List of Featues:\n" );
		eccoService.getFeatures().forEach(feature -> {
			System.out.println("\t" + feature);
		});
		
		DependencyGraph dg = new DependencyGraph(eccoService.getAssociations());
		System.out.println("----------------------");
		System.out.println(dg.getDOTString());
		
		System.out.println("----------------------");
		System.out.println(dg.getXMLString());
		
		System.out.println("----------------------");
		System.out.print("List of Associations: \n\n");
		exportTraceability(eccoService.getAssociations());
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public static void exportTraceability(Collection<Association> associations){
		associations.forEach(assoc -> {
			if(assoc.getRootNode().countArtifacts() > 0){
				System.out.println( "Association:          " + assoc.getPresenceCondition() );
				System.out.println( "Simple label:         " + assoc.getPresenceCondition().getSimpleLabel() );
				System.out.println( "Number of Artifacts:  " + assoc.getRootNode().countArtifacts() );
				recursiveVisitArtefacts(assoc.getRootNode());
				
				System.out.println(  );
			}
		});
	}	
	
	public static void recursiveVisitArtefacts(Node node) {
		if (node.getArtifact() != null) {
			System.out.println(node.getArtifact());
		}
		// traverse into children
		for (Node child : node.getChildren()) {
			recursiveVisitArtefacts(child);
		}
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public static int countArtifactsInAssociationRec(Node node, int currentCount) {
		if (node.getArtifact() != null && node.isUnique()) {
			System.out.println(node.getArtifact());
			currentCount++;
		}
		for (Node child : node.getChildren()) {
			currentCount = countArtifactsInAssociationRec(child, currentCount);
		}
		return currentCount;
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public static Artifact<ArtifactData> getArtifactByName(Node node, String nome) {
		if (node.getArtifact() != null && node.isUnique()) {
			if(node.getArtifact().toString().equals(nome)){
				System.out.println(node.getArtifact());
			}
		}
		for (Node child : node.getChildren()) {
			getArtifactByName(child, nome);
		}
		return null;
	}
	
		
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
		
}
