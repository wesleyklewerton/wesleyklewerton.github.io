package wesleyk.variability_grafting;

import java.util.Collection;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.uml2.uml.Comment;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.UMLPackage;
import org.eclipse.uml2.uml.internal.impl.ClassImpl;
import org.eclipse.uml2.uml.internal.impl.EnumerationImpl;
import org.eclipse.uml2.uml.internal.impl.InterfaceImpl;
import org.eclipse.uml2.uml.internal.impl.OperationImpl;
import org.eclipse.uml2.uml.internal.impl.PackageImpl;
import org.eclipse.uml2.uml.internal.impl.PrimitiveTypeImpl;
import org.eclipse.uml2.uml.internal.impl.PropertyImpl;
import org.eclipse.uml2.uml.resource.UMLResource;

import at.jku.isse.ecco.EccoService;
import at.jku.isse.ecco.core.Association;
import at.jku.isse.ecco.tree.Node;
import wesleyk.ModelUtilsECCO;
import wesleyk.MyRepositoryUtils;

public class VariabilityGraftingVOD {
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	public static void main(String[] args) {
		//staring time
		long initTime = System.currentTimeMillis();
		
		String repository = "/home/wesley/workspaceMars/ecco/repository_VOD/uml";
		URI base = URI.createFileURI(
				"/home/wesley/my_files/documentos/pos-mestrado/2016_Tese_Doutorado/experiment_results/4-variability_grafting/input/VOD_15_model_best.uml");
		URI output = URI.createURI(
				"/home/wesley/my_files/documentos/pos-mestrado/2016_Tese_Doutorado/experiment_results/4-variability_grafting/output/VOD_15_model_best_VariabilityGrafted.uml");
		variabilityGrafting(repository, base, output);
		
		//ending time
	    long estimatedTime = System.currentTimeMillis() - initTime;
	    System.out.println("Total execution time: " + estimatedTime + "ms");
	}
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	public static synchronized boolean variabilityGrafting(String repositoryURL, URI baseModel, URI outputModel){
		try {
			System.out.println("Processing Variability Grafting:");
			
			
			ResourceSet resourceSet = new ResourceSetImpl();
			resourceSet.getPackageRegistry().put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE);
			resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(UMLResource.FILE_EXTENSION, UMLResource.Factory.INSTANCE);
			Map<URI, URI> uriMap = resourceSet.getURIConverter().getURIMap();
			Resource resource = resourceSet.getResource(baseModel, true);
			resource.load(uriMap);
			
			System.out.println(resource);
			System.out.println("---------------");
			
			EccoService eccoService = MyRepositoryUtils.getRepository(repositoryURL);
			System.out.println("---------------");
			
			Collection<Association> associations = eccoService.getAssociations();
			for (Association association : associations) {
				String presenceCondition = association.getPresenceCondition().getSimpleLabel();
				recursiveVisitArtefacts(association.getRootNode(), presenceCondition, resource);
			}
			
//			resource.getAllContents().forEachRemaining(eobj -> {
////				System.out.println( ModelUtilsECCO.getUniqueId(eobj) );
//				System.out.println( eobj );
//				if (eobj instanceof PropertyImpl) {
//					Comment comment = ((Element) eobj).createOwnedComment();
//					comment.setBody("Meu primeiro comentario");
//				}
//			});
			
			
			System.out.println("---------------");
			saveUML(outputModel,resource);
			
//			resource.getAllContents().forEachRemaining(eobj -> {
//				System.out.println( eobj );
//			});
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	public static void recursiveVisitArtefacts(Node node, String presenceCondition, Resource resource) {
		if (node.getArtifact() != null) {
			graft(node.getArtifact().toString(), presenceCondition, resource);
			//System.out.println(presenceCondition + " --> " + node.getArtifact());
		}
		// traverse into children
		for (Node child : node.getChildren()) {
			recursiveVisitArtefacts(child, presenceCondition, resource);
		}
	}
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	public static void graft(String elementId, String presenceCondition, Resource resource) {
		resource.getAllContents().forEachRemaining(eobj -> {
			if (eobj instanceof PackageImpl || 
					eobj instanceof ClassImpl || 
					eobj instanceof EnumerationImpl || 
					eobj instanceof InterfaceImpl || 
					eobj instanceof PropertyImpl || 
					eobj instanceof OperationImpl || 
					eobj instanceof PrimitiveTypeImpl) {
				if (elementId.equals( ModelUtilsECCO.getUniqueId(eobj) )) {
					System.out.println(presenceCondition + " --> " + elementId);
					Comment comment = ((Element) eobj).createOwnedComment();
					comment.setBody(presenceCondition);
				}
			}
		});
	}
	
	/*
	 * -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	 */
	public static synchronized boolean saveUML(URI modelURI, Resource resource){
		try {
			ResourceSet resourceSet = new ResourceSetImpl();
			resourceSet.getPackageRegistry().put(UMLPackage.eNS_URI, UMLPackage.eINSTANCE);
			resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(UMLResource.FILE_EXTENSION, UMLResource.Factory.INSTANCE);
			Map<URI, URI> uriMap = resourceSet.getURIConverter().getURIMap();
			Resource r = resourceSet.createResource(modelURI);
			r.getContents().addAll(resource.getContents());
			r.save(uriMap);
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
