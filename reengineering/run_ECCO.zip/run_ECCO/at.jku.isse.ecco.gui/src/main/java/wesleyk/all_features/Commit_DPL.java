package wesleyk.all_features;

import java.io.File;

import at.jku.isse.ecco.EccoService;
import wesleyk.MyRepositoryUtils;

public class Commit_DPL {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		String[][] variants = {
            {"DPL_P01", "DPL, Line"},
            {"DPL_P02", "DPL, Rect, Line"},
            {"DPL_P03", "DPL, Rect"},
            {"DPL_P04", "DPL, Rect, Color, Line"},
            {"DPL_P05", "DPL, Color, Line"},
            {"DPL_P06", "DPL, Rect, Color"},
            {"DPL_P07", "DPL, Wipe, Line"},
            {"DPL_P08", "DPL, Rect, Wipe, Line"},
            {"DPL_P09", "DPL, Rect, Wipe"},
            {"DPL_P10", "DPL, Rect, Color, Wipe, Line"},
            {"DPL_P11", "DPL, Color, Wipe, Line"},
            {"DPL_P12", "DPL, Rect, Color, Wipe"},
            {"DPL_P13", "DPL, Rect, Color, Fill, Line"},
            {"DPL_P14", "DPL, Rect, Fill, Color"},
            {"DPL_P15", "DPL, Rect, Color, Fill, Wipe, Line"},
            {"DPL_P16", "DPL, Rect, Color, Fill, Wipe"}
		};
		
		//staring time
		long initTime = System.currentTimeMillis();
		
		//DPL - UML
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_DPL/uml");
		for (String[] variant : variants) {
			MyRepositoryUtils.commitVariant(eccoService, 
					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0]+"/model")).toPath(), variant[1]);
		}

		//ending time
	    long estimatedTime = System.currentTimeMillis() - initTime;
	    System.out.println("Total execution time: " + estimatedTime + "ms");
		
		//DPL - JAVA
//		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_DPL/java");
//		for (String[] variant : variants) {
//			MyRepositoryUtils.commitVariant(eccoService, 
//					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0]+"/src")).toPath(), variant[1]);
//		}

	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
