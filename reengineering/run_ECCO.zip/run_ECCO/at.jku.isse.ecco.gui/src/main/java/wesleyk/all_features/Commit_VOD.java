package wesleyk.all_features;

import java.io.File;

import at.jku.isse.ecco.EccoService;
import wesleyk.MyRepositoryUtils;

public class Commit_VOD {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		String[][] variants = {
				{"VOD_00", "SelectMovie, PlayImm, VRCInterface, StartMovie, StartPlayer, VOD"},
				{"VOD_01", "SelectMovie, PlayImm, Pause, VRCInterface, StartMovie, StartPlayer, VOD"},
				{"VOD_02", "SelectMovie, PlayImm, VRCInterface, StopMovie, StartMovie, StartPlayer, VOD"},
				{"VOD_03", "SelectMovie, PlayImm, Pause, VRCInterface, StopMovie, StartMovie, StartPlayer, VOD"},
				{"VOD_04", "SelectMovie, PlayImm, VRCInterface, StartMovie, QuitPlayer, StartPlayer, VOD"},
				{"VOD_05", "SelectMovie, PlayImm, Pause, VRCInterface, StartMovie, QuitPlayer, StartPlayer, VOD"},
				{"VOD_06", "SelectMovie, PlayImm, VRCInterface, StopMovie, StartMovie, QuitPlayer, StartPlayer, VOD"},
				{"VOD_07", "SelectMovie, PlayImm, Pause, VRCInterface, StopMovie, StartMovie, QuitPlayer, StartPlayer, VOD"},
				{"VOD_08", "SelectMovie, PlayImm, VRCInterface, StartMovie, ChangeServer, StartPlayer, VOD"},
				{"VOD_09", "SelectMovie, PlayImm, Pause, VRCInterface, StartMovie, ChangeServer, StartPlayer, VOD"},
				{"VOD_10", "SelectMovie, PlayImm, VRCInterface, StopMovie, StartMovie, ChangeServer, StartPlayer, VOD"},
				{"VOD_11", "SelectMovie, PlayImm, Pause, VRCInterface, StopMovie, StartMovie, ChangeServer, StartPlayer, VOD"},
				{"VOD_12", "SelectMovie, PlayImm, VRCInterface, StartMovie, ChangeServer, QuitPlayer, StartPlayer, VOD"},
				{"VOD_13", "SelectMovie, PlayImm, Pause, VRCInterface, StartMovie, ChangeServer, QuitPlayer, StartPlayer, VOD"},
				{"VOD_14", "SelectMovie, PlayImm, VRCInterface, StopMovie, StartMovie, ChangeServer, QuitPlayer, StartPlayer, VOD"},
				{"VOD_15", "SelectMovie, PlayImm, Pause, VRCInterface, StopMovie, StartMovie, ChangeServer, QuitPlayer, StartPlayer, VOD"},
				{"VOD_16", "SelectMovie, PlayImm, Detail, VRCInterface, StartMovie, StartPlayer, VOD"},
				{"VOD_17", "SelectMovie, PlayImm, Detail, Pause, VRCInterface, StartMovie, StartPlayer, VOD"},
				{"VOD_18", "SelectMovie, PlayImm, Detail, VRCInterface, StopMovie, StartMovie, StartPlayer, VOD"},
				{"VOD_19", "SelectMovie, PlayImm, Detail, Pause, VRCInterface, StopMovie, StartMovie, StartPlayer, VOD"},
				{"VOD_20", "SelectMovie, PlayImm, Detail, VRCInterface, StartMovie, QuitPlayer, StartPlayer, VOD"},
				{"VOD_21", "SelectMovie, PlayImm, Detail, Pause, VRCInterface, StartMovie, QuitPlayer, StartPlayer, VOD"},
				{"VOD_22", "SelectMovie, PlayImm, Detail, VRCInterface, StopMovie, StartMovie, QuitPlayer, StartPlayer, VOD"},
				{"VOD_23", "SelectMovie, PlayImm, Detail, Pause, VRCInterface, StopMovie, StartMovie, QuitPlayer, StartPlayer, VOD"},
				{"VOD_24", "SelectMovie, PlayImm, Detail, VRCInterface, StartMovie, ChangeServer, StartPlayer, VOD"},
				{"VOD_25", "SelectMovie, PlayImm, Detail, Pause, VRCInterface, StartMovie, ChangeServer, StartPlayer, VOD"},
				{"VOD_26", "SelectMovie, PlayImm, Detail, VRCInterface, StopMovie, StartMovie, ChangeServer, StartPlayer, VOD"},
				{"VOD_27", "SelectMovie, PlayImm, Detail, Pause, VRCInterface, StopMovie, StartMovie, ChangeServer, StartPlayer, VOD"},
				{"VOD_28", "SelectMovie, PlayImm, Detail, VRCInterface, StartMovie, ChangeServer, QuitPlayer, StartPlayer, VOD"},
				{"VOD_29", "SelectMovie, PlayImm, Detail, Pause, VRCInterface, StartMovie, ChangeServer, QuitPlayer, StartPlayer, VOD"},
				{"VOD_30", "SelectMovie, PlayImm, Detail, VRCInterface, StopMovie, StartMovie, ChangeServer, QuitPlayer, StartPlayer, VOD"},
				{"VOD_31", "SelectMovie, PlayImm, Detail, Pause, VRCInterface, StopMovie, StartMovie, ChangeServer, QuitPlayer, StartPlayer, VOD"}
		};
		
		//staring time
		long initTime = System.currentTimeMillis();
		
		//VOD - UML
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_VOD/uml");
		for (String[] variant : variants) {
			MyRepositoryUtils.commitVariant(eccoService, 
					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0]+"/model")).toPath(), variant[1]);
		}

		//ending time
	    long estimatedTime = System.currentTimeMillis() - initTime;
	    System.out.println("Total execution time: " + estimatedTime + "ms");

	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
