package wesleyk;

import java.io.File;

import at.jku.isse.ecco.EccoService;

public class CommitExample {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		String[][] variants = {
				{"Example_01", "F1, F2, F3"},
				{"Example_02", "F1, F4"},
				{"Example_03", "F1, F2, F4, F5"}
		};

		//Example Approach - UML
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_Example/uml");
		for (String[] variant : variants) {
			MyRepositoryUtils.commitVariant(eccoService, 
					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0])).toPath(), variant[1]);
		}


	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
