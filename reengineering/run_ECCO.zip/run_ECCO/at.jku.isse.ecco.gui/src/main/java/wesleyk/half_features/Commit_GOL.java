package wesleyk.half_features;

import java.io.File;

import at.jku.isse.ecco.EccoService;
import wesleyk.MyRepositoryUtils;

public class Commit_GOL {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		String[][] variants = {
			{"GOL_P00", "GuiBase, ModelBase"},
			{"GOL_P01", "RandomDefaultGenerator, RandomGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P02", "FormDefaultGenerator, FormGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P03", "GeneratorSelection, RandomDefaultGenerator, RandomGenerator, FormGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P04", "GeneratorSelection, FormDefaultGenerator, RandomGenerator, FormGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P05", "Test, RandomDefaultGenerator, RandomGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P06", "Test, FormDefaultGenerator, FormGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P07", "Test, GeneratorSelection, RandomDefaultGenerator, RandomGenerator, FormGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P08", "Test, GeneratorSelection, FormDefaultGenerator, RandomGenerator, FormGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P09", "RandomDefaultGenerator, RandomGenerator, AbstractGenerator, IO, GuiBase, ModelBase"},
			{"GOL_P10", "FormDefaultGenerator, FormGenerator, AbstractGenerator, IO, GuiBase, ModelBase"},
			{"GOL_P11", "GeneratorSelection, RandomDefaultGenerator, RandomGenerator, FormGenerator, AbstractGenerator, IO, GuiBase, ModelBase"},
			{"GOL_P12", "GeneratorSelection, FormDefaultGenerator, RandomGenerator, FormGenerator, AbstractGenerator, IO, GuiBase, ModelBase"},
			{"GOL_P13", "Test, RandomDefaultGenerator, RandomGenerator, AbstractGenerator, IO, GuiBase, ModelBase"},
			{"GOL_P14", "Test, FormDefaultGenerator, FormGenerator, AbstractGenerator, IO, GuiBase, ModelBase"},
			{"GOL_P17", "RandomDefaultGenerator, RandomGenerator, AbstractGenerator, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P18", "FormDefaultGenerator, FormGenerator, AbstractGenerator, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P19", "GeneratorSelection, RandomDefaultGenerator, RandomGenerator, FormGenerator, AbstractGenerator, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P20", "GeneratorSelection, FormDefaultGenerator, RandomGenerator, FormGenerator, AbstractGenerator, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P21", "Test, RandomDefaultGenerator, RandomGenerator, AbstractGenerator, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P22", "Test, FormDefaultGenerator, FormGenerator, AbstractGenerator, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P25", "RandomDefaultGenerator, RandomGenerator, AbstractGenerator, IO, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P26", "FormDefaultGenerator, FormGenerator, AbstractGenerator, IO, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P29", "Test, RandomDefaultGenerator, RandomGenerator, AbstractGenerator, IO, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P30", "Test, FormDefaultGenerator, FormGenerator, AbstractGenerator, IO, PopUpMenu, GuiBase, ModelBase"},
			{"GOL_P33", "UndoRedoGenerator, UndoRedoGuiBase, UndoRedo, RandomDefaultGenerator, RandomGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P34", "UndoRedoGenerator, UndoRedoGuiBase, UndoRedo, FormDefaultGenerator, FormGenerator, AbstractGenerator, GuiBase, ModelBase"},
			{"GOL_P50", "UndoRedoGenerator, UndoRedoTest, UndoRedoGuiBase, UndoRedo, Test, FormDefaultGenerator, FormGenerator, AbstractGenerator, GuiBase, ModelBase"},
		};
	    
		//staring time
		long initTime = System.currentTimeMillis();
	    
		//GOL - UML
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_GOL/uml");
		for (String[] variant : variants) {
			MyRepositoryUtils.commitVariant(eccoService, 
					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0]+"/model")).toPath(), variant[1]);
		}

		//ending time
	    long estimatedTime = System.currentTimeMillis() - initTime;
	    System.out.println("Total execution time: " + estimatedTime + "ms");
	    
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
