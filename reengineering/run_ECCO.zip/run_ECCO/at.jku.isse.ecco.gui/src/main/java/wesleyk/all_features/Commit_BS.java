package wesleyk.all_features;

import java.io.File;

import at.jku.isse.ecco.EccoService;
import wesleyk.MyRepositoryUtils;

public class Commit_BS {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		String[][] variants = {
            {"BS_01", "Base"},
            {"BS_02", "Base, WithdrawLimit"},
            {"BS_03", "Base, Consortium"},
            {"BS_04", "Base, Converter"},
            {"BS_05", "Base, Consortium, Converter"},
            {"BS_06", "Base, WithdrawLimit, Converter"},
            {"BS_07", "Base, WithdrawLimit, Consortium"},
            {"BS_08", "Base, WithdrawLimit, Consortium, Converter"}
		};
	    
		//staring time
		long initTime = System.currentTimeMillis();
	    
		//BS - UML
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_BS/uml");
		for (String[] variant : variants) {
			MyRepositoryUtils.commitVariant(eccoService, 
					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0]+"/model")).toPath(), variant[1]);
		}

		//ending time
	    long estimatedTime = System.currentTimeMillis() - initTime;
	    System.out.println("Total execution time: " + estimatedTime + "ms");
	    
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
