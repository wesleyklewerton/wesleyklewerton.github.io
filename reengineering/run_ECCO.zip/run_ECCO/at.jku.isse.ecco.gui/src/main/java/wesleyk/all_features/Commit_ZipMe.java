package wesleyk.all_features;

import java.io.File;

import at.jku.isse.ecco.EccoService;
import wesleyk.MyRepositoryUtils;

public class Commit_ZipMe {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		String[][] variants = {
				{"ZipMe_00", "Base, Compress"},
				{"ZipMe_01", "Base, CRC, Compress"},
				{"ZipMe_02", "Base, ArchiveCheck, Compress"},
				{"ZipMe_03", "Base, CRC, ArchiveCheck, Compress"},
				{"ZipMe_04", "Base, GZIP, Compress"},
				{"ZipMe_05", "Base, CRC, GZIP, Compress"},
				{"ZipMe_06", "Base, ArchiveCheck, GZIP, Compress"},
				{"ZipMe_07", "Base, CRC, ArchiveCheck, GZIP, Compress"},
				{"ZipMe_08", "Base, Adler32Checksum, Compress"},
				{"ZipMe_09", "Base, CRC, Adler32Checksum, Compress"},
				{"ZipMe_10", "Base, ArchiveCheck, Adler32Checksum, Compress"},
				{"ZipMe_11", "Base, CRC, ArchiveCheck, Adler32Checksum, Compress"},
				{"ZipMe_12", "Base, GZIP, Adler32Checksum, Compress"},
				{"ZipMe_13", "Base, CRC, GZIP, Adler32Checksum, Compress"},
				{"ZipMe_14", "Base, ArchiveCheck, GZIP, Adler32Checksum, Compress"},
				{"ZipMe_15", "Base, CRC, ArchiveCheck, GZIP, Adler32Checksum, Compress"},
				{"ZipMe_16", "Base, Compress, Extract"},
				{"ZipMe_17", "Base, CRC, Compress, Extract"},
				{"ZipMe_18", "Base, ArchiveCheck, Compress, Extract"},
				{"ZipMe_19", "Base, CRC, ArchiveCheck, Compress, Extract"},
				{"ZipMe_20", "Base, GZIP, Compress, Extract"},
				{"ZipMe_21", "Base, CRC, GZIP, Compress, Extract"},
				{"ZipMe_22", "Base, ArchiveCheck, GZIP, Compress, Extract"},
				{"ZipMe_23", "Base, CRC, ArchiveCheck, GZIP, Compress, Extract"},
				{"ZipMe_24", "Base, Adler32Checksum, Compress, Extract"},
				{"ZipMe_25", "Base, CRC, Adler32Checksum, Compress, Extract"},
				{"ZipMe_26", "Base, ArchiveCheck, Adler32Checksum, Compress, Extract"},
				{"ZipMe_27", "Base, CRC, ArchiveCheck, Adler32Checksum, Compress, Extract"},
				{"ZipMe_28", "Base, GZIP, Adler32Checksum, Compress, Extract"},
				{"ZipMe_29", "Base, CRC, GZIP, Adler32Checksum, Compress, Extract"},
				{"ZipMe_30", "Base, ArchiveCheck, GZIP, Adler32Checksum, Compress, Extract"},
				{"ZipMe_31", "Base, CRC, ArchiveCheck, GZIP, Adler32Checksum, Compress, Extract"}
		};
		
		//staring time
		long initTime = System.currentTimeMillis();
		
		//ZipMe - UML
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_ZipMe/uml");

		for (String[] variant : variants) {
			MyRepositoryUtils.commitVariant(eccoService, 
					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0]+"/model")).toPath(), variant[1]);
		}

		//ending time
	    long estimatedTime = System.currentTimeMillis() - initTime;
	    System.out.println("Total execution time: " + estimatedTime + "ms");
	    
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
