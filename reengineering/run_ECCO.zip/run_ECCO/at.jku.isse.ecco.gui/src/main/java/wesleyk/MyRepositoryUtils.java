package wesleyk;

import java.io.File;
import java.nio.file.Path;
import java.util.Collection;

import at.jku.isse.ecco.EccoService;
import at.jku.isse.ecco.core.Association;
import at.jku.isse.ecco.core.Commit;
import at.jku.isse.ecco.tree.Node;

public class MyRepositoryUtils {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		EccoService eccoService = getRepository("/home/wesley/workspaceMars/ecco/repository_programmatically");
//		commitVariant(eccoService, "canvas, line");
		
		
		//UML Banking System
		commitVariant(eccoService, 
				(new File("/home/wesley/workspaceMars/ecco/variants_models_bs/bs2/")).toPath(), 
				"Base");
		commitVariant(eccoService,
				(new File("/home/wesley/workspaceMars/ecco/variants_models_bs/bs6/")).toPath(), 
				"Base, Withdraw");
		commitVariant(eccoService, 
				(new File("/home/wesley/workspaceMars/ecco/variants_models_bs/bs5/")).toPath(), 
				"Base, Consortium");
		commitVariant(eccoService, 
				(new File("/home/wesley/workspaceMars/ecco/variants_models_bs/bs8/")).toPath(), 
				"Base, Converter");
		commitVariant(eccoService, 
				(new File("/home/wesley/workspaceMars/ecco/variants_models_bs/bs3/")).toPath(), 
				"Base, Consortium, Converter");
		commitVariant(eccoService, 
				(new File("/home/wesley/workspaceMars/ecco/variants_models_bs/bs4/")).toPath(), 
				"Base, Withdraw, Converter");
		commitVariant(eccoService, 
				(new File("/home/wesley/workspaceMars/ecco/variants_models_bs/bs7/")).toPath(), 
				"Base, Withdraw, Consortium");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceMars/ecco/variants_models_bs/bs1/")).toPath(), 
//				"Base, Withdraw, Consortium, Converter");

		
		//UML DPL
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/ecco/variants_models_dpl/P01")).toPath(), 
//				"canvas, line");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/ecco/variants_models_dpl/P02")).toPath(), 
//				"canvas, line, rect");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/ecco/variants_models_dpl/P03")).toPath(), 
//				"canvas, rect");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/ecco/variants_models_dpl/P05")).toPath(), 
//				"canvas, line, color");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/ecco/variants_models_dpl/P06")).toPath(), 
//				"canvas, rect, color");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/ecco/variants_models_dpl/P07")).toPath(), 
//				"canvas, line, wipe");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/ecco/variants_models_dpl/P09")).toPath(), 
//				"canvas, rect, wipe");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/ecco/variants_models_dpl/P14")).toPath(), 
//				"canvas, rect, color, fill");
		
		//JAVA DPL
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceMars/ecco/variants/DPL_java/P01")).toPath(), 
//				"canvas, line");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceMars/ecco/variants/DPL_java/P02")).toPath(), 
//				"canvas, line, rect");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/CaseStudies/DPL_P03/src")).toPath(), 
//				"canvas, rect");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/CaseStudies/DPL_P05/src")).toPath(), 
//				"canvas, line, color");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/CaseStudies/DPL_P06/src")).toPath(), 
//				"canvas, rect, color");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/CaseStudies/DPL_P07/src")).toPath(), 
//				"canvas, line, wipe");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/CaseStudies/DPL_P09/src")).toPath(), 
//				"canvas, rect, wipe");
//		commitVariant(eccoService, 
//				(new File("/home/wesley/workspaceKepler/CaseStudies/DPL_P14/src")).toPath(), 
//				"canvas, rect, color, fill");

	}

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
	
	public static EccoService getRepository(String url){
		File baseDir = new File(url);
		EccoService eccoService = new EccoService(baseDir.toPath());
		
		if(eccoService.detectRepository(baseDir.toPath())){
			eccoService.init();
		}else{
			eccoService = createRepository(url);
		}
		
		return eccoService;
	}

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public static EccoService createRepository(String url){
		File baseDir = new File(url);
		EccoService eccoService = new EccoService(baseDir.toPath());
		
		if( eccoService.createRepository() ){
			System.out.println("Repository created successfully");
			return eccoService;
		}
			
		System.out.println("ERROR on creating the repository");
		return null;
	}

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public static void commitVariant(EccoService eccoService, String configuration){
		System.out.println("\n-------------------------\n");
		Commit cm = eccoService.commit(configuration);
		System.out.println( cm.toString() );
		System.out.println("\n-------------------------\n");
	}
	
	public static void commitVariant(EccoService eccoService, Path baseDir, String configuration){
		System.out.println("\n-------------------------\n");
		eccoService.setBaseDir(baseDir);
		Commit cm = eccoService.commit(configuration);
		System.out.println( cm.toString() );
		System.out.println("\n-------------------------\n");
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void useRepository(){
		File baseDir = new File("/home/wesley/workspaceMars/ecco/repository_ecco");
		
		// ECCO Service
		EccoService eccoService = new EccoService(baseDir.toPath()); // create ecco service
		eccoService.detectRepository(baseDir.toPath()); // detect any existing repository
		eccoService.init(); //eccoService.createRepository();
		
		System.out.println("\n-------------------------\n");
		
		//here we call the method to deal/export with the associations
		Collection<Association> associations = eccoService.getAssociations();
		ExportTraceability.exportTraceability(associations);
		
		System.out.println("\n-------------------------\n");
	}

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
	
	public static void recursiveVisitArtefacts(Node node) {
		if (node.getArtifact() != null) {
			//faz algo com o artefato
			System.out.println(node.getArtifact());
		}
		// traverse into children
		for (Node child : node.getChildren()) {
			recursiveVisitArtefacts(child);
		}
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	
	public static void getNodeByArtifactName(Node node, String name) {
		if (node.getArtifact() != null) {
			if(node.getArtifact().toString().equals(name)){
				System.out.println("achou: "+node.getArtifact().toString());
			}
		}
		// traverse into children
		for (Node child : node.getChildren()) {
			getNodeByArtifactName(child, name);
		}
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
