package wesleyk.half_features;

import java.io.File;

import at.jku.isse.ecco.EccoService;
import wesleyk.MyRepositoryUtils;

public class Commit_MMv2 {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		String[][] variants = {
			{"MMv2_P01", "MobileMedia,device_screen_132x176,includePhoto"},
			{"MMv2_P02", "MobileMedia,device_screen_128x149,includePhoto"},
			{"MMv2_P03", "MobileMedia,device_screen_176x205,includePhoto"},
			{"MMv2_P04", "MobileMedia,device_screen_132x176,includeSorting,includePhoto"},
		};
	    
		//staring time
		long initTime = System.currentTimeMillis();
	    
		//MMv2 - UML
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_MMv2/uml");
		for (String[] variant : variants) {
			MyRepositoryUtils.commitVariant(eccoService, 
					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0]+"/model")).toPath(), variant[1]);
		}

		//ending time
	    long estimatedTime = System.currentTimeMillis() - initTime;
	    System.out.println("Total execution time: " + estimatedTime + "ms");
	    
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
