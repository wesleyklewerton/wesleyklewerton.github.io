package wesleyk.half_features;

import java.io.File;

import at.jku.isse.ecco.EccoService;
import wesleyk.MyRepositoryUtils;

public class Commit_MMv5 {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	public static void main(String[] args) {
		
		String[][] variants = {
			{"MMv5_P01", "MobileMedia,device_screen_132x176,includePhoto"},
			{"MMv5_P02", "MobileMedia,device_screen_128x149,includePhoto"},
			{"MMv5_P03", "MobileMedia,device_screen_176x205,includePhoto"},
			{"MMv5_P04", "MobileMedia,device_screen_132x176,includeSmsFeature,includePhoto"},
			{"MMv5_P05", "MobileMedia,device_screen_128x149,includeSmsFeature,includePhoto"},
			{"MMv5_P06", "MobileMedia,device_screen_176x205,includeSmsFeature,includePhoto"},
			{"MMv5_P07", "MobileMedia,device_screen_132x176,includeCopyMedia,includePhoto"},
			{"MMv5_P08", "MobileMedia,device_screen_128x149,includeCopyMedia,includePhoto"},
			{"MMv5_P09", "MobileMedia,device_screen_176x205,includeCopyMedia,includePhoto"},
			{"MMv5_P10", "MobileMedia,device_screen_132x176,includeCopyMedia,includeSmsFeature,includePhoto"},
			{"MMv5_P11", "MobileMedia,device_screen_128x149,includeCopyMedia,includeSmsFeature,includePhoto"},
			{"MMv5_P12", "MobileMedia,device_screen_176x205,includeCopyMedia,includeSmsFeature,includePhoto"},
			{"MMv5_P13", "MobileMedia,device_screen_132x176,includeFavourites,includePhoto"},
			{"MMv5_P14", "MobileMedia,device_screen_128x149,includeFavourites,includePhoto"},
			{"MMv5_P15", "MobileMedia,device_screen_176x205,includeFavourites,includePhoto"},
			{"MMv5_P16", "MobileMedia,device_screen_132x176,includeFavourites,includeSmsFeature,includePhoto"},
			{"MMv5_P17", "MobileMedia,device_screen_128x149,includeFavourites,includeSmsFeature,includePhoto"},
			{"MMv5_P18", "MobileMedia,device_screen_176x205,includeFavourites,includeSmsFeature,includePhoto"},
			{"MMv5_P19", "MobileMedia,device_screen_132x176,includeFavourites,includeCopyMedia,includePhoto"},
			{"MMv5_P20", "MobileMedia,device_screen_128x149,includeFavourites,includeCopyMedia,includePhoto"},
			{"MMv5_P21", "MobileMedia,device_screen_176x205,includeFavourites,includeCopyMedia,includePhoto"},
			{"MMv5_P25", "MobileMedia,device_screen_132x176,includeSorting,includePhoto"},
			{"MMv5_P26", "MobileMedia,device_screen_128x149,includeSorting,includePhoto"},
			{"MMv5_P27", "MobileMedia,device_screen_176x205,includeSorting,includePhoto"},
			{"MMv5_P28", "MobileMedia,device_screen_132x176,includeSorting,includeSmsFeature,includePhoto"},
			{"MMv5_P29", "MobileMedia,device_screen_128x149,includeSorting,includeSmsFeature,includePhoto"},
			{"MMv5_P30", "MobileMedia,device_screen_176x205,includeSorting,includeSmsFeature,includePhoto"},
			{"MMv5_P31", "MobileMedia,device_screen_132x176,includeSorting,includeCopyMedia,includePhoto"},
			{"MMv5_P32", "MobileMedia,device_screen_128x149,includeSorting,includeCopyMedia,includePhoto"},
			{"MMv5_P33", "MobileMedia,device_screen_176x205,includeSorting,includeCopyMedia,includePhoto"},
			{"MMv5_P37", "MobileMedia,device_screen_132x176,includeSorting,includeFavourites,includePhoto"},
			{"MMv5_P38", "MobileMedia,device_screen_128x149,includeSorting,includeFavourites,includePhoto"},
			{"MMv5_P39", "MobileMedia,device_screen_176x205,includeSorting,includeFavourites,includePhoto"},
		};
	    
		//staring time
		long initTime = System.currentTimeMillis();
	    
		//MMv5 - UML
		EccoService eccoService = MyRepositoryUtils.getRepository("/home/wesley/workspaceMars/ecco/repository_MMv5/uml");
		for (String[] variant : variants) {
			MyRepositoryUtils.commitVariant(eccoService, 
					(new File("/home/wesley/workspaceNeon/CaseStudies/"+variant[0]+"/model")).toPath(), variant[1]);
		}

		//ending time
	    long estimatedTime = System.currentTimeMillis() - initTime;
	    System.out.println("Total execution time: " + estimatedTime + "ms");
	    
	}
	
	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

}
