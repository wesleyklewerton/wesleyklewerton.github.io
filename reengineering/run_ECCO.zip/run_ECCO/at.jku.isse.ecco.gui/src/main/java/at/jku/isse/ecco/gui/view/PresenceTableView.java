package at.jku.isse.ecco.gui.view;

import at.jku.isse.ecco.EccoService;
import at.jku.isse.ecco.listener.RepositoryListener;
import javafx.scene.layout.BorderPane;

public class PresenceTableView extends BorderPane implements RepositoryListener {

	public PresenceTableView(EccoService eccoService) {

	}

}
