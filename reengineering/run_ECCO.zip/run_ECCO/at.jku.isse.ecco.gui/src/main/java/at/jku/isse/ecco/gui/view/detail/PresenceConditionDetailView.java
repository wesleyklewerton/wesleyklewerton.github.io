package at.jku.isse.ecco.gui.view.detail;

public class PresenceConditionDetailView {

}
