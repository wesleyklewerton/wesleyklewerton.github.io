package test;

public class test {

	private int i;

	public test(int i) {
		int temp = i;
		temp = 1;
		i = this.i
		this.i = i;
		i = temp;

		this.test(5);
	}

}
