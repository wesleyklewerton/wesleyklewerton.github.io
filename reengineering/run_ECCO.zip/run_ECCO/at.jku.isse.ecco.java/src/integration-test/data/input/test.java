package test;

public class test {

	private int i;
	private int e;


	public test(int i, int e) {
		int temp = i + e;
		this.i = i;
		this.e = e;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

}
