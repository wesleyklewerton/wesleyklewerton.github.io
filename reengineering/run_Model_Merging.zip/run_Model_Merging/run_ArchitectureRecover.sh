#!/bin/bash  


## declare an array variable
declare -a arr=("BS" "DPL" "MMv1" "VOD" "ZipMe")

## now loop through the above array
for case_study in "${arr[@]}"
do
   echo "Case Study: $case_study"
   # or do whatever with individual element of the array
   for run_number in $(seq 0 29); do 
       #tar xzf "myfile-1.0$i" || exit 1
       echo "$case_study / Run number: $run_number"
       java -Xmx14g -d64 -cp ArchitectureRecover.jar wesleyk.jmetal.run.GA_main "all_features/$case_study" "$run_number"  >> ./models_output/"$case_study"_run_output.txt
    done
done


## declare an array variable
declare -a arr=("GOL" "MMv2" "MMv3" "MMv4" "MMv5")

## now loop through the above array
for case_study in "${arr[@]}"
do
   echo "Case Study: $case_study"
   # or do whatever with individual element of the array
   for run_number in $(seq 0 29); do 
       #tar xzf "myfile-1.0$i" || exit 1
       echo "$case_study / Run number: $run_number"
       java -Xmx14g -d64 -cp ArchitectureRecover.jar wesleyk.jmetal.run.GA_main "half_features/$case_study" "$run_number"  >> ./models_output/"$case_study"_run_output.txt
    done
done
