#!/bin/bash  

## declare an array variable
declare -a arr=("BS" "DPL" "MMv1" "VOD" "ZipMe" "GOL" "MMv2" "MMv3" "MMv4" "MMv5")

## loop through the above array
for case_study in "${arr[@]}"
do
   echo "Case Study: $case_study"
   for run_number in $(seq 0 29); do 
       echo "$case_study / Run number: $run_number"
       java -Xmx7g -d64 -cp ecj_fm.jar run.RunNSGAIIFM_3obj_tese "$case_study" "$run_number"  >> output/"$case_study"_RunNSGAIIFM_3obj.txt
    done
done
