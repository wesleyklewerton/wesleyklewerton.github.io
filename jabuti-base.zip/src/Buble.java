
import java.util.Vector;

public class Buble {
    private Vector elements;
    
    public Buble() {
        elements = new Vector();
    }
    
    //   put element into array
    public void add(int value) throws IllegalArgumentException {
        if (value<0)
            throw new IllegalArgumentException();
        elements.add(new Integer(value));
    }
    
    //   displays array contents
    public void display() {
        for (int i=0; i<elements.size(); i++)
            System.out.print(elements.get(i) + " ");
        System.out.println("");
    }
    
    public void bubbleSort() {
        int out, in;
        for (out = elements.size()-1; out > 0; out--)
            for (in = 0; in < out; in++) {  
                Integer x=(Integer) elements.get(in);
                Integer y=(Integer) elements.get(in+1);
                if (x.intValue()>y.intValue())  
                    swap(in, in + 1); 
            }
    }
    
    private void swap(int i, int j) {
        Integer temp = (Integer) elements.get(i);
        elements.setElementAt(elements.get(j), i);
        elements.setElementAt(temp, j);
    }
    
    public int get(int i) 
    {
        Integer value=(Integer) elements.get(i);
        return value.intValue();
    }
    
    public int size() 
    {
        return this.elements.size();
    }
    
    public String toString() 
    {
        String result="";
        for (int i=0; i<size(); i++)
            result+=get(i)+",";
        return result;
    }
    
    public boolean equals(Object o) 
    {
        if (!(o instanceof Buble)) return false;
        Buble auxi=(Buble) o;
        if (auxi.size()!=size()) return false;
        for (int i=0; i<size(); i++)
            if (auxi.get(i)!=get(i))
                return false;
        return true;
    }
} 