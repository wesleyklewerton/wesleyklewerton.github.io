import org.junit.Test;

import org.junit.Before;

public class Teste {

	@Test
	public void casoTeste_1() {
		Buble b = new Buble();
		b.add(3);
	}

	/*
	@Test
	public void casoTeste_2() {
		Buble b = new Buble();
		b.display();
	}
	*/

}
