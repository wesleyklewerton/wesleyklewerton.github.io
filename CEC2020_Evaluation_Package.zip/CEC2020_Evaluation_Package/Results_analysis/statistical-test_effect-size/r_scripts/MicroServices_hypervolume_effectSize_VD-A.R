# in the command line: Rscript script.R
# https://rdrr.io/cran/effsize/man/VD.A.html
# https://cran.r-project.org/web/packages/effsize/effsize.pdf

system <- "MicroServices"
setwd("/home/wesley/Dropbox/2020_CEC_willian/CEC2020_statistical-test_effect-size/results")

library(effsize)

#treatment
NSGAII <- c(0.029241, 0.030405, 0.027944, 0.034889, 0.037389, 0.030828, 0.034889, 0.007667, 0.034532, 0.030389, 0.027410, 0.049538, 0.031667, 0.031344, 0.026185, 0.004333, 0.027944, 0.029810, 0.034810, 0.034889, 0.033522, 0.004333, 0.034889, 0.035238, 0.004333, 0.026278, 0.030405, 0.031667, 0.024333, 0.004333)

#control
SPEA2 <- c(0.009333, 0.007667, 0.031667, 0.007667, 0.007667, 0.007667, 0.007667, 0.009333, 0.028022, 0.009333, 0.007667, 0.007667, 0.009333, 0.007667, 0.004333, 0.009333, 0.009333, 0.009333, 0.007667, 0.009333, 0.009333, 0.007667, 0.007667, 0.007667, 0.023211, 0.031667, 0.024333, 0.007667, 0.031667, 0.009333)


sink(paste(system, "_hypervolume_effectSize_VD-A.txt", sep = ""))

print("VD.A: Vargha and Delaney A measure")
## compute Vargha and Delaney A
## treatment and control
VD.A(NSGAII,SPEA2)

#The magnitude is assessed using the thresholds provided in (Romano 2006), i.e. |d|<0.147"negligible",|d|<0.33"small", |d|<0.474"medium", otherwise"large"

sink()



