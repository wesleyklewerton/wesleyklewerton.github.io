#in the command line: Rscript script.R

system <- "MicroServices"
setwd("/home/wesley/Dropbox/2020_CEC_willian/CEC2020_statistical-test_effect-size/results")

NSGAII <- c(51927, 46780, 46726, 41891, 51579, 51633, 41792, 46502, 48357, 48391, 51216, 44988, 48397, 49646, 54643, 34720, 42099, 47869, 58251, 42456, 50473, 35213, 42546, 50319, 34966, 47525, 46739, 43311, 50885, 39050)
SPEA2 <- c(569278, 420702, 472812, 507223, 531553, 537126, 470963, 557679, 148169, 513894, 481356, 538077, 574223, 541485, 103377, 585090, 495777, 579455, 505596, 463961, 576904, 534052, 545330, 534781, 136395, 495435, 529011, 504805, 446537, 580170)

result <- wilcox.test(NSGAII, SPEA2)
m <- data.frame(result$statistic,result$p.value)
write.csv2(m, file=paste(system, "_runtime_pvalue.csv", sep = ""))

pdf(file=paste(system, "_runtime_boxplot.pdf", sep = ""))
par(cex.lab=1.8)
par(cex.axis=1.8)
boxplot(NSGAII, SPEA2,  names=c("NSGA-II", "SPEA2"))
