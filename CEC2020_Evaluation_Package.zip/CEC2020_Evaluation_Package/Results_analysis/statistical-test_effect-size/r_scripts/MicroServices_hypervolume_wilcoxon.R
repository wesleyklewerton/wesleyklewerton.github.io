#in the command line: Rscript script.R

system <- "MicroServices"
setwd("/home/wesley/Dropbox/2020_CEC_willian/CEC2020_statistical-test_effect-size/results")

NSGAII <- c(0.029241, 0.030405, 0.027944, 0.034889, 0.037389, 0.030828, 0.034889, 0.007667, 0.034532, 0.030389, 0.027410, 0.049538, 0.031667, 0.031344, 0.026185, 0.004333, 0.027944, 0.029810, 0.034810, 0.034889, 0.033522, 0.004333, 0.034889, 0.035238, 0.004333, 0.026278, 0.030405, 0.031667, 0.024333, 0.004333)
SPEA2 <- c(0.009333, 0.007667, 0.031667, 0.007667, 0.007667, 0.007667, 0.007667, 0.009333, 0.028022, 0.009333, 0.007667, 0.007667, 0.009333, 0.007667, 0.004333, 0.009333, 0.009333, 0.009333, 0.007667, 0.009333, 0.009333, 0.007667, 0.007667, 0.007667, 0.023211, 0.031667, 0.024333, 0.007667, 0.031667, 0.009333)

result <- wilcox.test(NSGAII, SPEA2)
m <- data.frame(result$statistic,result$p.value)
write.csv2(m, file=paste(system, "_hypervolume_pvalue.csv", sep = ""))

pdf(file=paste(system, "_hypervolume_boxplot.pdf", sep = ""))
par(cex.lab=1.8)
par(cex.axis=1.8)
boxplot(NSGAII, SPEA2,  names=c("NSGA-II", "SPEA2"))
