#!/bin/sh

reference="1.1 1.1 1.1"

FILES=./raw_data_30runs/*
for f in $FILES
do
	echo "Processing $f"
	echo $f >> ./hypervolume.txt
	./hv-1.3-src/hv -r "$reference" $f >> ./hypervolume.txt
	echo "\n" >> ./hypervolume.txt
done
