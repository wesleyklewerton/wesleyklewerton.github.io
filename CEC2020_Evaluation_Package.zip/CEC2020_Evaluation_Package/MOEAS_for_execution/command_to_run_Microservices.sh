# CEC-2020
# The input artifacts are in the folder "new_models"
# Uncomment the desired line below and use "./command_to_run_Microservices.sh" in the prompt to run the algorithm

# --- Uncomment below to run NSGAII --- 
#java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj MicroServices > output/RunNSGAIIFM_3obj_MicroServices.txt

# --- Uncomment below to run SPEA2 --- 
#java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunSPEA2FM_3obj MicroServices > output/RunSPEA2FM_3obj_MicroServices.txt

