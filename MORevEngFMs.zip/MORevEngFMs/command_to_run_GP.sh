#!/bin/bash  

java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj argouml > output/RunGPFM_1obj_argouml.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj dpl > output/RunGPFM_1obj_dpl.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj gol > output/RunGPFM_1obj_gol.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj vod > output/RunGPFM_1obj_vod.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj zipme > output/RunGPFM_1obj_zipme.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj mm_var1 > output/RunGPFM_1obj_mm_var1.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj mm_var2 > output/RunGPFM_1obj_mm_var2.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj mm_var3 > output/RunGPFM_1obj_mm_var3.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj mm_var4 > output/RunGPFM_1obj_mm_var4.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj mm_var5 > output/RunGPFM_1obj_mm_var5.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj mm_var6 > output/RunGPFM_1obj_mm_var6.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunGPFM_1obj mm_var7 > output/RunGPFM_1obj_mm_var7.txt &
