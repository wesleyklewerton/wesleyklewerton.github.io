#!/bin/bash  

java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj argouml > output/RunNSGAIIFM_3obj_argouml.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj dpl > output/RunNSGAIIFM_3obj_dpl.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj gol > output/RunNSGAIIFM_3obj_gol.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj vod > output/RunNSGAIIFM_3obj_vod.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj zipme > output/RunNSGAIIFM_3obj_zipme.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj mm_var1 > output/RunNSGAIIFM_3obj_mm_var1.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj mm_var2 > output/RunNSGAIIFM_3obj_mm_var2.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj mm_var3 > output/RunNSGAIIFM_3obj_mm_var3.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj mm_var4 > output/RunNSGAIIFM_3obj_mm_var4.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj mm_var5 > output/RunNSGAIIFM_3obj_mm_var5.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj mm_var6 > output/RunNSGAIIFM_3obj_mm_var6.txt &
java -Xmx6g -d64 -classpath dist/ecj_fm.jar run.RunNSGAIIFM_3obj mm_var7 > output/RunNSGAIIFM_3obj_mm_var7.txt &
