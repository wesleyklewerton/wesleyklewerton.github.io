OBSERVA��ES

Copiar o mujava para o diret�rio pessoal: www.inf.ufpr.br/wesleyk

Corrigir o mujava.config: diret�rio que aparece quando voc� d� pwd

Executar os comandos DE DENTRO DA PASTA mujava
	Primeiro gerar os mutantes (Ser�o criados na pasta MuJava_HOME\result)
		java -cp mujava-v2.jar:adaptedOJ.jar:/usr/lib/jvm/java-1.6.0-openjdk/lib/tools.jar:classes/:src/:/usr/lib/jvm/java-1.6.0-openjdk/jre/lib/rt.jar mujava.gui.GenMutantsMain

	Criar e complilar os TestCases
		javac -J-Xmx128m Teste.java

	Depois executar os mutantes
		java -cp mujava-v2.jar:adaptedOJ.jar:/usr/lib/jvm/java-1.6.0-openjdk/lib/tools.jar:/usr/lib/jvm/java-1.6.0-openjdk/jre/lib/rt.jar mujava.gui.RunTestMain

Vamos executar o primeiro testcase com o segundo comentado

Alguns mutantes entram em loop infinito: MUTANTE AN�MALO.
Solu��o: retirar o diret�rio do mutante que travou a execu��o da pasta Mu_JavaHome\result.
Isso j� atualiza o n�mero de mutantes.
5% a 20% s�o equivalentes

CURIOSIDADE
A ferramenta j� funciona como plugin do Eclipse. MuClipse.
