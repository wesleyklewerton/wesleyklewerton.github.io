public class Teste {

	// MATA O AOIU_1
	public String test1() {
		String result = "";
		Buble b = new Buble();
		b.add(10);
		result = String.valueOf(b.get(0));
		return result;
	}

	/*
	public String test2() {
		String result = "";
		Buble b = new Buble();
		b.add(1);
		b.add(20);
		b.add(5);
		b.add(10);
		b.bubbleSort();
		for (int i = 0; i < b.size(); i++) {
			result = result + String.valueOf(b.get(i));
		}
		return result;
	}
	*/

}
