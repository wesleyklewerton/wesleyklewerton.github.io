import java.awt.Graphics; 

public abstract  class  Shape {
	

	public abstract void paint(Graphics g);


}
