
/**
 * DPL Main.java
 * @author Roberto E. Lopez-Herrejon
 * Main class of Draw Product Line
 * SEP SPL Course July 2010
 */

import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*; 

@SuppressWarnings("serial")

public  class  Main  extends JFrame {
	

	// *** Initialize constants

	// Window size
	private static final int WIDTH = 800;

	
	private static final int HEIGHT = 600;

	

	// Pane declaration. No need to use more panels or canvas.
	protected JPanel toolPanel = new JPanel();

	
	protected Canvas canvas = new Canvas();

	

	// *** Initialization of atomic elements
	 private void  initAtoms__wrappee__Base  () {
		
	}

	

	 private void  initAtoms__wrappee__Limpa  () {
		initAtoms__wrappee__Base();
		wipeButton = new JButton(wipeText);
	}

	
	
	 private void  initAtoms__wrappee__Retangulo  () {
		initAtoms__wrappee__Limpa();
		rectButton = new JButton(rectText);
	}

	
	
	public void initAtoms() {
		initAtoms__wrappee__Retangulo();
		lineButton = new JButton(lineText);
	}

	 // initAtoms

	// Layout components declaration
	private Container contentPane;

	

	/** Initializes layout . No need to change */
	public void initLayout() {
		contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		toolPanel.setLayout(new BoxLayout(toolPanel, BoxLayout.Y_AXIS));
	}

	

	/** Initializes the content pane */
	 private void  initContentPane__wrappee__Base  () {
		contentPane.add(toolPanel, BorderLayout.WEST);
		contentPane.add(canvas, BorderLayout.CENTER);
		
	}

	
	
	
	/** Initializes the content pane */
	 private void  initContentPane__wrappee__Limpa  () {
		initContentPane__wrappee__Base();
		toolPanel.add(wipeButton);
	}

	
	
	 private void  initContentPane__wrappee__Retangulo  () {
		toolPanel.add(rectButton);
		initContentPane__wrappee__Limpa();
	}

	

	public void initContentPane() {
		toolPanel.add(lineButton);
		initContentPane__wrappee__Retangulo();
	}

	 // initContentPane

	/** Initializes the listeners for the buttons and the combo box */
	 private void  initListeners__wrappee__Base  () {
		
	}

	 // initContentPane
	
	/** Initializes the listeners for the buttons and the combo box */
	 private void  initListeners__wrappee__Limpa  () {
		initListeners__wrappee__Base();
		wipeButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				canvas.wipe();
			}
		});
	}

	
	
	 private void  initListeners__wrappee__Retangulo  () {
		initListeners__wrappee__Limpa();
		rectButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				canvas.selectedFigure(Canvas.FigureTypes.RECT);
			}
		});
	}

	
	
	public void initListeners() {
		initListeners__wrappee__Retangulo();
		lineButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				canvas.selectedFigure(Canvas.FigureTypes.LINE);
			}
		});
	}

	 // of initListeners

	// Initializes entire containment hierarchy
	public void init() {
		initAtoms();
		initLayout();
		initContentPane();
		initListeners();
	}

	

	/* Constructor. No need to modify */
	public Main(String appTitle) {
		super(appTitle);
		init();
		addWindowListener( new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		setVisible(true);
		setSize(WIDTH, HEIGHT);
		setResizable(true);
		validate();
	}

	 // Main
																																																									// constructor

	/** main method */
	public static void main(String[] args) {
		new Main("Draw Product Line");
	}

	
	
	private static final String wipeText = "   Limpar   ";

	
	JButton wipeButton;

	

	private static final String rectText = "Retângulo";

	
	private JButton rectButton;

	

	private static final String lineText = "    Linha    ";

	
	private JButton lineButton;


}
