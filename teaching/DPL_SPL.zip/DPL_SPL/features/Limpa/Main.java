/**
 * DPL Main.java
 * @author Roberto E. Lopez-Herrejon
 * Main class of Draw Product Line
 * SEP SPL Course July 2010
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

@SuppressWarnings("serial")  

public class Main extends JFrame {
	
	private static final String wipeText = "   Limpar   ";
	JButton wipeButton;

	public void initAtoms() {
		original();
		wipeButton = new JButton(wipeText);
	}
	
	
	/** Initializes the content pane */
	public void initContentPane() {
		original();
		toolPanel.add(wipeButton);
	} // initContentPane
	
	/** Initializes the listeners for the buttons and the combo box */
	public void initListeners() {
		original();
		wipeButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) {
				canvas.wipe();
			}
		});
	} // of initListeners
	
}