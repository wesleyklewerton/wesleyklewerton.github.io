package at.jku.isse.fm.node.relation;

import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.data.ProductSet;
import at.jku.isse.fm.node.Relation;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class Alternative extends Relation {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Alternative";
	}

	@Override
	protected void myCheckConstraints(EvolutionState state) {
		super.myCheckConstraints(state);

		if (!(this.parent instanceof Feature)) {
			state.output.fatal("[FME] Alternative node must have a Feature as a parent! Parent: " + this.parent);
		}

		if (this.children.length < 1) {
			state.output.fatal("[FME] Alternative node must have at least one child! Number of children: " + this.children.length);
		}

		if (((GPNode) this.parent).children[this.argposition] != this) {
			state.output.fatal("[FME] Alternative node has wrong argposition that does not match its position in its parent's children array! Argposition: " + this.argposition);
		}

		for (GPNode child : this.children) {
			if (!(child instanceof Feature)) {
				state.output.fatal("[FME] Alternative node must have only Features as children! Child: " + child);
			}
		}
	}

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {
		this.myCheckConstraints(state);

		ProductSet ps = (ProductSet) input;
		ProductSet[] clones = new ProductSet[this.children.length - 1];

		for (int i = 0; i < this.children.length - 1; i++) { // all but the last child (the last alternative)
			// clone the ps
			ProductSet cloned_ps = (ProductSet) ps.clone();
			// give cloned ps to child
			this.children[i].eval(state, thread, cloned_ps, stack, individual, problem);
			// add clone to list
			clones[i] = cloned_ps;

			ps.features.addAll(cloned_ps.features);
		}

		// process the last child by giving it the original ps as input
		this.children[this.children.length - 1].eval(state, thread, ps, stack, individual, problem);

		// add clones to original ps
		for (int i = 0; i < clones.length; i++) {
			ps.products.addAll(clones[i].products);
		}

	}

}
