package at.jku.isse.fm.node.relation;

import java.util.HashSet;
import java.util.Set;

import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.data.Product;
import at.jku.isse.fm.data.ProductSet;
import at.jku.isse.fm.node.Relation;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPTree;

public class Root extends Relation {

	private static final long serialVersionUID = 1L;

	// TODO: this is only used for comparing my evaluation results to the ones from FAMA if available. remove for better performance!
	public Set<Product> products = new HashSet<Product>();

	@Override
	public String toString() {
		return "Root";
	}

	@Override
	public int expectedChildren() {
		return 1;
	}

	@Override
	protected void myCheckConstraints(final EvolutionState state) {
		super.myCheckConstraints(state);

		if (!(this.parent instanceof GPTree)) {
			state.output.fatal("[FME] Root node must have the Tree as parent!");
		}

		if (this.children.length != 1) {
			state.output.fatal("[FME] Root node must have exactly one child! Number of children: " + this.children.length);
		}

		if (!(this.children[0] instanceof Feature)) {
			state.output.fatal("[FME] Root node must have a Feature as a child! Child: " + this.children[0]);
		}
	}

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {
		this.myCheckConstraints(state);

		ProductSet ps = (ProductSet) (input);

		if (ps.products.size() != 0) {
			state.output.fatal("[FME] Error evaluating individual: initial product set was not empty (" + ps.products.size() + "). " + ps.products);
		}

		ps.products.add(new Product()); // initially add empty product

		children[0].eval(state, thread, input, stack, individual, problem);
	}

}
