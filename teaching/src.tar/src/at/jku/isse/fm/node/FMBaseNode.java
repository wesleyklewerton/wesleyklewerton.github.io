package at.jku.isse.fm.node;

import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import ec.util.Parameter;

/**
 * Abstract base class for feature model nodes similar to GPNode from ECJ.
 */
public abstract class FMBaseNode extends GPNode {

	private static final long serialVersionUID = 1L;

	@Override
	public abstract String toString();

	@Override
	public abstract void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem);

	@Override
	public void checkConstraints(final EvolutionState state, final int tree, final GPIndividual typicalIndividual, final Parameter individualBase) {
		super.checkConstraints(state, tree, typicalIndividual, individualBase);
	}

	@Override
	public int expectedChildren() {
		return super.expectedChildren();
	}

	protected void myCheckConstraints(final EvolutionState state) {
		if (this.parent instanceof GPNode) {
			GPNode parentnode = (GPNode) this.parent;
			if (parentnode.children[this.argposition] != this) {
				int true_pos = -1;
				for (int i = 0; i < parentnode.children.length; i++) {
					if (parentnode.children[i] == this)
						true_pos = i;
				}
				state.output.fatal("[FME] Error in tree structure: parent.children[argposition] != this; this.argposition=" + this.argposition + ", true position: " + true_pos);
			}
		}

		for (GPNode n : this.children) {
			if (n == null) {
				state.output.fatal("[FME] Error in tree structure: child must not be null!");
			}
		}
	}

}
