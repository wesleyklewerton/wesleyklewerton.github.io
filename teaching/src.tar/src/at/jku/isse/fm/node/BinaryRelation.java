package at.jku.isse.fm.node;

import ec.EvolutionState;

public abstract class BinaryRelation extends Relation {

	private static final long serialVersionUID = 1L;

	@Override
	protected void myCheckConstraints(final EvolutionState state) {
		super.myCheckConstraints(state);

		if (this.children.length != 1) {
			state.output.fatal("[FME] A binary relation node must have exactly one child! Number of children: " + this.children.length);
		}
	}

}
