package at.jku.isse.fm.node;

import at.jku.isse.fm.data.Feature;
import ec.EvolutionState;
import ec.gp.GPNode;

public abstract class Relation extends FMBaseNode {

	private static final long serialVersionUID = 1L;

	@Override
	protected void myCheckConstraints(final EvolutionState state) {
		super.myCheckConstraints(state);

		for (GPNode child : this.children) {
			if (!(child instanceof Feature)) {
				state.output.fatal("[FME] A relation node must have only Features as children! Child: " + child);
			}
		}
	}

}
