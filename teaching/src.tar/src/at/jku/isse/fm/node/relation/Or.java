package at.jku.isse.fm.node.relation;

import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.data.ProductSet;
import at.jku.isse.fm.node.Relation;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class Or extends Relation {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Or";
	}

	@Override
	protected void myCheckConstraints(EvolutionState state) {
		super.myCheckConstraints(state);

		if (!(this.parent instanceof Feature)) {
			state.output.fatal("[FME] Or node must have a Feature as a parent! Parent: " + this.parent);
		}

		if (this.children.length < 1) {
			state.output.fatal("[FME] Or node must have at least one child! Number of children: " + this.children.length);
		}

		if (((GPNode) this.parent).children[this.argposition] != this) {
			state.output.fatal("[FME] Or node has wrong argposition that does not match its position in its parent's children array! Argposition: " + this.argposition);
		}

		for (GPNode child : this.children) {
			if (!(child instanceof Feature)) {
				state.output.fatal("[FME] Or node must have only Features as children! Child: " + child);
			}
		}
	}

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {
		this.myCheckConstraints(state);

		ProductSet ps = (ProductSet) input;
		ProductSet cloned_ps = (ProductSet) ps.clone();

		for (int i = 0; i < this.children.length; i++) {
			this.optional_eval(state, thread, ps, stack, individual, problem, i);
		}

		// remove those products that do not have any of the optional children
		ps.products.removeAll(cloned_ps.products);
	}

	private void optional_eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem, int i) {
		ProductSet cloned_ps = (ProductSet) ((ProductSet) input).clone();

		children[i].eval(state, thread, cloned_ps, stack, individual, problem);

		((ProductSet) input).products.addAll(cloned_ps.products);
		((ProductSet) input).features.addAll(cloned_ps.features);
	}

}
