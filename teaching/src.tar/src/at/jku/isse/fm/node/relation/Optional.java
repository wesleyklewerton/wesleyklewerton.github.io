package at.jku.isse.fm.node.relation;

import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.data.ProductSet;
import at.jku.isse.fm.node.BinaryRelation;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class Optional extends BinaryRelation {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Optional";
	}

	@Override
	protected void myCheckConstraints(final EvolutionState state) {
		super.myCheckConstraints(state);

		if (!(this.parent instanceof Feature)) {
			state.output.fatal("[FME] Optional node must have a Feature as a parent! Parent: " + this.parent);
		}

		if (this.children.length != 1) {
			state.output.fatal("[FME] Optional node must have exactly one child! Number of children: " + this.children.length);
		}

		if (((GPNode) this.parent).children[this.argposition] != this) {
			state.output.fatal("[FME] Optional node has wrong argposition that does not match its position in its parent's children array! Argposition: " + this.argposition);
		}

		if (!(this.children[0] instanceof Feature)) {
			state.output.fatal("[FME] Optional node must have exactly one Feature as a child! Child: " + this.children[0]);
		}
	}

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {
		this.myCheckConstraints(state);

		ProductSet cloned_ps = (ProductSet) ((ProductSet) input).clone();

		children[0].eval(state, thread, cloned_ps, stack, individual, problem);

		((ProductSet) input).products.addAll(cloned_ps.products);

		((ProductSet) input).features.addAll(cloned_ps.features);
	}

}
