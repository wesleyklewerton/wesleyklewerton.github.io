package at.jku.isse.fm;

import ec.DefaultsForm;
import ec.util.Parameter;

public class FMEDefaults implements DefaultsForm {

	public static final String P_FMFILE = "fmfile";
	public static final String P_FMFILETYPE = "fmfiletype";
	public static final String SPLOT_FILETYPE = "SPLOT";
	public static final String FAMA_FILETYPE = "FAMA";
	public static final String SFS_FILETYPE = "SFS";

	/** Returns the default base. **/
	public static final Parameter base() {
		return new Parameter("at.jku.isse.fm");
	}

}
