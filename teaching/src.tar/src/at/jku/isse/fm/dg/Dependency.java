package at.jku.isse.fm.dg;

import java.util.Set;

import at.jku.isse.fm.data.Feature;

public class Dependency {

	private DNF from;
	private DNF to;
	private double weight;

	public DNF getFrom() {
		return from;
	}

	public void setFrom(DNF from) {
		this.from = from;
	}

	public DNF getTo() {
		return to;
	}

	public void setTo(DNF to) {
		this.to = to;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public boolean holdsOn(Set<Feature> features) {
		if (this.from.holdsOn(features)) {
			if (this.to.holdsOn(features))
				return true;
			else
				return false;
		} else
			return true;
	}

	@Override
	public String toString() {
		return "Dependency [from=" + from + ", to=" + to + ", weight=" + weight + "]\n";
	}

}
