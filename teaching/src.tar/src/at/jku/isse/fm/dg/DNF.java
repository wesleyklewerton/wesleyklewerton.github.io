package at.jku.isse.fm.dg;

import java.util.Iterator;
import java.util.Set;

import at.jku.isse.fm.data.Feature;

public class DNF {

	private Set<Set<Literal>> formula;

	public DNF() {

	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		Iterator<Set<Literal>> andit = this.formula.iterator();
		while (andit.hasNext()) {
			Set<Literal> term = andit.next();
			sb.append("(");
			Iterator<Literal> orit = term.iterator();
			while (orit.hasNext()) {
				Literal literal = orit.next();
				sb.append(literal.toString());
				if (orit.hasNext())
					sb.append(" AND ");
			}
			sb.append(")");
			if (andit.hasNext())
				sb.append(" OR ");
		}
		return sb.toString();
	}

	// ###########################################################

	public Set<Set<Literal>> getFormula() {
		return formula;
	}

	public void setFormula(Set<Set<Literal>> formula) {
		this.formula = formula;
	}

	public void addTerm(Set<Literal> term) {
		this.formula.add(term);
	}

	// ###########################################################

	public boolean holdsOn(Set<Feature> features) {
		for (Set<Literal> inner_formula : this.formula) {
			boolean holds = true;
			for (Literal literal : inner_formula) {
				if (literal.pos && !features.contains(literal.feature))
					holds = false;
				else if (!literal.pos && features.contains(literal.feature))
					holds = false;
			}
			if (holds)
				return true;
		}

		return false;
	}

}
