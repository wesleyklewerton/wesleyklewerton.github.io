package at.jku.isse.fm.dg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import at.jku.isse.fm.data.Feature;

public class DependencyGraph {
	private Document dom;

	private ArrayList<Dependency> dependencies;

	private double sumOfWeights;

	@Override
	public String toString() {
		return "DependencyGraph [dependencies=" + dependencies + "]";
	}

	public boolean holdsOn(Set<Feature> features) {
		for (Dependency dependency : this.dependencies) {
			if (!dependency.holdsOn(features))
				return false;
		}
		return true;
	}

	public double getSumOfWeights() {
		return this.sumOfWeights;
	}

	public ArrayList<Dependency> getDependencies() {
		return dependencies;
	}

	public void setDependencies(ArrayList<Dependency> dependencies) {
		this.dependencies = dependencies;
	}

	public void extractFMDependencies(String xmlFile) {
		this.dependencies = new ArrayList<Dependency>();
		this.parseXmlFile(xmlFile);
		this.parseDocument();
	}

	private void parseXmlFile(String xmlFile) {
		try {
			// get the factory
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

			// Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// parse using builder to get DOM representation of the XML file
			dom = db.parse(xmlFile);
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	private void parseDocument() {
		// get the root elememt
		Element docEle = dom.getDocumentElement();

		// get a nodelist of <employee> elements
		NodeList nl = docEle.getElementsByTagName("dependency");

		double sumOfWeights = 0.0;

		if (nl != null && nl.getLength() > 0) {
			for (int i = 0; i < nl.getLength(); i++) {
				// get the dependency element
				Element el = (Element) nl.item(i);

				Dependency fmdep = new Dependency();
				fmdep.setWeight(Double.parseDouble(el.getAttribute("weight")));

				fmdep.setFrom(this.getFormula(el.getAttribute("from")));
				fmdep.setTo(this.getFormula(el.getAttribute("to")));

				// fmdep.from = el.getAttribute("from");
				// fmdep.to = el.getAttribute("to");
				// fmdep.weight = Double.parseDouble(el.getAttribute("weight"));

				sumOfWeights += fmdep.getWeight();

				this.dependencies.add(fmdep);
			}

			this.sumOfWeights = sumOfWeights;
			for (Dependency dep : this.dependencies) {
				dep.setWeight(dep.getWeight() / this.sumOfWeights);
			}
		}
	}

	private DNF getFormula(String formula_string) {
		DNF dnf = new DNF();
		Set<Set<Literal>> formula = new HashSet<Set<Literal>>();

		// System.out.println("STRING: " + formula_string);

		String[] formula_terms = formula_string.split("OR");
		for (String term : formula_terms) {
			term = term.replaceAll("\\(", "");
			term = term.replaceAll("\\)", "");
			String[] literals = term.split("AND");

			Set<Literal> feature_term = new HashSet<Literal>();
			for (String string_literal : literals) {
				String featurename = string_literal.trim();

				Literal literal = new Literal();
				if (featurename.startsWith("!"))
					literal.pos = false;
				else
					literal.pos = true;
				literal.feature = new Feature(featurename.replace("!", ""));

				feature_term.add(literal);
			}
			formula.add(feature_term);
		}

		dnf.setFormula(formula);

		// System.out.println("DNF: " + dnf);

		return dnf;
	}

}
