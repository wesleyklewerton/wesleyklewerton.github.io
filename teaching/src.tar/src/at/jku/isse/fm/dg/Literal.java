package at.jku.isse.fm.dg;

import at.jku.isse.fm.data.Feature;

public class Literal {

	public Feature feature;
	public boolean pos;

	@Override
	public String toString() {
		if (!this.pos)
			return "!" + this.feature;
		else
			return this.feature.toString();
	}

}
