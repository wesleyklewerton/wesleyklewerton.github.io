package at.jku.isse.fm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;

import at.jku.isse.fm.data.ProductSet;
import ec.EvolutionState;
import ec.gp.GPInitializer;
import ec.util.Parameter;
import es.us.isa.FAMA.Reasoner.Reasoner;
import es.us.isa.FAMA.Reasoner.questions.ProductsQuestion;
import es.us.isa.FAMA.models.FAMAfeatureModel.FAMAFeatureModel;
import es.us.isa.FAMA.models.FAMAfeatureModel.Feature;
import es.us.isa.FAMA.models.FAMAfeatureModel.fileformats.SPLXReader;
import es.us.isa.FAMA.models.FAMAfeatureModel.fileformats.XMLReader;
import es.us.isa.FAMA.models.featureModel.GenericFeature;
import es.us.isa.FAMA.models.featureModel.Product;
import es.us.isa.FAMA.models.variabilityModel.GenericProduct;
import es.us.isa.FAMA.models.variabilityModel.parsers.WrongFormatException;
import es.us.isa.JavaBDDReasoner.JavaBDDReasoner;
import es.us.isa.JavaBDDReasoner.questions.JavaBDDProductsQuestion;

public class FeatureModelExtractionInitializer extends GPInitializer {

	private static final long serialVersionUID = 1L;

	public static final String P_INIT = "init";

	public ProductSet ps = null;

	@Override
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);

		state.output.message("[FME] FeatureModelExtractionInitializer.setup(): " + base);

		Parameter def = FMEDefaults.base().push(P_INIT);
		Parameter fmbase = FMEDefaults.base();

		// ProductSet ps = (ProductSet) this.input;
		this.ps = new ProductSet();

		// get parameter for feature model file
		File fmfile = state.parameters.getFile(base.push(FMEDefaults.P_FMFILE), fmbase.push(FMEDefaults.P_FMFILE));
		String fmfiletype = state.parameters.getString(base.push(FMEDefaults.P_FMFILETYPE), fmbase.push(FMEDefaults.P_FMFILETYPE));

		if (fmfiletype.equals(FMEDefaults.SFS_FILETYPE)) {
			try {
				BufferedReader in = new BufferedReader(new FileReader(fmfile));
				String line;
				while ((line = in.readLine()) != null) {
					String[] strArr = line.split(",");
					at.jku.isse.fm.data.Product product = new at.jku.isse.fm.data.Product();
					for (String str : strArr) {
						String feature = str.trim();
						product.add(new at.jku.isse.fm.data.Feature(feature.toLowerCase()));
						ps.features.add(new at.jku.isse.fm.data.Feature(feature.toLowerCase()));
					}
					ps.products.add(product);
				}
				in.close();
			} catch (IOException e) {
				state.output.fatal("[FME] Error reading the provided SFS file!");
			}
		} else {
			// read feature model file
			FAMAFeatureModel fama_model = null;
			try {
				if (fmfiletype.equals(FMEDefaults.SPLOT_FILETYPE)) {
					SPLXReader reader = new SPLXReader();
					fama_model = (FAMAFeatureModel) reader.parseFile(fmfile.getAbsolutePath());
				} else if (fmfiletype.equals(FMEDefaults.FAMA_FILETYPE)) {
					XMLReader reader = new XMLReader();
					fama_model = (FAMAFeatureModel) reader.parseFile(fmfile.getAbsolutePath());
				} else {
					state.output.fatal("[FME] Unknown feature model file type specified!");
				}
			} catch (WrongFormatException e) {
				state.output.fatal("[FME] The provided feature model file is in the wrong format!");
			} catch (Exception e) {
				state.output.fatal("[FME] Error reading the provided feature model file!");
			}

			// compute the products for the feature model and convert them to our data structure
			if (fama_model != null) {
				for (Feature fama_feature : fama_model.getFeatures()) {
					ps.features.add(new at.jku.isse.fm.data.Feature(fama_feature.getName().toLowerCase()));
				}
				state.output.message("Features: (" + ps.features.size() + ") " + ps.features.toString());

				// TODO: make the solver a parameter
				ProductsQuestion products_question = new JavaBDDProductsQuestion();
				Reasoner reasoner = new JavaBDDReasoner();
				// ProductsQuestion products_question = new Sat4jProductsQuestion();
				// Reasoner reasoner = new Sat4jReasoner();
				fama_model.transformTo(reasoner);
				reasoner.ask(products_question);

				Collection<? extends GenericProduct> fama_products = (Collection<? extends GenericProduct>) products_question.getAllProducts();

				for (GenericProduct fama_generic_product : fama_products) {
					at.jku.isse.fm.data.Product product = new at.jku.isse.fm.data.Product();
					for (GenericFeature fama_generic_feature : ((Product) fama_generic_product).getFeatures()) {
						product.add(new at.jku.isse.fm.data.Feature(fama_generic_feature.getName().toLowerCase()));
					}
					ps.products.add(product);
					// state.output.message(product.toString());
				}
			}
		}
		
		state.output.message("Num Products: (" + ps.products.size() + ") "); // + ps.products.toString());
	}

}
