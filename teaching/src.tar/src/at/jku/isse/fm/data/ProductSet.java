package at.jku.isse.fm.data;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import ec.gp.GPData;

public class ProductSet extends GPData {

	private static final long serialVersionUID = 1L;

	public Set<Product> products = new HashSet<Product>();

	public Set<Feature> features = new LinkedHashSet<Feature>();

	public ProductSet() {
		super();
	}

	@Override
	public Object clone() {
		ProductSet ps = (ProductSet) super.clone();
		ps.products = new HashSet<Product>();
		for (Product p : this.products) {
			ps.products.add((Product) p.clone());
		}
		ps.features = (HashSet<Feature>) ((HashSet<Feature>) this.features).clone();

		return ps;
	}

}
