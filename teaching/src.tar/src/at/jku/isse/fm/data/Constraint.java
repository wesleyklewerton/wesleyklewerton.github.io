package at.jku.isse.fm.data;

import java.util.HashSet;

import ec.gp.GPData;

/*
 * All nodes and other data structures should point to the features in the product set of the initializer! they may never be changed!
 */

public class Constraint extends GPData {

	private static final long serialVersionUID = 1L;

	public HashSet<Feature> pos = new HashSet<Feature>();
	public HashSet<Feature> neg = new HashSet<Feature>();

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((neg == null) ? 0 : neg.hashCode());
		result = prime * result + ((pos == null) ? 0 : pos.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Constraint other = (Constraint) obj;
		if (neg == null) {
			if (other.neg != null)
				return false;
		} else if (!neg.equals(other.neg))
			return false;
		if (pos == null) {
			if (other.pos != null)
				return false;
		} else if (!pos.equals(other.pos))
			return false;
		return true;
	}

}
