package at.jku.isse.fm.data;

import java.util.HashSet;
import java.util.Set;

import ec.gp.GPData;

public class ConstraintSet extends GPData {

	private static final long serialVersionUID = 1L;

	public Set<Constraint> constraints = new HashSet<Constraint>();

}
