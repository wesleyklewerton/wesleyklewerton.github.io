package at.jku.isse.fm.data;

import java.util.HashSet;

public class Product extends HashSet<Feature> {

	private static final long serialVersionUID = 1L;

	public Product() {
		super();
	}

}
