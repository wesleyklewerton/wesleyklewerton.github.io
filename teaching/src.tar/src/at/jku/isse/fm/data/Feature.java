package at.jku.isse.fm.data;

import at.jku.isse.fm.node.FMBaseNode;
import at.jku.isse.fm.node.Relation;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import ec.util.Parameter;

public class Feature extends FMBaseNode {

	private static final long serialVersionUID = 1L;

	private String name;

	// ######## GPNode ###################

	@Override
	public String toString() {
		return this.name;
	}

	@Override
	protected void myCheckConstraints(EvolutionState state) {
		super.myCheckConstraints(state);

		if (!(this.parent instanceof Relation)) {
			state.output.fatal("[FME] Feature node must have a Relation as a parent! Parent: " + this.parent);
		}

		if (((GPNode) this.parent).children[this.argposition] != this) {
			state.output.fatal("[FME] Feature node has wrong argposition that does not match its position in its parent's children array! Argposition: " + this.argposition);
		}

		for (GPNode child : this.children) {
			if (!(child instanceof Relation)) {
				state.output.fatal("[FME] Feature node must have only Relations as children!");
			}
		}

	}

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {
		this.myCheckConstraints(state);

		ProductSet ps = ((ProductSet) input);
		ProductSet ps_clone = (ProductSet) ps.clone();
		for (Product p : ps_clone.products) {
			p.add(this);
		}
		ps.products.clear();
		ps.products.addAll(ps_clone.products);

		if (ps.features.contains(this)) {
			state.output.fatal("[FME] Fatal error evaluating individual: Feature was already evaluated in individual. Feature: " + this);
		}

		ps.features.add(this);

		for (GPNode n : this.children) {
			n.eval(state, thread, input, stack, individual, problem);
		}
	}

	public void checkConstraints(final EvolutionState state, final int tree, final GPIndividual typicalIndividual, final Parameter individualBase) {
		super.checkConstraints(state, tree, typicalIndividual, individualBase);
	}

	public int expectedChildren() {
		return super.expectedChildren();
	}

	// ###################################

	public Feature() {
		this.name = "<undefined>";
	}

	public Feature(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Feature other = (Feature) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}
