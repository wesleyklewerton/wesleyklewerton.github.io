package at.jku.isse.fm;

import java.util.ArrayList;

import at.jku.isse.fm.ctc.AtomNode;
import at.jku.isse.fm.ctc.ConstraintNode;
import at.jku.isse.fm.ctc.ConstraintSetNode;
import at.jku.isse.fm.ctc.NotNode;
import at.jku.isse.fm.data.Constraint;
import at.jku.isse.fm.data.ConstraintSet;
import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.node.BinaryRelation;
import at.jku.isse.fm.node.Relation;
import at.jku.isse.fm.node.relation.Alternative;
import at.jku.isse.fm.node.relation.Or;
import ec.gp.GPNode;

// TODO: maybe move some of these functions into the classes. e.g. the function attachNode could be a method of class FMBaseNode.

public class FMUtils {

	public static GPNode cloneNode(GPNode n) {
		GPNode new_n = n.lightClone();
		new_n.children = new GPNode[0];
		new_n.argposition = 0;
		new_n.parent = null;
		return new_n;
	}

	/**
	 * Detaches n from its parent node.
	 */
	public static void detachNode(GPNode n) {
		GPNode parentnode = (GPNode) n.parent;
		GPNode[] orig_children = parentnode.children;
		GPNode[] new_children = new GPNode[orig_children.length - 1];
		for (int i = 0; i < n.argposition; i++) {
			new_children[i] = orig_children[i];
		}
		for (int i = n.argposition + 1; i < orig_children.length; i++) {
			new_children[i - 1] = orig_children[i];
			parentnode.children[i].argposition = (byte) (i - 1);
		}

		((GPNode) n.parent).children = new_children;

		n.parent = null;
		n.argposition = -1;
	}

	/**
	 * Attaches n1 to n2.
	 */
	public static void attachNode(GPNode n1, GPNode n2) {
		if (n2.children != null) {
			GPNode[] orig_children = n2.children;
			GPNode[] new_children = new GPNode[orig_children.length + 1];

			System.arraycopy(orig_children, 0, new_children, 0, orig_children.length);
			new_children[new_children.length - 1] = n1;

			n2.children = new_children;

			n1.parent = n2;
			n1.argposition = (byte) (new_children.length - 1);
		} else {
			GPNode[] new_children = new GPNode[1];
			new_children[0] = n1;

			n2.children = new_children;

			n1.parent = n2;
			n1.argposition = (byte) 0;
		}
	}

	/**
	 * Replaces node n1 with node n2.
	 */
	public static void replaceNode(GPNode n1, GPNode n2) {
		n2.children = n1.children;
		n2.parent = n1.parent;
		n2.argposition = n1.argposition;

		n1.children = null;
		n1.parent = null;

		((GPNode) n2.parent).children[n2.argposition] = n2;

		for (GPNode child : n2.children) {
			child.parent = n2;
		}
	}

	/**
	 * Swaps two nodes in the tree.
	 */
	public static void swapNodes(GPNode n1, GPNode n2) {
		byte tempargposition;
		GPNode tempchildren[];
		GPNode tempparent;

		tempargposition = n2.argposition;
		tempchildren = n2.children;
		tempparent = (GPNode) n2.parent;

		n2.children = n1.children;
		n2.parent = n1.parent;
		n2.argposition = n1.argposition;

		n1.children = tempchildren;
		n1.parent = tempparent;
		n1.argposition = tempargposition;

		((GPNode) n1.parent).children[n1.argposition] = n1;
		((GPNode) n2.parent).children[n2.argposition] = n2;

		for (GPNode child : n1.children) {
			child.parent = n1;
		}
		for (GPNode child : n2.children) {
			child.parent = n2;
		}
	}

	public static class ReturnVal {
		public GPNode n;
		public int i;

		public ReturnVal(GPNode n, int i) {
			this.n = n;
			this.i = i;
		}
	}

	public static ReturnVal getFeatureNode(GPNode n, int i, int cur_i) {
		if (cur_i == i) {
			if (n instanceof Feature)
				return new ReturnVal(n, cur_i);
			else {
				for (GPNode child : n.children) {
					ReturnVal r;
					if (child instanceof Feature)
						r = FMUtils.getFeatureNode(child, i, cur_i);
					else
						r = FMUtils.getFeatureNode(child, i, cur_i);
					if (r.n != null)
						return r;
					cur_i = r.i;
				}
			}
		} else {
			for (GPNode child : n.children) {
				ReturnVal r;
				if (child instanceof Feature)
					r = FMUtils.getFeatureNode(child, i, cur_i + 1);
				else
					r = FMUtils.getFeatureNode(child, i, cur_i);
				if (r.n != null)
					return r;
				cur_i = r.i;
			}
		}
		return new ReturnVal(null, cur_i);
	}

	public static ReturnVal getNode(GPNode n, int i, int cur_i) {
		if (cur_i == i)
			return new ReturnVal(n, cur_i);
		else {
			for (GPNode child : n.children) {
				ReturnVal r;
				r = FMUtils.getNode(child, i, cur_i + 1);
				cur_i = r.i;
				if (r.n != null)
					return r;
			}
		}
		return new ReturnVal(null, cur_i);
	}

	public static void getAllGroupRelations(GPNode n, ArrayList<Relation> list) {
		if (n instanceof Alternative || n instanceof Or) {
			list.add((Relation) n);
		}
		for (GPNode child : n.children) {
			FMUtils.getAllGroupRelations(child, list);
		}
	}

	public static void getAllBinaryRelations(GPNode n, ArrayList<BinaryRelation> list) {
		if (n instanceof BinaryRelation) {
			list.add((BinaryRelation) n);
		}
		for (GPNode child : n.children) {
			FMUtils.getAllBinaryRelations(child, list);
		}
	}

	public static void getAllRelations(GPNode n, ArrayList<Relation> list) {
		if (n instanceof Relation) {
			list.add((Relation) n);
		}
		for (GPNode child : n.children) {
			FMUtils.getAllRelations(child, list);
		}
	}

	public static int treeSize(GPNode n) {
		int size = 1;
		for (GPNode child : n.children) {
			size += FMUtils.treeSize(child);
		}
		return size;
	}

	public static int countFeatures(GPNode n) {
		int size = 0;
		if (n instanceof Feature) {
			size++;
		}
		for (GPNode child : n.children) {
			size += FMUtils.countFeatures(child);
		}
		return size;
	}

	public static void collectConstraints(ConstraintSetNode csn, ConstraintSet cs) {
		for (GPNode node : csn.children) {
			ConstraintNode cn = (ConstraintNode) node;
			Constraint c = new Constraint();

			for (GPNode node2 : cn.children[0].children) { // node2 is either a NotNode or an AtomNode
				if (node2 instanceof AtomNode) {
					c.pos.add((Feature) node2.children[0]); // add feature
				} else if (node2 instanceof NotNode) {
					c.neg.add((Feature) node2.children[0].children[0]); // add feature
				}
			}

			cs.constraints.add(c);
		}
	}

}
