package at.jku.isse.fm.operator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import at.jku.isse.fm.FMEDefaults;
import at.jku.isse.fm.FMUtils;
import at.jku.isse.fm.FeatureModelExtractionInitializer;
import at.jku.isse.fm.ctc.AtomNode;
import at.jku.isse.fm.ctc.ConstraintNode;
import at.jku.isse.fm.ctc.ConstraintSetNode;
import at.jku.isse.fm.ctc.NotNode;
import at.jku.isse.fm.ctc.OrNode;
import at.jku.isse.fm.data.Constraint;
import at.jku.isse.fm.data.ConstraintSet;
import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.node.Relation;
import at.jku.isse.fm.node.relation.Mandatory;
import at.jku.isse.fm.node.relation.Root;
import ec.EvolutionState;
import ec.Individual;
import ec.gp.GPBreedingPipeline;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import ec.gp.GPTree;
import ec.util.Parameter;

public class FeatureModelCrossoverPipeline extends GPBreedingPipeline {

	private static final long serialVersionUID = 1L;

	public static final int NUM_SOURCES = 2;

	/** Temporary holding place for parents */
	public GPIndividual parents[];

	/** Should the pipeline discard the second parent after crossing over? */
	public boolean tossSecondParent;

	public FeatureModelCrossoverPipeline() {
		parents = new GPIndividual[2];
	}

	@Override
	public Parameter defaultBase() {
		return FMEDefaults.base().push("xover");
	}

	@Override
	public int numSources() {
		return NUM_SOURCES;
	}

	/**
	 * Returns 2 * minimum number of typical individuals produced by any sources, else 1* minimum number if tossSecondParent is true.
	 */
	@Override
	public int typicalIndsProduced() {
		return (tossSecondParent ? minChildProduction() : minChildProduction() * 2);
	}

	@Override
	public Object clone() {
		FeatureModelCrossoverPipeline c = (FeatureModelCrossoverPipeline) (super.clone());

		// deep-cloned stuff
		c.parents = (GPIndividual[]) parents.clone();

		return c;
	}

	@Override
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);

		Parameter def = defaultBase();

		tossSecondParent = state.parameters.getBoolean(base.push("toss"), def.push("toss"), false);
	}

	@Override
	public int produce(int min, int max, int start, int subpopulation, Individual[] inds, EvolutionState state, int thread) {
		// how many individuals should we make?
		int n = typicalIndsProduced();
		if (n < min)
			n = min;
		if (n > max)
			n = max;
		

		// state.output.message("[FME] likelihood: " + likelihood);
		// state.output.message("[FME] +Crossover");
		if (n != 2) {
			state.output.message("[FME] Produced individuals for crossover is not 2! " + typicalIndsProduced() + "," + min + "," + max);
		}

		//System.out.println(n+" - "+min+" - "+max);
		//System.exit(0);
		
		
		// should we bother?
		if (!state.random[thread].nextBoolean(likelihood)) {
			state.output.message("[FME] ERROR: Strange thing in Crossover happened with likelihood!");
			return reproduce(n, start, subpopulation, inds, state, thread, true); // DO produce children from source -- we've not done so already
		}

		FeatureModelExtractionInitializer initializer = ((FeatureModelExtractionInitializer) state.initializer);

		for (int q = start; q < n + start; /* no increment */) // keep on going until we're filled up
		{
			// grab two individuals from our sources
			if (sources[0] == sources[1]) // grab from the same source
				sources[0].produce(2, 2, 0, subpopulation, parents, state, thread);
			else // grab from different sources
			{
				sources[0].produce(1, 1, 0, subpopulation, parents, state, thread);
				sources[1].produce(1, 1, 1, subpopulation, parents, state, thread);
			}

			// at this point, parents[] contains our two selected individuals

			// clone individual
			GPIndividual j1 = (GPIndividual) (parents[0].lightClone());
			GPIndividual j2 = (GPIndividual) (parents[1].lightClone());

			// it is not evaluated
			j1.evaluated = false;
			j2.evaluated = false;

			// number of features
			int num_features = initializer.ps.features.size();
			// store sequence of random numbers
			ArrayList<Integer> rlist = new ArrayList<Integer>();
			// map of already copied features and the corresponding feature node
			HashMap<String, Feature> featuremap = new HashMap<String, Feature>();

			// ############ FIRST INDIVIDUAL ###############

			// clone tree
			j1.trees[0] = (GPTree) (parents[0].trees[0].lightClone());
			j1.trees[0].owner = j1;

			// initialise new tree with root node
			j1.trees[0].child = new Root();
			j1.trees[0].child.parent = j1.trees[0];
			j1.trees[0].child.argposition = 0;

			// total number of features copied
			int rtotal = 0;

			// initialise offspring with first parent's root feature and second parent's root feature
			Root root1 = (Root) j1.trees[0].child;
			root1.children = new GPNode[1];
			// add first feature
			Feature new_feature1 = (Feature) parents[0].trees[0].child.children[0].lightClone();
			// new_feature1.children = new GPNode[1];
			new_feature1.parent = j1.trees[0].child;
			new_feature1.argposition = (byte) (0);
			root1.children[0] = new_feature1;

			featuremap.put(new_feature1.getName(), new_feature1);

			Feature new_feature2 = (Feature) parents[1].trees[0].child.children[0].lightClone();
			if (!new_feature1.equals(new_feature2)) {
				new_feature1.children = new GPNode[1];

				// add mandatory relation to first feature
				Mandatory mandatory = new Mandatory();
				mandatory.resetNode(state, thread);
				mandatory.parent = new_feature1;
				mandatory.argposition = (byte) (0);
				mandatory.children = new GPNode[1];
				new_feature1.children[0] = mandatory;
				// add second feature

				new_feature2.children = new GPNode[0];
				new_feature2.parent = mandatory;
				new_feature2.argposition = (byte) (0);
				mandatory.children[0] = new_feature2;

				featuremap.put(new_feature2.getName(), new_feature2);
			} else {
				new_feature1.children = new GPNode[0];
				new_feature2 = new_feature1;
			}

			Feature last1parent = (Feature) parents[0].trees[0].child.children[0]; // root feature of first parent
			Feature last2parent = (Feature) parents[1].trees[0].child.children[0]; // root feature of second parent

			Feature last1offspring = new_feature1;
			Feature last2offspring = new_feature2;

			boolean pol = true; // which tree is next to be traversed

			ReturnVal rv1 = new ReturnVal(last1parent, last1offspring);
			ReturnVal rv2 = new ReturnVal(last2parent, last2offspring);

			rtotal = 2;
			if (last1offspring.equals(last2offspring))
				rtotal = 1;
			
			//while (rtotal < num_features) {
			while (featuremap.size() < num_features) {
				int r = state.random[thread].nextInt(num_features - 1) + 1;
				// rlist.add(r);

				// System.out.println("R: " + pol + "." + r);

				// rtotal += r;
				int r_orig = r;

				if (pol) {
					// traverse first tree
					/*
					 * starts/continues traversing at next1parent (feature) and appends traversed nodes at last1 (relation) and returns last (feature) node that was not traversed
					 */
					//rv1 = this.traverse(rv1.last_parent_node, r, rv1.last_offspring_node, featuremap);
					rv1 = this.traverse(last1parent, r, last1offspring, featuremap);
					pol = !pol;
					r = r - rv1.r;
					r_orig = r_orig - rv1.r;
				} else {
					// traverse second tree
					/*
					 * starts/continues traversing at next2parent and appends traversed nodes at last2 and returns last node that was not traversed
					 */
					rv2 = this.traverse(last2parent, r, last2offspring, featuremap);
					pol = !pol;
					r = r - rv2.r;
					r_orig = r_orig - rv2.r;
				}

				rlist.add(r);
				rtotal += r;

				if (rtotal != featuremap.size())
					System.out.println("SIZE-DIFF: " + rtotal + ", " + featuremap.size());
				
//				if (r != 0)
//					System.out.println(r + ", " + r_orig);
			}

			if (featuremap.size() != initializer.ps.features.size()) {
				state.output.message("!!!ERROR: feature size does not match! " + rtotal + "; " + featuremap.size() + "; " + initializer.ps.features.size());
			}

			// create (and clone!) ctc tree for this individual: for every ctc in parent1 and parent2: randomly either put it in or not (avoid duplicate CTCs by using a ConstraintSet!)

			// clone ctc tree
			j1.trees[1] = (GPTree) (parents[0].trees[1].lightClone());
			j1.trees[1].owner = j1;

			// initialize new ctc tree with constraint set node
			ConstraintSetNode csn = new ConstraintSetNode();
			csn.resetNode(state, thread);
			csn.argposition = (byte) 0;
			csn.parent = j1.trees[1];
			csn.children = new GPNode[0];

			j1.trees[1].child = csn;

			// traverse both parents' ctc tree to get a complete constraint set containing all constraints
			ConstraintSet cs = new ConstraintSet();
			this.collectConstraints((ConstraintSetNode) parents[0].trees[1].child, cs);
			this.collectConstraints((ConstraintSetNode) parents[1].trees[1].child, cs);

			// randomly put every constraint either in the first offspring or not
			Iterator<Constraint> it = cs.constraints.iterator();
			while (it.hasNext()) {
				Constraint c = it.next();

				// add it to first offspring?
				if (state.random[thread].nextBoolean(0.5)) {
					// create a ctc tree for the constraint set
					ConstraintNode cn = new ConstraintNode();
					cn.resetNode(state, thread);
					cn.children = new GPNode[1];

					FMUtils.attachNode(cn, csn);

					OrNode ornode = new OrNode();
					ornode.resetNode(state, thread);
					ornode.parent = cn;
					ornode.children = new GPNode[0];
					ornode.argposition = (byte) 0;

					cn.children[0] = ornode;

					// neg features (requiring a not node)
					for (Feature f : c.neg) {
						NotNode notnode = new NotNode();
						AtomNode atomnode = new AtomNode();
						Feature new_f = new Feature(f.getName());
						new_f.children = new GPNode[0];
						FMUtils.attachNode(new_f, atomnode);
						FMUtils.attachNode(atomnode, notnode);
						FMUtils.attachNode(notnode, ornode);
					}

					// pos features
					for (Feature f : c.pos) {
						AtomNode atomnode = new AtomNode();
						Feature new_f = new Feature(f.getName());
						new_f.children = new GPNode[0];
						FMUtils.attachNode(new_f, atomnode);
						FMUtils.attachNode(atomnode, ornode);
					}

					// remove it
					it.remove();
				}
			}

			// ############ SECOND INDIVIDUAL ###############
			/*
			 * (this should be pretty much identical to first one except for not generating new random numbers but instead using the list of stored ones
			 */

			if (q + 1 < n + start && !tossSecondParent) {

				// total number of features copied
				// rtotal = 0;
				// map of already copied features and the corresponding feature node
				featuremap = new HashMap<String, Feature>();

				// clone tree
				j2.trees[0] = (GPTree) (parents[1].trees[0].lightClone());
				j2.trees[0].owner = j2;

				this.initialize_offspring(parents[1], parents[0], j2, state, thread);

				last1parent = (Feature) parents[1].trees[0].child.children[0]; // root feature of first parent
				last2parent = (Feature) parents[0].trees[0].child.children[0]; // root feature of second parent

				last1offspring = (Feature) j2.trees[0].child.children[0];
				if (j2.trees[0].child.children[0].children.length > 0)
					last2offspring = (Feature) j2.trees[0].child.children[0].children[0].children[0]; // initialization guarantees that this is correct
				else
					last2offspring = last1offspring;

				featuremap.put(last1offspring.getName(), last1offspring);
				if (!last1offspring.equals(last2offspring))
					featuremap.put(last2offspring.getName(), last2offspring);

				pol = true; // which tree is next to be traversed

				rv1 = new ReturnVal(last1parent, last1offspring);
				rv2 = new ReturnVal(last2parent, last2offspring);

				// while (rtotal < num_features) {
				// int r = state.random[thread].nextInt(num_features - 1) + 1;
				// rlist.add(r);
				//
				// // System.out.println("R: " + pol + "." + r);
				//
				// rtotal += r;

				for (int r : rlist) {
				//while (featuremap.size() < num_features) {
					if (pol) {
						// traverse first tree
						/*
						 * starts/continues traversing at next1parent (feature) and appends traversed nodes at last1 (relation) and returns last (feature) node that was not
						 * traversed
						 */
						// rv1 = this.traverse(rv1.last_parent_node, r, rv1.last_offspring_node, featuremap);
						rv1 = this.traverse(last1parent, r, last1offspring, featuremap);
						pol = !pol;
					} else {
						// traverse second tree
						/*
						 * starts/continues traversing at next2parent and appends traversed nodes at last2 and returns last node that was not traversed
						 */
						// rv2 = this.traverse(rv2.last_parent_node, r, rv2.last_offspring_node, featuremap);
						rv2 = this.traverse(last2parent, r, last2offspring, featuremap);
						pol = !pol;
					}
				}

				if (featuremap.size() != initializer.ps.features.size()) {
					state.output.message("???ERROR: feature size does not match! " + rtotal + "; " + featuremap.size() + "; " + initializer.ps.features.size());
				}

				// create (and clone!) ctc tree for this individual: for every ctc in parent1 and parent2: randomly either put it in or not (avoid duplicate CTCs by using a ConstraintSet!)

				// clone ctc tree
				j2.trees[1] = (GPTree) (parents[1].trees[1].lightClone());
				j2.trees[1].owner = j2;

				// initialize new ctc tree with constraint set node
				ConstraintSetNode csn2 = new ConstraintSetNode();
				csn2.resetNode(state, thread);
				csn2.argposition = (byte) 0;
				csn2.parent = j2.trees[1];
				csn2.children = new GPNode[0];

				j2.trees[1].child = csn2;

				// put every REMAINING constraint in the second offspring
				it = cs.constraints.iterator();
				while (it.hasNext()) {
					Constraint c = it.next();

//					// add it to second offspring?
//					if (state.random[thread].nextBoolean(0.5)) {
					// add to second offspring
						// create a ctc tree for the constraint set
						ConstraintNode cn = new ConstraintNode();
						cn.resetNode(state, thread);
						cn.children = new GPNode[1];

						FMUtils.attachNode(cn, csn2);

						OrNode ornode = new OrNode();
						ornode.resetNode(state, thread);
						ornode.parent = cn;
						ornode.children = new GPNode[0];
						ornode.argposition = (byte) 0;

						cn.children[0] = ornode;

						// neg features (requiring a not node)
						for (Feature f : c.neg) {
							NotNode notnode = new NotNode();
							AtomNode atomnode = new AtomNode();
							Feature new_f = new Feature(f.getName());
							new_f.children = new GPNode[0];
							FMUtils.attachNode(new_f, atomnode);
							FMUtils.attachNode(atomnode, notnode);
							FMUtils.attachNode(notnode, ornode);
						}

						// pos features
						for (Feature f : c.pos) {
							AtomNode atomnode = new AtomNode();
							Feature new_f = new Feature(f.getName());
							new_f.children = new GPNode[0];
							FMUtils.attachNode(new_f, atomnode);
							FMUtils.attachNode(atomnode, ornode);
						}

						// remove it
						it.remove();
//					}
				}

			}

			// ############ DONE #################

			// add the individuals to the population
			inds[q] = j1;
			q++;
			if (q < n + start && !tossSecondParent) {
				inds[q] = j2;
				q++;
			}
		}

		// state.output.message("[FME] -Crossover");

		return n;
	}

	private void initialize_offspring(GPIndividual parent1, GPIndividual parent2, GPIndividual offspring, EvolutionState state, int thread) {
		// initialise new tree with root node
		offspring.trees[0].child = new Root();
		offspring.trees[0].child.resetNode(state, thread);
		offspring.trees[0].child.parent = offspring.trees[0];
		offspring.trees[0].child.argposition = 0;

		// initialise offspring with first parent's root feature and second parent's root feature
		Root root = (Root) offspring.trees[0].child;
		root.children = new GPNode[1];
		// add first feature
		Feature new_feature1 = (Feature) parent1.trees[0].child.children[0].lightClone();
		// new_feature1.children = new GPNode[1];
		new_feature1.parent = root;
		new_feature1.argposition = (byte) (0);
		root.children[0] = new_feature1;

		Feature new_feature2 = (Feature) parent2.trees[0].child.children[0].lightClone();
		if (!new_feature1.equals(new_feature2)) {
			new_feature1.children = new GPNode[1];

			// add mandatory relation to first feature
			Mandatory mandatory = new Mandatory();
			mandatory.resetNode(state, thread);
			mandatory.parent = new_feature1;
			mandatory.argposition = (byte) (0);
			mandatory.children = new GPNode[1];
			new_feature1.children[0] = mandatory;
			// add second feature

			new_feature2.children = new GPNode[0];
			new_feature2.parent = mandatory;
			new_feature2.argposition = (byte) (0);
			mandatory.children[0] = new_feature2;
		} else {
			new_feature1.children = new GPNode[0];
		}
	}

	// private void iterative_traversal(Stack<GPNode> stack, int r, HashMap<String, Feature> featuremap) {
	// while (!stack.isEmpty()) {
	// GPNode current = stack.pop();
	//
	// // do work
	// if (current instanceof Feature) { // it is a feature
	// Feature feature = (Feature) current;
	// if (featuremap.containsKey(current)) {
	// // feature is already contained: do nothing
	// } else {
	//
	// }
	// } else { // it is a relation
	// // the parent of a relation must be a feature
	// Feature parent_feature = (Feature) current.parent;
	//
	// // to have gotten to this relation, the feature must already have been inserted. get it.
	// Feature offspring_parent_feature = featuremap.get(parent_feature.getName());
	//
	// // add the relation as a child to the offspring parent
	//
	// }
	//
	// for (GPNode child : current.children) {
	// stack.push(child);
	// }
	// }
	// }

	/**
	 * Starts to traverse the tree at "next" and traverses "r" nodes. Returns the "r+1"st node as the first node that was not traversed anymore (and therefore is the new next node
	 * from which traversal should be continued). Appends traversed nodes to "last" node.
	 * 
	 * @param next
	 * @param r
	 * @param last
	 * @return
	 */
	private ReturnVal traverse(Feature last_parent_node, int r, Feature last_offspring_node, HashMap<String, Feature> featuremap) {

		ReturnVal rv = new ReturnVal(last_parent_node, last_offspring_node, r);

		// base case
		if (r == 0) { // no more traversal
			return rv;
		}

		// "next" and "last" must be features and not relations
		if (!(last_parent_node instanceof Feature) || !(last_offspring_node instanceof Feature)) {
			System.out.println("[FME] nodes must be features: (" + last_parent_node + "," + last_offspring_node + ")");
		}

		// Feature new_next = null;

		// traverse all children from last parent feature (must all be relations)
		for (GPNode nr : last_parent_node.children) {
			Relation rel = (Relation) nr;

			// traverse all children of the relation (must all be features)
			for (GPNode nf : rel.children) {
				Feature feature = (Feature) nf;

				// append next feature from parent to last feature from offspring, but only if it is not already part of the offspring
				if (featuremap.containsKey(feature.getName())) { // next parent feature is already part of the offspring
					// continue traversal at the matching feature from the featuremap and do not decrease r
					rv = this.traverse(feature, rv.r, featuremap.get(feature.getName()), featuremap);

				} else { // next parent feature is not part of offspring yet

					// add rel to children of last offspring feature
					// increase size of children array by 1
					if (last_offspring_node.children == null || last_offspring_node.children.length == 0) {
						last_offspring_node.children = new GPNode[1];
					} else {
						GPNode[] new_children = new GPNode[last_offspring_node.children.length + 1];
						System.arraycopy(last_offspring_node.children, 0, new_children, 0, last_offspring_node.children.length);
						last_offspring_node.children = new_children;
					}
					Relation new_rel = (Relation) rel.lightClone();
					new_rel.children = null;
					new_rel.parent = last_offspring_node;
					new_rel.argposition = (byte) (last_offspring_node.children.length - 1);
					last_offspring_node.children[last_offspring_node.children.length - 1] = new_rel;

					// add next parent feature to children of new rel
					// increase size of children array by 1
					if (new_rel.children == null || new_rel.children.length == 0) {
						new_rel.children = new GPNode[1];
					} else {
						GPNode[] new_children = new GPNode[new_rel.children.length + 1];
						System.arraycopy(new_rel.children, 0, new_children, 0, new_rel.children.length);
						new_rel.children = new_children;
					}
					Feature new_feature = (Feature) feature.lightClone();
					// new_feature.children = null; // this causes a null pointer exception
					new_feature.children = new GPNode[0];
					new_feature.parent = new_rel;
					new_feature.argposition = (byte) (new_rel.children.length - 1);
					new_rel.children[new_rel.children.length - 1] = new_feature;

					// put new feature node in offspring into the map
					featuremap.put(new_feature.getName(), new_feature);

					// continue traversal
					// rv = this.traverse(feature, r - 1, new_feature, featuremap);
					rv = this.traverse(feature, rv.r - 1, new_feature, featuremap);

					if (rv.r == 0) {
						//System.out.println("done!!!!");
						return rv;
					}
				}

			}

		}

		// GPNode temp_parent = last_parent_node;
		// while (temp_parent.parent instanceof GPNode && temp_parent.argposition == ((GPNode)temp_parent.parent).children.length - 1)
		// temp_parent = (GPNode) temp_parent.parent;
		//
		// if (temp_parent instanceof GPNode) {
		// rv = this.traverse(last_parent_node, r, last_offspring_node, featuremap)
		// }

		return rv;
	}

	private class ReturnVal {
		public Feature last_parent_node;
		public Feature last_offspring_node;
		public int r;

		public ReturnVal(Feature new_last_parent_node, Feature new_last_offspring_node, int r) {
			this.last_offspring_node = new_last_offspring_node;
			this.last_parent_node = new_last_parent_node;
			this.r = r;
		}

		public ReturnVal(Feature new_last_parent_node, Feature new_last_offspring_node) {
			this.last_offspring_node = new_last_offspring_node;
			this.last_parent_node = new_last_parent_node;
			this.r = -1;
		}
	}

	private void collectConstraints(ConstraintSetNode csn, ConstraintSet cs) {
		for (GPNode node : csn.children) {
			ConstraintNode cn = (ConstraintNode) node;
			Constraint c = new Constraint();

			for (GPNode node2 : cn.children[0].children) { // node2 is either a NotNode or an AtomNode
				if (node2 instanceof AtomNode) {
					c.pos.add((Feature) node2.children[0]); // add feature
				} else if (node2 instanceof NotNode) {
					c.neg.add((Feature) node2.children[0].children[0]); // add feature
				}
			}

			cs.constraints.add(c);
		}
	}

}
