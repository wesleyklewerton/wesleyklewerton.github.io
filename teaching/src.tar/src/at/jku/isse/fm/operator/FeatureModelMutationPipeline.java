package at.jku.isse.fm.operator;

import java.util.ArrayList;

import at.jku.isse.fm.FMEDefaults;
import at.jku.isse.fm.FMUtils;
import at.jku.isse.fm.FMUtils.ReturnVal;
import at.jku.isse.fm.FeatureModelExtractionInitializer;
import at.jku.isse.fm.ctc.AtomNode;
import at.jku.isse.fm.ctc.ConstraintNode;
import at.jku.isse.fm.ctc.ConstraintSetNode;
import at.jku.isse.fm.ctc.NotNode;
import at.jku.isse.fm.ctc.OrNode;
import at.jku.isse.fm.data.Constraint;
import at.jku.isse.fm.data.ConstraintSet;
import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.node.BinaryRelation;
import at.jku.isse.fm.node.Relation;
import at.jku.isse.fm.node.relation.Alternative;
import at.jku.isse.fm.node.relation.Mandatory;
import at.jku.isse.fm.node.relation.Optional;
import at.jku.isse.fm.node.relation.Or;
import at.jku.isse.fm.node.relation.Root;
import ec.BreedingPipeline;
import ec.EvolutionState;
import ec.Individual;
import ec.gp.GPBreedingPipeline;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import ec.util.Parameter;

public class FeatureModelMutationPipeline extends GPBreedingPipeline {

	private static final long serialVersionUID = 1L;

	public static final int NUM_SOURCES = 1;

	public static final String P_CTC_PERCENTAGE = "ctcpercentage";
	public static final String P_MUTATE = "mutate";
	public static final String P_TREE_MUTATION_PROB = "treeprob";
	public static final String P_CTC_MUTATION_PROB = "ctcprob";

	private double ctc_percentage = 0.5;
	private double tree_mutation_prob = 0.1;
	private double ctc_mutation_prob = 0.1;

	@Override
	public Parameter defaultBase() {
		return FMEDefaults.base().push(P_MUTATE);
	}

	@Override
	public int numSources() {
		return NUM_SOURCES;
	}

	/**
	 * Returns 2 * minimum number of typical individuals produced by any sources, else 1* minimum number if tossSecondParent is true.
	 */
	@Override
	public int typicalIndsProduced() {
		return 1;
	}

	@Override
	public Object clone() {
		FeatureModelMutationPipeline c = (FeatureModelMutationPipeline) (super.clone());

		return c;
	}

	@Override
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);

		state.output.message("[FME] FeatureModelMutationPipeline.setup(): " + base);

		Parameter def = defaultBase();

		this.ctc_percentage = state.parameters.getDouble(base.push(P_CTC_PERCENTAGE), def.push(P_CTC_PERCENTAGE));

		if (this.ctc_percentage < 0.0) {
			state.output.error("[FME] CTC percentage must be a positive percentage value. Setting it to 0.5 as default.");
			this.ctc_percentage = 0.5;
		}

		this.ctc_mutation_prob = state.parameters.getDouble(base.push(P_CTC_MUTATION_PROB), def.push(P_CTC_MUTATION_PROB));
		this.tree_mutation_prob = state.parameters.getDouble(base.push(P_TREE_MUTATION_PROB), def.push(P_TREE_MUTATION_PROB));

		state.output.message("[FME] Mutator was set up with these parameters: ctc_percentage=" + this.ctc_percentage + "; ctc_mutation_prob=" + this.ctc_mutation_prob
				+ "; tree_mutation_prob=" + this.tree_mutation_prob);
	}

	@Override
	public int produce(int min, int max, int start, int subpopulation, Individual[] inds, EvolutionState state, int thread) {
		// state.output.message("[FME] +Mutation");

		// grab individuals from our source and stick 'em right into inds.
		// we'll modify them from there
		int n = sources[0].produce(min, max, start, subpopulation, inds, state, thread);

		// System.out.println("N: " + n);

		// should we bother?
		if (!state.random[thread].nextBoolean(likelihood)) {
			state.output.message("[FME] ERROR: Strange thing in Mutator happened with likelihood!");
			return reproduce(n, start, subpopulation, inds, state, thread, false); // DON'T produce children from source -- we already did
		}

		FeatureModelExtractionInitializer initializer = ((FeatureModelExtractionInitializer) state.initializer);

		// ################ BEGIN MUTATION ##################

		for (int q = start; q < n + start; q++) {
			GPIndividual i = (GPIndividual) inds[q];

			GPIndividual j;

			if (sources[0] instanceof BreedingPipeline) { // it's already a copy, so just smash the tree in
				j = i;
				j.evaluated = false;

				((Root) j.trees[0].child).products.clear();
			} else { // need to clone the individual
				// j = (GPIndividual) (i.lightClone());
				j = (GPIndividual) (i.clone());

				// Fill in various tree information that didn't get filled in there
				// j.trees = new GPTree[i.trees.length];
				j.evaluated = false;

				((Root) j.trees[0].child).products.clear();

				state.output.message("[FME] Warning in Mutator: source was not a breeding pipeline!");
			}

			if (FMUtils.countFeatures(j.trees[0].child) != initializer.ps.features.size())
				state.output.message("FEATURES MISSING (OR TOO MANY?!) IN TREE! " + FMUtils.countFeatures(j.trees[0].child) + ", " + initializer.ps.features.size());

			// if we do a mutation ...
			if (state.random[thread].nextBoolean(this.tree_mutation_prob)) {
				// ... we always only do exactly one mutation ...
				double mutation_type = state.random[thread].nextDouble(true, true);
				// ... each with equal probability
				if (mutation_type >= 0 && mutation_type < 0.25) {
					// swap two features in j
					// pick two random features
					int f1i = state.random[thread].nextInt(initializer.ps.features.size());
					int f2i = state.random[thread].nextInt(initializer.ps.features.size());
					int tries = 0;
					while (f1i == f2i && tries < 10) {
						f2i = state.random[thread].nextInt(initializer.ps.features.size());
						tries++;
					}

					// traverse the tree and get the two features
					ReturnVal r1 = FMUtils.getFeatureNode(j.trees[0].child, f1i, 0);
					ReturnVal r2 = FMUtils.getFeatureNode(j.trees[0].child, f2i, 0);

					// swap the two features
					Feature f1 = (Feature) r1.n;
					Feature f2 = (Feature) r2.n;

					if (f1 == null || f2 == null) {
						state.output.fatal("F1: " + f1 + ", F2: " + f2 + "; " + f1i + ", " + f2i + "; " + FMUtils.countFeatures(j.trees[0].child) + ", "
								+ initializer.ps.features.size());
					}

					FMUtils.swapNodes(f1, f2);
				} else if (mutation_type >= 0.25 && mutation_type < 0.5) {
					// change MANDATORY <-> OPTIONAL

					// traverse the tree and get all optional and mandatory relations
					ArrayList<BinaryRelation> relations = new ArrayList<BinaryRelation>();
					FMUtils.getAllBinaryRelations(j.trees[0].child, relations);

					if (relations.size() > 0) {
						// choose one randomly
						int r = state.random[thread].nextInt(relations.size());
						Relation relation = relations.get(r);

						// change it
						if (state.random[thread].nextBoolean(0.70)) { // TODO: make this a parameter
							// keep the relation binary
							if (relation instanceof Mandatory) {
								Optional optional = new Optional();
								optional.resetNode(state, thread);
								FMUtils.replaceNode(relation, optional);
							} else if (relation instanceof Optional) {
								Mandatory mandatory = new Mandatory();
								mandatory.resetNode(state, thread);
								FMUtils.replaceNode(relation, mandatory);
							} else {
								state.output.fatal("[FME] Error in Mutation: Relation should have been either Mandatory or Optional, but it was not.");
							}
						} else {
							// make the relation a group relation
							if (state.random[thread].nextBoolean(0.5)) {
								Or or = new Or();
								or.resetNode(state, thread);
								FMUtils.replaceNode(relation, or);
							} else {
								Alternative alt = new Alternative();
								alt.resetNode(state, thread);
								FMUtils.replaceNode(relation, alt);
							}
						}
					}
				} else if (mutation_type >= 0.5 && mutation_type < 0.75) {
					// change ALTERNATIVE <-> OR

					// traverse the tree and get all or and alternative relations
					ArrayList<Relation> relations = new ArrayList<Relation>();
					FMUtils.getAllGroupRelations(j.trees[0].child, relations);

					if (relations.size() > 0) {
						// choose one randomly
						int r = state.random[thread].nextInt(relations.size());
						Relation relation = relations.get(r);

						// change it
						if (relation instanceof Alternative) {
							Or or = new Or();
							or.resetNode(state, thread);
							FMUtils.replaceNode(relation, or);
						} else if (relation instanceof Or) {
							Alternative alt = new Alternative();
							alt.resetNode(state, thread);
							FMUtils.replaceNode(relation, alt);
						} else {
							state.output.fatal("[FME] Error in Mutation: Relation should have been either Alternative or Or, but it was not.");
						}
					}
				} else if (mutation_type >= 0.75 && mutation_type <= 1) {
					// move a subtree

					// pick a random node in the tree (except the root node and the root feature)
					int treesize = FMUtils.treeSize(j.trees[0].child);
					int r = state.random[thread].nextInt(treesize - 2);
					ReturnVal rv = FMUtils.getNode(j.trees[0].child, r + 2, 0);
					GPNode node = rv.n;

					// if it is a relation detach it and put it below a random feature in the remaining tree that is not its current parent
					if (node instanceof Relation) {

						// detach
						FMUtils.detachNode(node);

						// get random feature node in remaining tree
						int num_features = FMUtils.countFeatures(j.trees[0].child);
						int rf = state.random[thread].nextInt(num_features);
						rv = FMUtils.getFeatureNode(j.trees[0].child, rf, 0);

						// make relation a child of that feature
						FMUtils.attachNode(node, rv.n);
					}
					// if it is a feature ...
					else if (node instanceof Feature) {

						if (node.parent instanceof BinaryRelation || ((GPNode) node.parent).children.length <= 1) {
							FMUtils.detachNode((GPNode) node.parent);

							int num_features = FMUtils.countFeatures(j.trees[0].child);
							int rf = state.random[thread].nextInt(num_features);
							rv = FMUtils.getFeatureNode(j.trees[0].child, rf, 0);

							FMUtils.attachNode((GPNode) node.parent, rv.n);
						} else {
							FMUtils.detachNode(node);

							ArrayList<Relation> relations = new ArrayList<Relation>();
							FMUtils.getAllRelations(j.trees[0].child.children[0], relations); // any relation but the root relation, otherwise the root could get more than 1 child

							Relation rel = relations.get(state.random[thread].nextInt(relations.size()));

							if (rel instanceof BinaryRelation) {
								BinaryRelation br = (BinaryRelation) rel.lightClone();
								br.children = new GPNode[0];

								FMUtils.attachNode(node, br);

								FMUtils.attachNode(br, (GPNode) rel.parent);
							} else {
								FMUtils.attachNode(node, rel);
							}

						}
					} else {
						state.output.fatal("[FME] Error in Mutator: Selected node is neither Relation nor Feature! " + node);
					}

				} else {
					state.output.fatal("[FME] Selected a non-existant mutation type.");
				}
			}

			// if we do a ctc mutation ...
			if (state.random[thread].nextBoolean(this.ctc_mutation_prob)) {

				ConstraintSetNode csn = (ConstraintSetNode) j.trees[1].child;
				ConstraintSet cs = new ConstraintSet();
				FMUtils.collectConstraints(csn, cs);

				int num_features = initializer.ps.features.size();
				int max_num_constraints = (int) Math.round(num_features * this.ctc_percentage);

				// if (cs.constraints.size() >= max_num_constraints) { // remove a ctc
				//
				// } else if (cs.constraints.size() <= 0) { // add a ctc
				//
				// } else { // randomly either add or remove a CTC
				if (state.random[thread].nextBoolean(0.5)) { // remove
					if (cs.constraints.size() > 0) {
						// determine which constraint to remove
						int r = state.random[thread].nextInt(csn.children.length);
						ConstraintNode cn = (ConstraintNode) csn.children[r];
						// remove it
						FMUtils.detachNode(cn);
					}
				} else { // add
					if (cs.constraints.size() < max_num_constraints) {
						// come up with a random new constraint
						int tries = 0;
						boolean found_one = false;
						while (!found_one && tries < 10) {
							Feature f1 = null, f2 = null;
							int f1r = state.random[thread].nextInt(initializer.ps.features.size());
							int f2r = state.random[thread].nextInt(initializer.ps.features.size());
							while (f1r == f2r)
								f2r = state.random[thread].nextInt(initializer.ps.features.size());
							int k = 0;
							for (Feature f : initializer.ps.features) {
								if (k == f1r)
									f1 = f;
								if (k == f2r)
									f2 = f;
								k++;
							}
							// exclude
							Constraint excludes = new Constraint();
							excludes.neg.add(f1);
							excludes.neg.add(f2);

							if (!cs.constraints.contains(excludes)) { // there must not already be an exclude constraint with these features

								// f1 requires f2
								Constraint requires1 = new Constraint();
								requires1.neg.add(f1);
								requires1.pos.add(f2);
								// f2 requires f1
								Constraint requires2 = new Constraint();
								requires2.neg.add(f1);
								requires2.pos.add(f2);

								// pick constraint
								ArrayList<Constraint> constraint_list = new ArrayList<Constraint>();
								if (!cs.constraints.contains(requires1) && !cs.constraints.contains(requires2))
									constraint_list.add(excludes);
								if (!cs.constraints.contains(requires1))
									constraint_list.add(requires1);
								if (!cs.constraints.contains(requires1))
									constraint_list.add(requires2);

								if (constraint_list.size() > 0) {
									int random_constraint = state.random[thread].nextInt(constraint_list.size());
									Constraint picked_constraint = constraint_list.get(random_constraint);

									// add it
									ConstraintNode cn = new ConstraintNode();
									cn.resetNode(state, thread);
									cn.children = new GPNode[1];

									FMUtils.attachNode(cn, csn);

									OrNode ornode = new OrNode();
									ornode.resetNode(state, thread);
									ornode.parent = cn;
									ornode.children = new GPNode[0];
									ornode.argposition = (byte) 0;

									cn.children[0] = ornode;

									// neg features (requiring a not node)
									for (Feature f : picked_constraint.neg) {
										NotNode notnode = new NotNode();
										AtomNode atomnode = new AtomNode();
										Feature new_f = new Feature(f.getName());
										new_f.children = new GPNode[0];
										FMUtils.attachNode(new_f, atomnode);
										FMUtils.attachNode(atomnode, notnode);
										FMUtils.attachNode(notnode, ornode);
									}

									// pos features
									for (Feature f : picked_constraint.pos) {
										AtomNode atomnode = new AtomNode();
										Feature new_f = new Feature(f.getName());
										new_f.children = new GPNode[0];
										FMUtils.attachNode(new_f, atomnode);
										FMUtils.attachNode(atomnode, ornode);
									}

									found_one = true;
								}

							}

							tries++;
						}
					}
				}
				// }

			}

			// add the new individual, replacing its previous source
			inds[q] = j;
		}
		return n;
	}

}
