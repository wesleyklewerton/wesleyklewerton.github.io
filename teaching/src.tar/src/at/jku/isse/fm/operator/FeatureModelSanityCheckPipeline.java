package at.jku.isse.fm.operator;

public class FeatureModelSanityCheckPipeline {

}
