package at.jku.isse.fm.operator;

import java.util.Collection;
import java.util.Iterator;

import at.jku.isse.fm.FMEDefaults;
import at.jku.isse.fm.FeatureModelExtractionInitializer;
import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.node.relation.Alternative;
import at.jku.isse.fm.node.relation.Mandatory;
import at.jku.isse.fm.node.relation.Optional;
import at.jku.isse.fm.node.relation.Or;
import at.jku.isse.fm.node.relation.Root;
import ec.EvolutionState;
import ec.gp.GPFunctionSet;
import ec.gp.GPNode;
import ec.gp.GPNodeBuilder;
import ec.gp.GPNodeParent;
import ec.gp.GPType;
import ec.util.Parameter;
import es.us.isa.FAMA.Reasoner.Reasoner;
import es.us.isa.FAMA.Reasoner.questions.ProductsQuestion;
import es.us.isa.FAMA.models.FAMAfeatureModel.FAMAFeatureModel;
import es.us.isa.FAMA.models.FAMAfeatureModel.Relation;
import es.us.isa.FAMA.models.featureModel.GenericFeature;
import es.us.isa.FAMA.models.featureModel.Product;
import es.us.isa.FAMA.models.variabilityModel.GenericProduct;
import es.us.isa.JavaBDDReasoner.JavaBDDReasoner;
import es.us.isa.JavaBDDReasoner.questions.JavaBDDProductsQuestion;
import es.us.isa.generator.FM.AbstractFMGenerator;
import es.us.isa.generator.FM.FMGenerator;
import es.us.isa.generator.FM.GeneratorCharacteristics;

public class FeatureModelBuilder extends GPNodeBuilder {

	private static final long serialVersionUID = 1L;

	@Override
	public Parameter defaultBase() {
		return FMEDefaults.base().push("builder");
	}

	@Override
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);

		Parameter def = defaultBase();

	}

	private GPNode createRandomFM(Collection<Feature> features, EvolutionState state, int thread) {

		GeneratorCharacteristics ch = new GeneratorCharacteristics();
		ch.setNumberOfFeatures(features.size());
		ch.setPercentageCTC(0);
		ch.setSeed(state.random[thread].nextLong());

		AbstractFMGenerator generator = new FMGenerator();
		generator.resetGenerator(ch);

		FAMAFeatureModel model = (FAMAFeatureModel) generator.generateFM(ch);

		int num_features_not_assigned = features.size();
		int current_features_index = state.random[thread].nextInt(features.size());
		String[] temp_feature_names = new String[features.size()];
		int i = 0;
		for (Feature feature : features) {
			temp_feature_names[i] = feature.getName();
			i++;
		}
		for (es.us.isa.FAMA.models.FAMAfeatureModel.Feature f : model.getFeatures()) {
			// assign feature name
			f.setName(temp_feature_names[current_features_index]);
			temp_feature_names[current_features_index] = null;
			num_features_not_assigned--;

			if (num_features_not_assigned > 0) {

				int r = state.random[thread].nextInt(num_features_not_assigned);

				while (r >= 0) {
					current_features_index++;
					if (current_features_index >= features.size())
						current_features_index = 0;
					while (temp_feature_names[current_features_index] == null) {
						current_features_index++;
						if (current_features_index >= features.size())
							current_features_index = 0;
					}
					r--;
				}

			}

		}

		// Collection<VariabilityElement> list = (Collection<VariabilityElement>) model.getElements();
		// System.out.println(model.getRoot().getChilds());
		// System.out.println(model.getRoot().getRelationAt(0).isOptional() + " - " + model.getRoot().getRelationAt(0).isMandatory());
		// System.out.println(model.getRoot().getRelationAt(0).isAlternative() + " - " + model.getRoot().getRelationAt(0).isOr());
		// Iterator it = model.getRoot().getRelationAt(0).getCardinalities();
		// while (it.hasNext()) {
		// System.out.println(it.next());
		// }
		// System.out.println(model.getRoot().getNumberOfRelations());
		// System.out.println(model.getRoot().getRelationAt(0).getDestColl());
		// System.out.println(model.getRoot().getRelationAt(0).getNumberOfDestination());

		// convert to GP tree
		Root root = new Root();
		root.resetNode(state, thread);
		root.children = new GPNode[1];
		root.children[0] = getGPNodeFromFeature(state, thread, model.getRoot(), root, 0);

		// TODO: remove this for performance: stores FAMA results for later comparison with my evaluation results
		// #############
//		ProductsQuestion products_question = new JavaBDDProductsQuestion();
//		Reasoner reasoner = new JavaBDDReasoner();
//		model.transformTo(reasoner);
//		reasoner.ask(products_question);
//
//		Collection<? extends GenericProduct> fama_products = (Collection<? extends GenericProduct>) products_question.getAllProducts();
//
//		for (GenericProduct fama_generic_product : fama_products) {
//			at.jku.isse.fm.data.Product product = new at.jku.isse.fm.data.Product();
//			for (GenericFeature fama_generic_feature : ((Product) fama_generic_product).getFeatures()) {
//				product.add(new at.jku.isse.fm.data.Feature(fama_generic_feature.getName()));
//			}
//			root.products.add(product);
//			// state.output.message("DEBUG: " + product);
//		}
		// #############

		return root;
	}

	private GPNode getGPNodeFromFeature(final EvolutionState state, final int thread, es.us.isa.FAMA.models.FAMAfeatureModel.Feature feature, final GPNodeParent parent,
			final int argposition) {

		// create node for feature
		GPNode feature_node = new Feature(feature.getName());
		feature_node.resetNode(state, thread);
		feature_node.argposition = (byte) argposition;
		feature_node.parent = parent;
		feature_node.children = new GPNode[feature.getNumberOfRelations()]; // one child for every relation

		// go through all relations and create child nodes for them
		int i = 0;
		Iterator<Relation> rel_it = feature.getRelations();
		while (rel_it.hasNext()) {
			Relation relation = rel_it.next();
			GPNode rel_node = null;
			if (relation.isOptional()) {
				rel_node = new Optional();
			} else if (relation.isMandatory()) {
				rel_node = new Mandatory();
			} else if (relation.isAlternative()) {
				rel_node = new Alternative();
			} else if (relation.isOr()) {
				rel_node = new Or();
			} else {
				state.output.fatal("[FME] Error converting FAMA model to GP tree: unknown relation.");
			}
			// add relation as child to current feature
			if (rel_node != null) {
				rel_node.resetNode(state, thread);
				rel_node.argposition = (byte) i;
				rel_node.parent = feature_node;
				rel_node.children = new GPNode[relation.getNumberOfDestination()];
				// rel_node.children = new GPNode[0];
				feature_node.children[i] = rel_node;
				i++;
				int j = 0;
				Iterator<es.us.isa.FAMA.models.FAMAfeatureModel.Feature> feature_it = relation.getDestination();
				while (feature_it.hasNext()) {
					rel_node.children[j] = getGPNodeFromFeature(state, thread, feature_it.next(), rel_node, j);
					j++;
				}
				if (j != relation.getNumberOfDestination()) {
					state.output.fatal("[FME] Error converting FAMA model to GP tree: number of destinations (features) do not match.");
				}
			}
		}
		if (i != feature.getNumberOfRelations()) {
			state.output.fatal("[FME] Error converting FAMA model to GP tree: number of relations do not match.");
		}

		return feature_node;
	}

	public GPNode newRootedTree(final EvolutionState state, final GPType type, final int thread, final GPNodeParent parent, final GPFunctionSet set, final int argposition,
			final int requestedSize) {

		GPNode root = this.createRandomFM(((FeatureModelExtractionInitializer) state.initializer).ps.features, state, thread);
		// root.resetNode(state, thread);
		root.argposition = (byte) argposition;
		root.parent = parent;

		return root;
	}

}
