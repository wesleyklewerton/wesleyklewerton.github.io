package at.jku.isse.fm.operator;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;

import at.jku.isse.fm.FMEDefaults;
import at.jku.isse.fm.FMUtils;
import at.jku.isse.fm.FeatureModelExtractionInitializer;
import at.jku.isse.fm.ctc.AtomNode;
import at.jku.isse.fm.ctc.ConstraintNode;
import at.jku.isse.fm.ctc.ConstraintSetNode;
import at.jku.isse.fm.ctc.NotNode;
import at.jku.isse.fm.ctc.OrNode;
import at.jku.isse.fm.data.Feature;
import ec.EvolutionState;
import ec.gp.GPFunctionSet;
import ec.gp.GPNode;
import ec.gp.GPNodeBuilder;
import ec.gp.GPNodeParent;
import ec.gp.GPType;
import ec.util.Parameter;

public class CTCBuilder extends GPNodeBuilder {

	private static final long serialVersionUID = 1L;

	public static final String P_BUILDER = "builder";
	public static final String P_CTC_PERCENTAGE = "ctcpercentage";

	private double ctc_percentage = 0.5;

	@Override
	public Parameter defaultBase() {
		return FMEDefaults.base().push(P_BUILDER);
	}

	@Override
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);

		Parameter def = defaultBase();

		this.ctc_percentage = state.parameters.getDouble(base.push(P_CTC_PERCENTAGE), def.push(P_CTC_PERCENTAGE));

		if (this.ctc_percentage < 0.0) {
			state.output.error("[FME] CTC percentage must be a positive percentage value. Setting it to 0.5 as default.");
			this.ctc_percentage = 0.5;
		}

		state.output.message("[FME] CTCBuilder was set up with these parameters: ctc_percentage=" + this.ctc_percentage);
	}

	@Override
	public GPNode newRootedTree(EvolutionState state, GPType type, int thread, GPNodeParent parent, GPFunctionSet set, int argposition, int requestedSize) {
		ConstraintSetNode csn = new ConstraintSetNode();
		csn.resetNode(state, thread);
		csn.argposition = (byte) argposition;
		csn.parent = parent;

		FeatureModelExtractionInitializer initializer = (FeatureModelExtractionInitializer) state.initializer;
		int num_features = initializer.ps.features.size();
		int max_num_constraints = (int) Math.round(num_features * this.ctc_percentage);
		int num_constraints = state.random[thread].nextInt(max_num_constraints + 1); // 0 to the max number of constraints (including)

		// csn.children = new GPNode[num_constraints];
		csn.children = new GPNode[0];

		// initialize the set with all allowed combinations
		LinkedHashMap<Feature, LinkedHashSet<Feature>> combs = new LinkedHashMap<Feature, LinkedHashSet<Feature>>();
		for (Feature f : initializer.ps.features) {
			LinkedHashSet<Feature> fs = new LinkedHashSet<Feature>();
			fs.addAll(initializer.ps.features);
			fs.remove(f);
			combs.put(f, fs);
		}

		for (int i = 0; i < num_constraints && combs.size() > 0; i++) {

			ConstraintNode cn = new ConstraintNode();
			cn.resetNode(state, thread);
			cn.children = new GPNode[1];
			cn.argposition = (byte) i;
			cn.parent = csn;

			// csn.children[i] = cn;
			FMUtils.attachNode(cn, csn);

			OrNode ornode = new OrNode();
			ornode.resetNode(state, thread);
			ornode.parent = cn;
			ornode.children = new GPNode[0];
			ornode.argposition = (byte) 0;

			cn.children[0] = ornode;

			// pick two random features
			Feature f1 = null, f2 = null;

			// get first feature
			int f1r = state.random[thread].nextInt(combs.size());
			int j = 0;
			for (Feature f : combs.keySet()) {
				if (j == f1r)
					f1 = f;
				j++;
			}

			// get second feature
			Set<Feature> allowed_features = combs.get(f1);
			int f2r = state.random[thread].nextInt(allowed_features.size());
			j = 0;
			for (Feature f : allowed_features) {
				if (j == f2r)
					f2 = f;
				j++;
			}

			if (f1 == null || f2 == null)
				state.output.fatal("[FME] One of the constraint features is null!");

			int ctctype = state.random[thread].nextInt(2);

			if (ctctype == 0 || !(combs.get(f2).contains(f1))) { // requires
				// the same requires constraint may not occur again
				combs.get(f1).remove(f2);
				if (combs.get(f1).size() == 0)
					combs.remove(f1);

				NotNode notnode = new NotNode();
				notnode.children = new GPNode[0];
				AtomNode atomnode1 = new AtomNode();
				atomnode1.children = new GPNode[0];
				AtomNode atomnode2 = new AtomNode();
				atomnode2.children = new GPNode[0];
				Feature new_f1 = new Feature(f1.getName());
				new_f1.children = new GPNode[0];
				Feature new_f2 = new Feature(f2.getName());
				new_f2.children = new GPNode[0];

				FMUtils.attachNode(new_f1, atomnode1);
				FMUtils.attachNode(new_f2, atomnode2);
				FMUtils.attachNode(atomnode1, notnode);
				FMUtils.attachNode(notnode, ornode);
				FMUtils.attachNode(atomnode2, ornode);
			} else if (ctctype == 1) { // exclude
				// these two feature may not occur together in a CTC anymore
				combs.get(f1).remove(f2);
				if (combs.get(f1).size() == 0)
					combs.remove(f1);
				combs.get(f2).remove(f1);
				if (combs.get(f2).size() == 0)
					combs.remove(f2);

				NotNode notnode1 = new NotNode();
				notnode1.children = new GPNode[0];
				NotNode notnode2 = new NotNode();
				notnode2.children = new GPNode[0];
				AtomNode atomnode1 = new AtomNode();
				atomnode1.children = new GPNode[0];
				AtomNode atomnode2 = new AtomNode();
				atomnode2.children = new GPNode[0];
				Feature new_f1 = new Feature(f1.getName());
				new_f1.children = new GPNode[0];
				Feature new_f2 = new Feature(f2.getName());
				new_f2.children = new GPNode[0];

				FMUtils.attachNode(new_f1, atomnode1);
				FMUtils.attachNode(new_f2, atomnode2);
				FMUtils.attachNode(atomnode1, notnode1);
				FMUtils.attachNode(atomnode2, notnode2);
				FMUtils.attachNode(notnode1, ornode);
				FMUtils.attachNode(notnode2, ornode);
			}

		}

		return csn;
	}

}
