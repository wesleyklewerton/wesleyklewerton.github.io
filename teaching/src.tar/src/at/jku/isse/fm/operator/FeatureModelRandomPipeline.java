package at.jku.isse.fm.operator;

import java.util.Collection;
import java.util.Iterator;

import at.jku.isse.fm.FMEDefaults;
import at.jku.isse.fm.FMUtils;
import at.jku.isse.fm.FeatureModelExtractionInitializer;
import at.jku.isse.fm.ctc.AtomNode;
import at.jku.isse.fm.ctc.ConstraintNode;
import at.jku.isse.fm.ctc.ConstraintSetNode;
import at.jku.isse.fm.ctc.NotNode;
import at.jku.isse.fm.ctc.OrNode;
import at.jku.isse.fm.data.Feature;
import at.jku.isse.fm.node.relation.Alternative;
import at.jku.isse.fm.node.relation.Mandatory;
import at.jku.isse.fm.node.relation.Optional;
import at.jku.isse.fm.node.relation.Or;
import at.jku.isse.fm.node.relation.Root;
import ec.EvolutionState;
import ec.Individual;
import ec.gp.GPBreedingPipeline;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import ec.gp.GPNodeParent;
import ec.util.Parameter;
import es.us.isa.FAMA.Reasoner.Reasoner;
import es.us.isa.FAMA.Reasoner.questions.ProductsQuestion;
import es.us.isa.FAMA.models.FAMAfeatureModel.Dependency;
import es.us.isa.FAMA.models.FAMAfeatureModel.ExcludesDependency;
import es.us.isa.FAMA.models.FAMAfeatureModel.FAMAFeatureModel;
import es.us.isa.FAMA.models.FAMAfeatureModel.Relation;
import es.us.isa.FAMA.models.FAMAfeatureModel.RequiresDependency;
import es.us.isa.FAMA.models.featureModel.GenericFeature;
import es.us.isa.FAMA.models.featureModel.Product;
import es.us.isa.FAMA.models.variabilityModel.GenericProduct;
import es.us.isa.JavaBDDReasoner.JavaBDDReasoner;
import es.us.isa.JavaBDDReasoner.questions.JavaBDDProductsQuestion;
import es.us.isa.generator.FM.AbstractFMGenerator;
import es.us.isa.generator.FM.FMGenerator;
import es.us.isa.generator.FM.GeneratorCharacteristics;

public class FeatureModelRandomPipeline extends GPBreedingPipeline {

	private static final long serialVersionUID = 1L;

	public static final int NUM_SOURCES = 1;

	public static final String P_CTC_PERCENTAGE = "ctcpercentage";
	public static final String P_RANDOM = "random";
	public static final String P_TREE_MUTATION_PROB = "treeprob";
	public static final String P_CTC_MUTATION_PROB = "ctcprob";

	private double ctc_percentage = 0.5;

	@Override
	public Parameter defaultBase() {
		return FMEDefaults.base().push(P_RANDOM);
	}

	@Override
	public int numSources() {
		return NUM_SOURCES;
	}

	/**
	 * Returns 2 * minimum number of typical individuals produced by any sources, else 1* minimum number if tossSecondParent is true.
	 */
	@Override
	public int typicalIndsProduced() {
		return 1;
	}

	@Override
	public Object clone() {
		FeatureModelRandomPipeline c = (FeatureModelRandomPipeline) (super.clone());

		return c;
	}

	@Override
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);

		state.output.message("[FME] FeatureModelRandomPipeline.setup(): " + base);

		Parameter def = defaultBase();

		this.ctc_percentage = state.parameters.getDouble(base.push(P_CTC_PERCENTAGE), def.push(P_CTC_PERCENTAGE));

		if (this.ctc_percentage < 0.0) {
			state.output.error("[FME] CTC percentage must be a positive percentage value. Setting it to 0.5 as default.");
			this.ctc_percentage = 0.5;
		}

		state.output.message("[FME] Mutator was set up with these parameters: ctc_percentage=" + this.ctc_percentage);
	}

	@Override
	public int produce(int min, int max, int start, int subpopulation, Individual[] inds, EvolutionState state, int thread) {
		// state.output.message("[FME] +Mutation");

		state.output.message("[FME] RANDOM Mutation");
		
		// grab individuals from our source and stick 'em right into inds.
		// we'll modify them from there
		int n = sources[0].produce(min, max, start, subpopulation, inds, state, thread);

		// should we bother?
		if (!state.random[thread].nextBoolean(likelihood)) {
			state.output.message("[FME] ERROR: Strange thing in Mutator happened with likelihood!");
			return reproduce(n, start, subpopulation, inds, state, thread, false); // DON'T produce children from source -- we already did
		}

		FeatureModelExtractionInitializer initializer = ((FeatureModelExtractionInitializer) state.initializer);

		// ################ BEGIN MUTATION ##################

		for (int q = start; q < n + start; q++) {
			GPIndividual j = ((GPIndividual) inds[q]).lightClone();
			j.evaluated = false;

			// create random feature model

			Collection<Feature> features = initializer.ps.features;

			float rctc = state.random[thread].nextFloat(true, true) * (float) this.ctc_percentage;

			GeneratorCharacteristics ch = new GeneratorCharacteristics();
			ch.setNumberOfFeatures(features.size());
			ch.setPercentageCTC(rctc * 100);
			ch.setSeed(state.random[thread].nextLong());

			AbstractFMGenerator generator = new FMGenerator();
			generator.resetGenerator(ch);

			FAMAFeatureModel model = (FAMAFeatureModel) generator.generateFM(ch);

			int num_features_not_assigned = features.size();
			int current_features_index = state.random[thread].nextInt(features.size());
			String[] temp_feature_names = new String[features.size()];
			int i = 0;
			for (Feature feature : features) {
				temp_feature_names[i] = feature.getName();
				i++;
			}
			for (es.us.isa.FAMA.models.FAMAfeatureModel.Feature f : model.getFeatures()) {
				// assign feature name
				f.setName(temp_feature_names[current_features_index]);
				temp_feature_names[current_features_index] = null;
				num_features_not_assigned--;

				if (num_features_not_assigned > 0) {

					int r = state.random[thread].nextInt(num_features_not_assigned);

					while (r >= 0) {
						current_features_index++;
						if (current_features_index >= features.size())
							current_features_index = 0;
						while (temp_feature_names[current_features_index] == null) {
							current_features_index++;
							if (current_features_index >= features.size())
								current_features_index = 0;
						}
						r--;
					}

				}

			}

			// convert to GP tree (feature tree part trees[0])
			Root root = new Root();
			root.resetNode(state, thread);
			root.children = new GPNode[1];
			root.children[0] = getGPNodeFromFeature(state, thread, model.getRoot(), root, 0);

			// TODO: remove this for performance: stores FAMA results for later comparison with my evaluation results
			// #############
//			ProductsQuestion products_question = new JavaBDDProductsQuestion();
//			Reasoner reasoner = new JavaBDDReasoner();
//			model.transformTo(reasoner);
//			reasoner.ask(products_question);
//
//			Collection<? extends GenericProduct> fama_products = (Collection<? extends GenericProduct>) products_question.getAllProducts();
//
//			for (GenericProduct fama_generic_product : fama_products) {
//				at.jku.isse.fm.data.Product product = new at.jku.isse.fm.data.Product();
//				for (GenericFeature fama_generic_feature : ((Product) fama_generic_product).getFeatures()) {
//					product.add(new at.jku.isse.fm.data.Feature(fama_generic_feature.getName()));
//				}
//				root.products.add(product);
//				// state.output.message("DEBUG: " + product);
//			}
			// #############

			j.trees[0].child = root;
			root.parent = j.trees[0];
			root.argposition = (byte) 0;

			// do the ctc part trees[1]
			ConstraintSetNode csn = this.getGPNodeFromDependency(state, thread, model);
			j.trees[1].child = csn;
			csn.parent = j.trees[1];
			csn.argposition = (byte) 0;

			// add the new individual, replacing its previous source
			inds[q] = j;
		}
		return n;
	}

	private GPNode getGPNodeFromFeature(final EvolutionState state, final int thread, es.us.isa.FAMA.models.FAMAfeatureModel.Feature feature, final GPNodeParent parent,
			final int argposition) {

		// create node for feature
		GPNode feature_node = new Feature(feature.getName());
		feature_node.resetNode(state, thread);
		feature_node.argposition = (byte) argposition;
		feature_node.parent = parent;
		feature_node.children = new GPNode[feature.getNumberOfRelations()]; // one child for every relation

		// go through all relations and create child nodes for them
		int i = 0;
		Iterator<Relation> rel_it = feature.getRelations();
		while (rel_it.hasNext()) {
			Relation relation = rel_it.next();
			GPNode rel_node = null;
			if (relation.isOptional()) {
				rel_node = new Optional();
			} else if (relation.isMandatory()) {
				rel_node = new Mandatory();
			} else if (relation.isAlternative()) {
				rel_node = new Alternative();
			} else if (relation.isOr()) {
				rel_node = new Or();
			} else {
				state.output.fatal("[FME] Error converting FAMA model to GP tree: unknown relation.");
			}
			// add relation as child to current feature
			if (rel_node != null) {
				rel_node.resetNode(state, thread);
				rel_node.argposition = (byte) i;
				rel_node.parent = feature_node;
				rel_node.children = new GPNode[relation.getNumberOfDestination()];
				// rel_node.children = new GPNode[0];
				feature_node.children[i] = rel_node;
				i++;
				int j = 0;
				Iterator<es.us.isa.FAMA.models.FAMAfeatureModel.Feature> feature_it = relation.getDestination();
				while (feature_it.hasNext()) {
					rel_node.children[j] = getGPNodeFromFeature(state, thread, feature_it.next(), rel_node, j);
					j++;
				}
				if (j != relation.getNumberOfDestination()) {
					state.output.fatal("[FME] Error converting FAMA model to GP tree: number of destinations (features) do not match.");
				}
			}
		}
		if (i != feature.getNumberOfRelations()) {
			state.output.fatal("[FME] Error converting FAMA model to GP tree: number of relations do not match.");
		}

		return feature_node;
	}

	private ConstraintSetNode getGPNodeFromDependency(final EvolutionState state, final int thread, FAMAFeatureModel model) {

		// System.out.println("NUM_CTCS: " + model.getNumberOfDependencies());

		ConstraintSetNode csn = new ConstraintSetNode();
		csn.resetNode(state, thread);
		csn.children = new GPNode[0];

		Iterator<Dependency> it = model.getDependencies();
		int i = 0;
		while (it.hasNext()) {
			Dependency d = it.next();

			ConstraintNode cn = new ConstraintNode();
			cn.resetNode(state, thread);
			cn.children = new GPNode[1];
			cn.argposition = (byte) i;
			cn.parent = csn;

			// csn.children[i] = cn;
			FMUtils.attachNode(cn, csn);

			OrNode ornode = new OrNode();
			ornode.resetNode(state, thread);
			ornode.parent = cn;
			ornode.children = new GPNode[0];
			ornode.argposition = (byte) 0;

			cn.children[0] = ornode;

			if (d instanceof RequiresDependency) {
				// System.out.println("REQUIRES: " + d.toString() + ";" + d.getOrigin() + ";" + d.getDestination() + ";" + d.getName() + ";");

				NotNode notnode = new NotNode();
				notnode.children = new GPNode[0];
				AtomNode atomnode1 = new AtomNode();
				atomnode1.children = new GPNode[0];
				AtomNode atomnode2 = new AtomNode();
				atomnode2.children = new GPNode[0];
				Feature new_f1 = new Feature(d.getOrigin().getName());
				new_f1.children = new GPNode[0];
				Feature new_f2 = new Feature(d.getDestination().getName());
				new_f2.children = new GPNode[0];

				FMUtils.attachNode(new_f1, atomnode1);
				FMUtils.attachNode(new_f2, atomnode2);
				FMUtils.attachNode(atomnode1, notnode);
				FMUtils.attachNode(notnode, ornode);
				FMUtils.attachNode(atomnode2, ornode);

			} else if (d instanceof ExcludesDependency) {
				// System.out.println("EXCLUDES: " + d.toString() + ";" + d.getOrigin() + ";" + d.getDestination() + ";" + d.getName() + ";");

				NotNode notnode1 = new NotNode();
				notnode1.children = new GPNode[0];
				NotNode notnode2 = new NotNode();
				notnode2.children = new GPNode[0];
				AtomNode atomnode1 = new AtomNode();
				atomnode1.children = new GPNode[0];
				AtomNode atomnode2 = new AtomNode();
				atomnode2.children = new GPNode[0];
				Feature new_f1 = new Feature(d.getOrigin().getName());
				new_f1.children = new GPNode[0];
				Feature new_f2 = new Feature(d.getDestination().getName());
				new_f2.children = new GPNode[0];

				FMUtils.attachNode(new_f1, atomnode1);
				FMUtils.attachNode(new_f2, atomnode2);
				FMUtils.attachNode(atomnode1, notnode1);
				FMUtils.attachNode(atomnode2, notnode2);
				FMUtils.attachNode(notnode1, ornode);
				FMUtils.attachNode(notnode2, ornode);

			} else {
				state.output.fatal("[FME] Unknown constraint: " + d.toString());
			}

			i++;
		}

		return csn;
	}

}
