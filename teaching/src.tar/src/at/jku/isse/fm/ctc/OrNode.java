package at.jku.isse.fm.ctc;

import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class OrNode extends GPNode {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Or";
	}

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {

		if (this.children.length < 1) {
			state.output.fatal("[FME] Error evaluating individual: ctc or node must have at least one child.");
		}

		for (int i = 0; i < this.children.length; i++) {
			this.children[i].eval(state, thread, input, stack, individual, problem);
		}

	}

}
