package at.jku.isse.fm.ctc;

import at.jku.isse.fm.data.Constraint;
import at.jku.isse.fm.data.Feature;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class AtomNode extends GPNode {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Atom";
	}

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {

		Constraint c = (Constraint) (input);

		c.pos.add((Feature) this.children[0]);

	}

}
