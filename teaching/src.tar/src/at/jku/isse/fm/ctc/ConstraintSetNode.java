package at.jku.isse.fm.ctc;

import at.jku.isse.fm.data.Constraint;
import at.jku.isse.fm.data.ConstraintSet;
import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

/*
 * Input is a constraint set that is filled during the eval traversal.
 */

public class ConstraintSetNode extends GPNode {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "ConstraintSet";
	}

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {

		ConstraintSet cs = (ConstraintSet) (input);

		if (cs.constraints.size() != 0) {
			state.output.fatal("[FME] Error evaluating individual: initial constraint set was not empty (" + cs.constraints.size() + "). " + cs.constraints);
		}

		for (int i = 0; i < this.children.length; i++) {
			Constraint c = new Constraint();
			this.children[i].eval(state, thread, c, stack, individual, problem);
			cs.constraints.add(c);
		}

	}

}
