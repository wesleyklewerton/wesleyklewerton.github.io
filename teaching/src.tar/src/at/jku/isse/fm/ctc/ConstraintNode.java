package at.jku.isse.fm.ctc;

import ec.EvolutionState;
import ec.Problem;
import ec.gp.ADFStack;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;

public class ConstraintNode extends GPNode {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Constraint";
	}

	/*
	 * The input here is of type Constraint.
	 */

	@Override
	public void eval(EvolutionState state, int thread, GPData input, ADFStack stack, GPIndividual individual, Problem problem) {

		if (this.children.length != 1) {
			state.output.fatal("[FME] Error evaluating individual: constraint node must have exactly one child.");
		}

		this.children[0].eval(state, thread, input, stack, individual, problem);
	}

}
