package batch;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BatchRandom {

	private static final int FM_OFFSET = 0;

	public static void main(String[] args) throws IOException, InterruptedException {

		// do preparations
		String[] classpathentries = new String[] { ".", "bin/", "lib/*", "lib/ecj/*", "lib/fama/*", "lib/fama/JavaBDD/*", "lib/fama/Sat4j/*" };

		System.out.println("RANDOM BATCH RUN STARTED!");

		// for every feature model ...
		File modelfolder = new File("fmfiles/");
		String[] modelnames = modelfolder.list();
		System.out.println("Models: ");
		for (String s : modelnames) {
			System.out.println(s);
		}
		System.out.println("-----------");

		for (int j = FM_OFFSET; j < modelnames.length; j++) {

			String modelname = modelnames[j];

			if (modelname.startsWith("."))
				continue;

			File modelfile = new File(modelfolder, modelname);

			System.out.println("Feature Model: " + modelfile);

			// ... do 30 runs (or just 10 for now)
			for (int i = 0; i < 30; i++) {

				System.out.println("RUN " + i + " STARTED!");

				// set up the parameters
				ArrayList<String> params = new ArrayList<String>();
				params.add("-file");
				params.add("params/fme_random.params");
				params.add("-p");
				params.add("generations=10000");
				params.add("-p");
				params.add("at.jku.isse.fm.fmfile=../" + modelfile.toString()); // input file
				params.add("-p");
				params.add("at.jku.isse.fm.fmfiletype=SPLOT");
				// ctc percentages
				params.add("-p");
				params.add("at.jku.isse.fm.mutate.ctcpercentage=0.5");
				params.add("-p");
				params.add("at.jku.isse.fm.builder.ctcpercentage=0.5");

				// set output file
				String outputfoldername = "output/RS/" + modelname + "/";
				File outputfolder = new File(outputfoldername);
				outputfolder.mkdirs();
				File outputfilemin = new File(outputfolder, i + ".min.stat");
				params.add("-p");
				params.add("stat.file=$" + outputfilemin.toString());

				// set up the command to execute
				List<String> command = new ArrayList<String>();
				command.add("java");
				command.add("-Xmx6g");
				command.add("-classpath");
				StringBuilder classpathstring = new StringBuilder();
				for (String s : classpathentries) {
					classpathstring.append(s + ":"); // TODO: for LINUX use ":" and for WINDOWS use ";"
				}
				// System.out.println("CLASSPATH: " + classpathstring.toString());
				command.add(classpathstring.toString());
				command.add("ec.Evolve");
				for (String s : params) {
					command.add(s);
				}

				ProcessBuilder pb = new ProcessBuilder(command);
				pb.directory(new File("./"));
				pb.inheritIO();

				Process p = pb.start();

				p.waitFor();

				System.out.println("EXIT VALUE: " + p.exitValue());

				System.out.println("RUN " + i + " DONE!");

			}

		}

		System.out.println("BATCH RUN DONE!");

	}

}
