package batch;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Batch {

	private static final int OFFSET = 0;

	public static void main(String[] args) throws IOException, InterruptedException {

		// do preparations
		String[] classpathentries = new String[] { ".", "bin/", "lib/*",
				"lib/ecj/*", "lib/fama/*", "lib/fama/JavaBDD/*",
				"lib/fama/Sat4j/*" };

		System.out.println("GP BATCH RUN STARTED!");

		// for every feature model ...
		File modelfolder = new File("new_models/");
		String[] modelnames = modelfolder.list();
		System.out.println("Models: ");
		for (String s : modelnames) {
			System.out.println(s);
		}
		System.out.println("-----------");

		for (int j = 0; j < modelnames.length; j++) {

			String modelname = modelnames[j];

			if (modelname.startsWith("."))
				continue;

			File modelfile = new File(modelfolder, modelname);

			System.out.println("Feature Model: " + modelfile);
			//System.exit(0);

			// ... do 30 runs (or just 10 for now)
			for (int i = 0 + OFFSET; i < 30 + OFFSET; i++) {

				System.out.println("RUN " + i + " STARTED!");

				// set up the parameters
				ArrayList<String> params = new ArrayList<String>();
				params.add("-file");
				params.add("params/fme_genetic.params");
				params.add("-p");
				params.add("generations=100");
				params.add("-p");
				params.add("at.jku.isse.fm.fmfile=../" + modelfile.toString()); // input
																				// file
				params.add("-p");
				params.add("at.jku.isse.fm.fmfiletype=SPLOT");
				// mutation probabilities
				params.add("-p");
				params.add("at.jku.isse.fm.mutate.ctcprob=0.5");
				params.add("-p");
				params.add("at.jku.isse.fm.mutate.treeprob=0.5");
				// ctc percentages
				params.add("-p");
				params.add("at.jku.isse.fm.mutate.ctcpercentage=0.5");
				params.add("-p");
				params.add("at.jku.isse.fm.builder.ctcpercentage=0.1");

				// set output file
				String outputfoldername = "output/GP/" + modelname + "/";
				File outputfolder = new File(outputfoldername);
				outputfolder.mkdirs();
				File outputfiletab = new File(outputfolder, i + ".tab.stat");
				File outputfiledetail = new File(outputfolder, i + ".detail.stat");
				File outputfilemin = new File(outputfolder, i + ".min.stat");
				File outputfilemeasures = new File(outputfolder, i + ".measures.stat");
				File outputfilevariables = new File(outputfolder, i + ".variables.stat");
				File outputfileobjectives = new File(outputfolder, i + ".objectives.stat");
				File outputEDmetric = new File(outputfolder, "edMetric.stat");
				params.add("-p");
				params.add("stat.file=$" + outputfiletab.toString());
				params.add("-p");
				params.add("stat.child.0.file=$" + outputfiledetail.toString());
				params.add("-p");
				params.add("stat.child.1.file=$" + outputfilemin.toString());
//				params.add("-p");
//				params.add("stat.child.2.front=$" + outputfilemeasures.toString());
//				params.add("-p");
//				params.add("stat.child.2.edFile=$" + outputEDmetric.toString());
//				params.add("-p");
//				params.add("stat.child.3.front=$" + outputfilevariables.toString());
//				params.add("-p");
//				params.add("stat.child.4.file=$" + outputfileobjectives.toString());

				// set up the command to execute
				List<String> command = new ArrayList<String>();
				command.add("java");
				command.add("-Xmx6g");
				command.add("-classpath");
				StringBuilder classpathstring = new StringBuilder();
				for (String s : classpathentries) {
					classpathstring.append(s + ";"); // TODO: for LINUX use ":" and for WINDOWS use ";"
				}
				// System.out.println("CLASSPATH: " +
				// classpathstring.toString());
				command.add(classpathstring.toString());
				command.add("ec.Evolve");
				for (String s : params) {
					command.add(s);
				}
				
				//-----------------------------------------------------------------------
				//System.out.println(command);
				//System.exit(0);
				//-----------------------------------------------------------------------
				
				ProcessBuilder pb = new ProcessBuilder(command);
				pb.directory(new File("./"));
				pb.inheritIO();

				Process p = pb.start();

				p.waitFor();

				System.out.println("EXIT VALUE: " + p.exitValue());

				System.out.println("RUN " + i + " DONE!");

			}

		}

		System.out.println("BATCH RUN DONE!");

	}

}
