package concatenator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

import es.us.isa.FAMA.Reasoner.Reasoner;
import es.us.isa.FAMA.Reasoner.questions.ProductsQuestion;
import es.us.isa.FAMA.models.FAMAfeatureModel.FAMAFeatureModel;
import es.us.isa.FAMA.models.FAMAfeatureModel.fileformats.SPLXReader;
import es.us.isa.JavaBDDReasoner.JavaBDDReasoner;
import es.us.isa.JavaBDDReasoner.questions.JavaBDDProductsQuestion;

/**
 * This class concatenates all the ECJ statistics output files in such a way that they can easily be processed by R. E.g. one file with all final individuals' data (from my own
 * statistics object) (one per line and with the name of the model as the first column from the folder name and the number of CTCs and the number of products).
 */
public class TabConcatenator {

	/*
	 * output:
	 * 
	 * - one file with ALL the generations, one generation per line, prefixed with fmname, number of CTCs and number of products.
	 */

	public static void main(String[] args) throws Exception {

		File concatenatedoutputfolder = new File("concatenated/GP/tab/");

		File fmfilesfolder = new File("fmfiles/");

		File ecjoutputfolder = new File("output/GP/");

		File[] fmoutputfolders = ecjoutputfolder.listFiles();

		StringBuffer allfmoutputbuffer = new StringBuffer();
		// StringBuffer averageallfmoutputbuffer = new StringBuffer();
		allfmoutputbuffer
				.append("origNumFeatures	origNumProducts	origNumCTCs	fmname	generation	build_or_breed_time	eval_time	avg_ind_size_in_gen	avg_ind_size_in_run	best_ind_size_in_gen	best_ind_size_in_run	mean_fitness_in_gen	best_fitness_in_gen	best_fitness_in_run\n");

		for (File fmoutputfolder : fmoutputfolders) {

			if (fmoutputfolder.getName().startsWith("."))
				continue;

			System.out.println(fmoutputfolder.getName());

			if (fmoutputfolder.isDirectory()) {
				String fmname = fmoutputfolder.getName();

				System.out.println("FM: " + fmname);

				// ###### GET INFORMATION ABOUT THE FEATURE MODEL WITH FAMA #####
				File fmfile = new File(fmfilesfolder, fmname);

				if (!fmfile.exists())
					continue;

				// XMLReader reader = new XMLReader();
				SPLXReader reader = new SPLXReader();
				FAMAFeatureModel famamodel = (FAMAFeatureModel) reader.parseFile(fmfile.getAbsolutePath());

				int numCTCs = famamodel.getNumberOfDependencies();
				int numFeatures = famamodel.getFeaturesNumber();

				ProductsQuestion products_question = new JavaBDDProductsQuestion();
				Reasoner reasoner = new JavaBDDReasoner();
				famamodel.transformTo(reasoner);
				reasoner.ask(products_question);

				long numProducts = products_question.getNumberOfProducts();

				System.out.println("numCTCs: " + numCTCs + ", numFeatures: " + numFeatures + ", numProducts: " + numProducts);
				// ##############################################################

				{
					// create the second file
					File[] fmoutputfiles = fmoutputfolder.listFiles();

					for (File fmoutputfile : fmoutputfiles) {
						if (fmoutputfile.getName().endsWith(".tab.stat")) {
							BufferedReader br = new BufferedReader(new FileReader(fmoutputfile));
							String line = br.readLine();
							int line_count = 0;
							while (line != null) {
								allfmoutputbuffer.append(numFeatures + "\t" + numProducts + "\t" + numCTCs + "\t" + fmname + "\t");
								allfmoutputbuffer.append(line);
								allfmoutputbuffer.append("\n");
								line = br.readLine();
								line_count++;
							}
							if (line_count != 100) {
								System.out.println("ERROR: line_count != 100");
							}
							br.close();
						}
					}
				}

			}
		}

		File myallfmoutputfile = new File(concatenatedoutputfolder, "ALLtab.stat");
		PrintWriter myallfmoutputfilewriter = new PrintWriter(myallfmoutputfile);
		myallfmoutputfilewriter.println(allfmoutputbuffer.toString());
		myallfmoutputfilewriter.close();

	}

}
