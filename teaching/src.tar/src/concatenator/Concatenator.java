package concatenator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

import es.us.isa.FAMA.Reasoner.Reasoner;
import es.us.isa.FAMA.Reasoner.questions.ProductsQuestion;
import es.us.isa.FAMA.models.FAMAfeatureModel.FAMAFeatureModel;
import es.us.isa.FAMA.models.FAMAfeatureModel.fileformats.SPLXReader;
import es.us.isa.JavaBDDReasoner.JavaBDDReasoner;
import es.us.isa.JavaBDDReasoner.questions.JavaBDDProductsQuestion;

/**
 * This class concatenates all the ECJ statistics output files in such a way that they can easily be processed by R. E.g. one file with all final individuals' data (from my own
 * statistics object) (one per line and with the name of the model as the first column from the folder name and the number of CTCs and the number of products).
 */
public class Concatenator {

	/*
	 * output:
	 * 
	 * - one file for every feature model with all the runs, one run per line
	 * 
	 * - one file with ALL the runs, one run per line, prefixed with fmname, number of CTCs and number of products.
	 */

	public static void main(String[] args) throws Exception {

		File concatenatedoutputfolder = new File("concatenated/GP/");
		// File concatenatedoutputfolder = new File("concatenated/RS/");

		File fmfilesfolder = new File("new_models/");

		File ecjoutputfolder = new File("output/GP/");
		// File ecjoutputfolder = new File("output/RS/");

		File[] fmoutputfolders = ecjoutputfolder.listFiles();

		StringBuffer allfmoutputbuffer = new StringBuffer();
		// StringBuffer averageallfmoutputbuffer = new StringBuffer();
		allfmoutputbuffer
				.append("origNumFeatures	origNumProducts	origNumCTCs	fmname	generation	generation_with_best	fitness	precision	recall	conformance	ed	numberOfCTCs	numberOfProducts	numberOfFeatures	numberOfContainedProducts	sizeDiff	surplus	f1	f2	relaxed	strict\n");

		for (File fmoutputfolder : fmoutputfolders) {

			if (fmoutputfolder.getName().startsWith("."))
				continue;

			System.out.println(fmoutputfolder.getName());

			if (fmoutputfolder.isDirectory()) {
				String fmname = fmoutputfolder.getName();

				System.out.println("FM: " + fmname);

				// ###### GET INFORMATION ABOUT THE FEATURE MODEL WITH FAMA #####
				File fmfile = new File(fmfilesfolder, fmname);

				if (!fmfile.exists())
					continue;

				// XMLReader reader = new XMLReader();
				SPLXReader reader = new SPLXReader();
				FAMAFeatureModel famamodel = (FAMAFeatureModel) reader.parseFile(fmfile.getAbsolutePath());

				int numCTCs = famamodel.getNumberOfDependencies();
				int numFeatures = famamodel.getFeaturesNumber();

				ProductsQuestion products_question = new JavaBDDProductsQuestion();
				Reasoner reasoner = new JavaBDDReasoner();
				famamodel.transformTo(reasoner);
				reasoner.ask(products_question);

				long numProducts = products_question.getNumberOfProducts();

				System.out.println("numCTCs: " + numCTCs + ", numFeatures: " + numFeatures + ", numProducts: " + numProducts);
				// ##############################################################

				{
					// create the first files with all the runs of the fm concatenated. name the file after the feature model but with .stat ending
					File[] fmoutputfiles = fmoutputfolder.listFiles();
					StringBuffer fmoutputbuffer = new StringBuffer();
					fmoutputbuffer
							.append("origNumFeatures	origNumProducts	origNumCTCs	fmname	generation	generation_with_best	fitness	precision	recall	conformance	ed	numberOfCTCs	numberOfProducts	numberOfFeatures	numberOfContainedProducts	sizeDiff	surplus	f1	f2	relaxed	strict\n");
					for (File fmoutputfile : fmoutputfiles) {
						if (fmoutputfile.getName().endsWith(".min.stat")) { // only use the minimal output files
							BufferedReader br = new BufferedReader(new FileReader(fmoutputfile));
							String line = br.readLine();
							int line_count = 0;
							while (line != null) {
								fmoutputbuffer.append(numFeatures + "\t" + numProducts + "\t" + numCTCs + "\t" + fmname + "\t");
								fmoutputbuffer.append(line);
								fmoutputbuffer.append("\n");
								line = br.readLine();
								line_count++;
							}
							if (line_count != 1) {
								System.out.println("ERROR: exactly one line should have been there!");
							}
							br.close();
						}
					}

					File myfmoutputfile = new File(concatenatedoutputfolder, fmname + ".stat");
					PrintWriter myfmoutputfilewriter = new PrintWriter(myfmoutputfile);
					myfmoutputfilewriter.println(fmoutputbuffer.toString());
					myfmoutputfilewriter.close();
				}

				{
					// create the second file
					File[] fmoutputfiles = fmoutputfolder.listFiles();

					for (File fmoutputfile : fmoutputfiles) {
						if (fmoutputfile.getName().endsWith(".min.stat")) { // only use the minimal output files
							BufferedReader br = new BufferedReader(new FileReader(fmoutputfile));
							String line = br.readLine();
							int line_count = 0;
							while (line != null) {
								allfmoutputbuffer.append(numFeatures + "\t" + numProducts + "\t" + numCTCs + "\t" + fmname + "\t");
								allfmoutputbuffer.append(line);
								allfmoutputbuffer.append("\n");
								line = br.readLine();
								line_count++;
							}
							if (line_count != 1) {
								System.out.println("ERROR: exactly one line should have been there!");
							}
							br.close();
						}
					}
				}

			}
		}

		File myallfmoutputfile = new File(concatenatedoutputfolder, "ALL.stat");
		PrintWriter myallfmoutputfilewriter = new PrintWriter(myallfmoutputfile);
		myallfmoutputfilewriter.println(allfmoutputbuffer.toString());
		myallfmoutputfilewriter.close();

	}

}
