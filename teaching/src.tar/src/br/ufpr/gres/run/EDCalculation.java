package br.ufpr.gres.run;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.StringTokenizer;

/**
 * This class concatenates all the ECJ statistics output files in such a way that they can easily be processed by R. E.g. one file with all final individuals' data (from my own
 * statistics object) (one per line and with the name of the model as the first column from the folder name and the number of CTCs and the number of products).
 */
public class EDCalculation {

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	public static void main(String[] args) throws Exception {

		File outputfolder = new File("output/indicators/");
		File ecjoutputfolder = null;
		File[] fmoutputfolders = null;
		
		
		// Preparing the file to calculate HV of NSGAII_2obj and NSGAII_3obj
//		String configuration_HV[] = {"NSGAII_2obj", "NSGAII_3obj"};
//		
//		for (String configuration : configuration_HV) {
//			ecjoutputfolder = new File("output/" + configuration + "/");
//			fmoutputfolders = ecjoutputfolder.listFiles();
//	
//			for (File fmoutputfolder : fmoutputfolders) {
//	
//				if (fmoutputfolder.getName().startsWith("."))
//					continue;
//	
//				if (fmoutputfolder.isDirectory()) {
//					String fmname = fmoutputfolder.getName();
//					
//	
//					System.out.println("\nFolder: " + fmname);
//	
//					File[] fmoutputfiles;
//					
//					fmoutputfiles = fmoutputfolder.listFiles();
//					Arrays.sort(fmoutputfiles, new Comparator<File>(){
//					    public int compare(File f1, File f2){
//					        return Long.valueOf(f1.lastModified()).compareTo(f2.lastModified());
//					    }});
//					
//					StringBuffer fmoutputbuffer = new StringBuffer();
//					
//					for (File fmoutputfile : fmoutputfiles) {
//						if (fmoutputfile.getName().endsWith(".measures.stat")) {
//							System.out.println(fmoutputfile);
//							
//						    if (fmoutputbuffer.length() != 0) {
//						    	fmoutputbuffer.append("#\n");
//						    }
//							
//							double front[][] = readFront(fmoutputfile.toString());
//							for(String line: Files.readAllLines(fmoutputfile.toPath())){
//								//System.out.println(" " + line);
//								fmoutputbuffer.append(line + "\n");
//							}
//							System.out.println("Number of solutions: " + front.length);
//	
//						}
//					}
//	
//					File myfmoutputfile = new File(outputfolder, configuration + "." + fmname + ".hv.dat");
//					PrintWriter myfmoutputfilewriter = new PrintWriter(myfmoutputfile);
//					myfmoutputfilewriter.println(fmoutputbuffer.toString());
//					myfmoutputfilewriter.close();
//	
//				}
//			}
//			
//			
//		}

		
		// Preparing the file to calculate ED of NSGAII_2obj and NSGAII_3obj
		String configuration_ED[] = {"NSGAII_2obj", "NSGAII_3obj"};
		double reference[] = {1.0, 1.0, 1.0};
		
		for (String configuration : configuration_ED) {
			ecjoutputfolder = new File("output/" + configuration + "/");
			fmoutputfolders = ecjoutputfolder.listFiles();
	
			for (File fmoutputfolder : fmoutputfolders) {
	
				if (fmoutputfolder.getName().startsWith("."))
					continue;
	
				if (fmoutputfolder.isDirectory()) {
					String fmname = fmoutputfolder.getName();
					
	
					System.out.println("\nFolder: " + fmname);
	
					File[] fmoutputfiles;
					
					fmoutputfiles = fmoutputfolder.listFiles();
					Arrays.sort(fmoutputfiles, new Comparator<File>(){
					    public int compare(File f1, File f2){
					        return Long.valueOf(f1.lastModified()).compareTo(f2.lastModified());
					    }});
					
					StringBuffer fmoutputbuffer = new StringBuffer();
					
					for (File fmoutputfile : fmoutputfiles) {
						if (fmoutputfile.getName().endsWith(".measures.stat")) {
							System.out.println(fmoutputfile);
						    
						    double front[][] = readFront(fmoutputfile.toString());
							double lowestED = Double.MAX_VALUE;
							double precision = Double.MAX_VALUE;
							double recall = Double.MAX_VALUE;
							
							for (double[] solution : front) {
								double euclidean_distance = distance(solution, reference);
								if(euclidean_distance < lowestED){
									lowestED = euclidean_distance;
									precision = solution[0];
									recall = solution[1];
								}
							}
	
						    if (fmoutputbuffer.length() != 0) {
						    	fmoutputbuffer.append("\n");
						    }
							//System.out.println(" " + line);
							System.out.println(" " + precision + " " + recall + " : " + lowestED);
							fmoutputbuffer.append(precision + " " + recall + " : " + lowestED);
						    
							System.out.println("Number of solutions: " + front.length);
	
						}
					}
	
					File myfmoutputfile = new File(outputfolder, configuration + "." + fmname + ".ed.dat");
					PrintWriter myfmoutputfilewriter = new PrintWriter(myfmoutputfile);
					myfmoutputfilewriter.println(fmoutputbuffer.toString());
					myfmoutputfilewriter.close();
	
				}
			}
			
			
		}
		
		
		// Preparing the file to calculate ED of GP_1obj and NSGAII_2obj
		
//		String configuration_ED = "GP_1obj";
//		ecjoutputfolder = new File("output/" + configuration_ED + "/");
//		fmoutputfolders = ecjoutputfolder.listFiles();
//		double reference[] = {1.0, 1.0};
//
//		for (File fmoutputfolder : fmoutputfolders) {
//
//			if (fmoutputfolder.getName().startsWith("."))
//				continue;
//
//			if (fmoutputfolder.isDirectory()) {
//				if (!fmoutputfolder.getName().endsWith(".xml"))
//					continue;
//				
//				String fmname = fmoutputfolder.getName();
//				System.out.println("\nFolder: " + fmname);
//
//				File[] fmoutputfiles = fmoutputfolder.listFiles();
//				Arrays.sort(fmoutputfiles, new Comparator<File>(){
//				    public int compare(File f1, File f2){
//				        return Long.valueOf(f1.lastModified()).compareTo(f2.lastModified());
//				    }});
//				
//				StringBuffer fmoutputbuffer = new StringBuffer();
//				
//				for (File fmoutputfile : fmoutputfiles) {
//					if (fmoutputfile.getName().endsWith(".min.stat")) {
//						//System.out.println(fmoutputfile);
//
//						for(String line: Files.readAllLines(fmoutputfile.toPath())){
//							String parts[] = line.split("\t");
//							double precision = Double.parseDouble(parts[3]);
//							double recall = Double.parseDouble(parts[4]);
//							double objectives[] = {precision, recall};
//							double euclidean_distance = distance(objectives, reference);
//							
//						    if (fmoutputbuffer.length() != 0) {
//						    	fmoutputbuffer.append("\n");
//						    }
//							//System.out.println(" " + line);
//							System.out.println(" " + precision + " " + recall + " : " + euclidean_distance);
//							fmoutputbuffer.append(precision + " " + recall + " : " + euclidean_distance);
//						}
//
//					}
//				}
//
//				File myfmoutputfile = new File(outputfolder, configuration_ED + "." + fmname + ".ed.dat");
//				PrintWriter myfmoutputfilewriter = new PrintWriter(myfmoutputfile);
//				myfmoutputfilewriter.println(fmoutputbuffer.toString());
//				myfmoutputfilewriter.close();
//			}
//		}		
		
//		String configuration_ED = "NSGAII_2obj";
//		ecjoutputfolder = new File("output/" + configuration_ED + "/");
//		fmoutputfolders = ecjoutputfolder.listFiles();
//
//		for (File fmoutputfolder : fmoutputfolders) {
//
//			if (fmoutputfolder.getName().startsWith("."))
//				continue;
//
//			if (fmoutputfolder.isDirectory()) {
//				if (!fmoutputfolder.getName().endsWith(".xml"))
//					continue;
//				
//				String fmname = fmoutputfolder.getName();
//				System.out.println("\nFolder: " + fmname);
//
//				File[] fmoutputfiles = fmoutputfolder.listFiles();
//				Arrays.sort(fmoutputfiles, new Comparator<File>(){
//				    public int compare(File f1, File f2){
//				        return Long.valueOf(f1.lastModified()).compareTo(f2.lastModified());
//				    }});
//				
//				StringBuffer fmoutputbuffer = new StringBuffer();
//				
//				for (File fmoutputfile : fmoutputfiles) {
//					if (fmoutputfile.getName().endsWith(".objectives.stat")) {
//						System.out.println(fmoutputfile);
//						
//						double front[][] = readFront(fmoutputfile.toString());
//						double lowestED = Double.MAX_VALUE;
//						double precision = Double.MAX_VALUE;
//						double recall = Double.MAX_VALUE;
//						
//						for (double[] solution : front) {
//							double euclidean_distance = distance(solution, reference);
//							if(euclidean_distance < lowestED){
//								lowestED = euclidean_distance;
//								precision = solution[0];
//								recall = solution[1];
//							}
//						}
//
//					    if (fmoutputbuffer.length() != 0) {
//					    	fmoutputbuffer.append("\n");
//					    }
//						//System.out.println(" " + line);
//						System.out.println(" " + precision + " " + recall + " : " + lowestED);
//						fmoutputbuffer.append(precision + " " + recall + " : " + lowestED);
//						
//
//					}
//				}
//
//				File myfmoutputfile = new File(outputfolder, configuration_ED + "." + fmname + ".ed.dat");
//				PrintWriter myfmoutputfilewriter = new PrintWriter(myfmoutputfile);
//				myfmoutputfilewriter.println(fmoutputbuffer.toString());
//				myfmoutputfilewriter.close();
//			}
//		}
		
		
		
	}

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	public static double[][] readFront(String path) {
		try {
			// Open the file
			FileInputStream fis = new FileInputStream(path);
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);

			List<double[]> list = new ArrayList<double[]>();
			int numberOfObjectives = 0;
			String aux = br.readLine();
			while (aux != null) {
				StringTokenizer st = new StringTokenizer(aux);
				int i = 0;
				numberOfObjectives = st.countTokens();
				double[] vector = new double[st.countTokens()];
				while (st.hasMoreTokens()) {
					double value = new Double(st.nextToken());
					vector[i] = value;
					i++;
				}
				list.add(vector);
				aux = br.readLine();
			}

			br.close();

			double[][] front = new double[list.size()][numberOfObjectives];
			for (int i = 0; i < list.size(); i++) {
				front[i] = list.get(i);
			}
			return front;

		} catch (Exception e) {
			System.out.println("InputFacilities crashed reading for file: "
					+ path);
			e.printStackTrace();
		}
		return null;
	}

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
	public static double distance(double[] a, double[] b) {
		double distance = 0.0;

		for (int i = 0; i < a.length; i++) {
			distance += Math.pow(a[i] - b[i], 2.0);
		}
		return Math.sqrt(distance);
	}

	// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
}
