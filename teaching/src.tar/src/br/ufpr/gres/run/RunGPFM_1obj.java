package br.ufpr.gres.run;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import br.ufpr.gres.fm.FMFitness;
import ec.EvolutionState;
import ec.Evolve;
import ec.Individual;
import ec.util.ParameterDatabase;

public class RunGPFM_1obj {
	
	public static void main(String[] args) throws IOException, InterruptedException  {
		
		File modelfolder = new File("new_models/");
		String[] modelnames = modelfolder.list();
		System.out.println("Models: ");
		for (String s : modelnames) {
			System.out.println(s);
		}
//		String[] modelnames = {"gol_full.xml"};
		
		for (int j = 0; j < modelnames.length; j++) {
	
			String modelname = modelnames[j];
	
			if (modelname.startsWith("."))
				continue;
	
			File modelfile = new File(modelfolder, modelname);
			System.out.println("Feature Model: " + modelfile);
	
			// ... do 30 runs (or just 10 for now)
			for (int i = 0; i < 30; i++) {
				
				int numJobs = 1;
				
				// set output file
				File outputfolder = new File("output/GP_1obj/" + modelname + "/");
				outputfolder.mkdirs();
				File outputfiletab = new File(outputfolder, i + ".tab.stat");
				File outputfiledetail = new File(outputfolder, i + ".detail.stat");
				File outputfilemin = new File(outputfolder, i + ".min.stat");
				File outputfilemeasures = new File(outputfolder, i + ".measures.stat");
				File outputfilevariables = new File(outputfolder, i + ".variables.stat");
				File outputfileobjectives = new File(outputfolder, i + ".objectives.stat");
				File outputEDmetric = new File(outputfolder, "edMetric.stat");
				
				String[] arguments = new String[] { 
						"-file", "params/fme_genetic.params",
						"-p", "generations=1000",
						//"-p", "pop.subpop.0.size=100",
						"-p", "at.jku.isse.fm.fmfile=../" + modelfile.toString(),
						"-p", "at.jku.isse.fm.fmfiletype=SPLOT",
						// mutation probabilities
						"-p", "at.jku.isse.fm.mutate.ctcprob=0.5",
						"-p", "at.jku.isse.fm.mutate.treeprob=0.5",
						// ctc percentages
						"-p", "at.jku.isse.fm.mutate.ctcpercentage=0.5",
						"-p", "at.jku.isse.fm.builder.ctcpercentage=0.1",
						//output files
						//"-p", "stat.file=$" + outputfiletab.toString(),
						"-p", "stat.file=$" + outputfiletab.toString(),
						"-p", "stat.child.0.file=$" + outputfiledetail.toString(),
						"-p", "stat.child.1.file=$" + outputfilemin.toString()
						};
				
		        EvolutionState state;
		        ParameterDatabase parameters;
		                
		        for(int job = 0 ; job < numJobs; job++){
		            parameters = Evolve.loadParameterDatabase(arguments);
		                        
		            // Initialize the EvolutionState, then set its job variables
		            state = Evolve.initialize(parameters, job);         // pass in job# as the seed increment
		            state.output.systemMessage("Job: " + job);
		            state.job = new Object[1];                          // make the job argument storage
		            state.job[0] = Integer.valueOf(job);                // stick the current job in our job storage
		            state.runtimeArguments = arguments;                 // stick the runtime arguments in our storage
		            if (numJobs > 1){                                   // only if iterating (so we can be backwards-compatible),
		                String jobFilePrefix = "job." + job + ".";
		                state.output.setFilePrefix(jobFilePrefix);      // add a prefix for checkpoint/output files 
		                state.checkpointPrefix = jobFilePrefix + state.checkpointPrefix;  // also set up checkpoint prefix
		            }
		            state.run(EvolutionState.C_STARTED_FRESH);
		            
		            //--------------------------------------------------------------------------------------------------
	                //mostra membros da populacao
//		            System.out.println("\n\n-------------------------------------");
//		            System.out.println("Show non-dominated Population");
//
//					ArrayList<Individual> inds = FMFitness.partitionIntoParetoFront(state.population.subpops[0].individuals, null, null);
//					System.out.println("Number of solutions: " + inds.size());
					
//					for (Individual individual : inds) {
//						System.out.println("-------------------------------------");
//						individual.printIndividualForHumans(state, 0);
//					}
					
					//state.population.printPopulationForHumans(state, 0);					
//					for (int x = 0; x < state.population.subpops[0].individuals.length; x++) {
//						Individual ind = state.population.subpops[0].individuals[x];
//						double[] fitnes = ((FeatureModelFitness) ind.fitness).getObjectives();
//						System.out.println("Individual" + j + ": " + fitnes[0] + "-" + fitnes[0]);
//					}
	              //--------------------------------------------------------------------------------------------------
		            
		            Evolve.cleanup(state);  // flush and close various streams, print out parameters if necessary
		            parameters = null;      // so we load a fresh database next time around
		        }
			}
		}
	}
	
}
