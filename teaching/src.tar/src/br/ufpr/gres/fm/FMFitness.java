package br.ufpr.gres.fm;

import ec.multiobjective.nsga2.NSGA2MultiObjectiveFitness;

public class FMFitness extends NSGA2MultiObjectiveFitness {

	private static final long serialVersionUID = 1L;

	private double precision;
	private double recall;
	private double conformance;

	private int numberOfCTCs;
	private int numberOfProducts;
	private int numberOfFeatures;
	private int numberOfContainedProducts;
	private int sizeDiff;
	private int surplus;

	private float f1;
	private float f2;
	private int relaxed;
	private int strict;

	@Override
	public boolean isIdealFitness() {
		double sum = 0.0;
		
		double[] objectives = this.getObjectives();
		for (int i = 0; i < objectives.length; i++) {
			sum += objectives[i];
		}
		
		if ( (sum/objectives.length) >= 1.0 )
			return true;
		else
			return false;
	}

	@Override
	public String toString() {
		return "Fitness: " + this.fitness() + ", NumberOfCTCs: " + this.numberOfCTCs + ", NumberOfProducts: " + this.numberOfProducts;
	}

	@Override
	public String fitnessToString() {
		return this.fitness() + "\t" + this.precision + "\t" + this.recall + "\t" + this.numberOfCTCs + "\t" + this.numberOfProducts + "\t" + this.numberOfFeatures + "\t"
				+ this.numberOfContainedProducts + "\t" + this.sizeDiff + "\t" + this.surplus + "\t" + this.f1 + "\t" + this.f2 + "\t" + this.relaxed + "\t" + this.strict;
	}

	public void setRecall(double recall) {
		if (recall >= 0.0 && recall <= 1.0) {
			this.recall = recall;
		} else {
			System.out.println("[FME] Invalid recall: " + recall);
		}
	}

	public double getRecall() {
		return this.recall;
	}

	public void setPrecision(double precision) {
		if (precision >= 0.0 && precision <= 1.0) {
			this.precision = precision;
		} else {
			System.out.println("[FME] Invalid precision: " + precision);
		}
	}

	public double getPrecision() {
		return this.precision;
	}
	
	public void setConformance(double conformance) {
		if (conformance >= 0.0 && conformance <= 1.0) {
			this.conformance = conformance;
		} else {
			System.out.println("[FME] Invalid conformance: " + conformance);
		}
	}

	public double getConformance() {
		return this.conformance;
	}

	public int getNumberOfCTCs() {
		return numberOfCTCs;
	}

	public void setNumberOfCTCs(int numberOfCTCs) {
		this.numberOfCTCs = numberOfCTCs;
	}

	public int getNumberOfProducts() {
		return numberOfProducts;
	}

	public void setNumberOfProducts(int numberOfProducts) {
		this.numberOfProducts = numberOfProducts;
	}

	public int getNumberOfFeatures() {
		return numberOfFeatures;
	}

	public void setNumberOfFeatures(int numberOfFeatures) {
		this.numberOfFeatures = numberOfFeatures;
	}

	public int getNumberOfContainedProducts() {
		return numberOfContainedProducts;
	}

	public void setNumberOfContainedProducts(int numberOfContainedProducts) {
		this.numberOfContainedProducts = numberOfContainedProducts;
	}

	public int getSizeDiff() {
		return sizeDiff;
	}

	public void setSizeDiff(int sizeDiff) {
		this.sizeDiff = sizeDiff;
	}

	public int getSurplus() {
		return surplus;
	}

	public void setSurplus(int surplus) {
		this.surplus = surplus;
	}

	public float getF1() {
		return f1;
	}

	public void setF1(float f1) {
		this.f1 = f1;
	}

	public float getF2() {
		return f2;
	}

	public void setF2(float f2) {
		this.f2 = f2;
	}

	public int getRelaxed() {
		return relaxed;
	}

	public void setRelaxed(int relaxed) {
		this.relaxed = relaxed;
	}

	public int getStrict() {
		return strict;
	}

	public void setStrict(int strict) {
		this.strict = strict;
	}

}
