package br.ufpr.gres.fm;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import at.jku.isse.fm.FMEDefaults;
import at.jku.isse.fm.FeatureModelExtractionInitializer;
import at.jku.isse.fm.data.Constraint;
import at.jku.isse.fm.data.ConstraintSet;
import at.jku.isse.fm.data.ProductSet;
import at.jku.isse.fm.dg.Dependency;
import at.jku.isse.fm.dg.DependencyGraph;
import at.jku.isse.fm.node.relation.Root;
import ec.EvolutionState;
import ec.Individual;
import ec.gp.GPData;
import ec.gp.GPIndividual;
import ec.gp.GPNode;
import ec.gp.GPProblem;
import ec.simple.SimpleProblemForm;
import ec.util.Parameter;
import es.us.isa.FAMA.Reasoner.Reasoner;
import es.us.isa.FAMA.Reasoner.questions.ProductsQuestion;
import es.us.isa.FAMA.models.FAMAfeatureModel.FAMAFeatureModel;
import es.us.isa.FAMA.models.FAMAfeatureModel.Feature;
import es.us.isa.FAMA.models.FAMAfeatureModel.fileformats.SPLXReader;
import es.us.isa.FAMA.models.FAMAfeatureModel.fileformats.XMLReader;
import es.us.isa.FAMA.models.featureModel.GenericFeature;
import es.us.isa.FAMA.models.featureModel.Product;
import es.us.isa.FAMA.models.variabilityModel.GenericProduct;
import es.us.isa.FAMA.models.variabilityModel.parsers.WrongFormatException;
import es.us.isa.JavaBDDReasoner.JavaBDDReasoner;
import es.us.isa.JavaBDDReasoner.questions.JavaBDDProductsQuestion;

public class FMExtractionProblem_2obj extends GPProblem implements SimpleProblemForm {
	private static final long serialVersionUID = 1;

	public ProductSet ps = null;
	public DependencyGraph fmDeps;

	@Override
	public Object clone() {
		this.evaluated_individuals = new ArrayList<Individual>();

		FMExtractionProblem_2obj prob = (FMExtractionProblem_2obj) (super.clone());

		System.out.println("[FME] FeatureModelExtractionProblem.clone()");

		// deep-clone the product set (this might not be necessary -> try and remove it if memory consumption is too high)
		prob.input = (GPData) (input.clone());

		prob.evaluated_individuals = new ArrayList<Individual>();

		return prob;
	}

	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);

		state.output.message("[FME] FeatureModelExtractionProblem.setup(): " + base);
		state.output.message("[FME] Using F1 as fitness!");

		Parameter def = FMEDefaults.base().push(P_PROBLEM);
		Parameter fmbase = FMEDefaults.base();

		// verify our input is the right class (or subclasses from it)
		if (!(this.input instanceof ProductSet))
			state.output.fatal("GPData class must subclass of " + ProductSet.class, base.push(P_DATA), null);

		// ProductSet ps = (ProductSet) this.input;
		this.ps = new ProductSet();

		// get parameter for feature model file
		File fmfile = state.parameters.getFile(base.push(FMEDefaults.P_FMFILE), fmbase.push(FMEDefaults.P_FMFILE));
		String fmfiletype = state.parameters.getString(base.push(FMEDefaults.P_FMFILETYPE), fmbase.push(FMEDefaults.P_FMFILETYPE));

		// read feature model file
		FAMAFeatureModel fama_model = null;
		try {
			if (fmfiletype.equals(FMEDefaults.SPLOT_FILETYPE)) {
				SPLXReader reader = new SPLXReader();
				fama_model = (FAMAFeatureModel) reader.parseFile(fmfile.getAbsolutePath());
			} else if (fmfiletype.equals(FMEDefaults.FAMA_FILETYPE)) {
				XMLReader reader = new XMLReader();
				fama_model = (FAMAFeatureModel) reader.parseFile(fmfile.getAbsolutePath());
			} else {
				state.output.fatal("[FME] Unknown feature model file type specified!");
			}
		} catch (WrongFormatException e) {
			state.output.fatal("The provided feature model file is in the wrong format!");
		} catch (Exception e) {
			state.output.fatal("Error reading the provided feature model file!");
		}

		// compute the products for the feature model and convert them to our data structure
		if (fama_model != null) {
			for (Feature fama_feature : fama_model.getFeatures()) {
				ps.features.add(new at.jku.isse.fm.data.Feature(fama_feature.getName().toLowerCase()));
			}
			state.output.message("Features: " + ps.features.toString());

			// TODO: make the solver a parameter
			ProductsQuestion products_question = new JavaBDDProductsQuestion();
			Reasoner reasoner = new JavaBDDReasoner();
			// ProductsQuestion products_question = new Sat4jProductsQuestion();
			// Reasoner reasoner = new Sat4jReasoner();
			fama_model.transformTo(reasoner);
			reasoner.ask(products_question);

			Collection<? extends GenericProduct> fama_products = (Collection<? extends GenericProduct>) products_question.getAllProducts();

			for (GenericProduct fama_generic_product : fama_products) {
				at.jku.isse.fm.data.Product product = new at.jku.isse.fm.data.Product();
				for (GenericFeature fama_generic_feature : ((Product) fama_generic_product).getFeatures()) {
					product.add(new at.jku.isse.fm.data.Feature(fama_generic_feature.getName().toLowerCase()));
				}
				ps.products.add(product);
				// state.output.message(product.toString());
			}
		}

		// deal with feature model dependencies
		this.fmDeps = new DependencyGraph();
		this.fmDeps.extractFMDependencies(fmfile.getAbsolutePath());

	}

	private List<Individual> evaluated_individuals = new ArrayList<Individual>();

	public void evaluate(final EvolutionState state, final Individual individual, final int subpopulation, final int threadnum) {

		boolean ind_already_contained = false;
		for (Individual temp_ind : evaluated_individuals)
			if (temp_ind == individual)
				ind_already_contained = true;
		if (ind_already_contained) {
			state.output
					.fatal("[FME] Error in evaluation: Individual was evaluated more than once! Was it part of the population multiple times? Number of evaluated Individuals: "
							+ evaluated_individuals.size());
		}
		evaluated_individuals.add(individual);

		if (!individual.evaluated) { // don't bother reevaluating
			ProductSet ps = new ProductSet();
			ConstraintSet cs = new ConstraintSet();

			FeatureModelExtractionInitializer initializer = (FeatureModelExtractionInitializer) state.initializer;

			((GPIndividual) individual).trees[0].child.eval(state, threadnum, ps, stack, ((GPIndividual) individual), this);

			if (ps.features.size() != initializer.ps.features.size() || !ps.features.containsAll(initializer.ps.features)) {
				state.output.fatal("[FME] Fatal error evaluating individual: the set of features in the individual is wrong! Number of Features in Individual: "
						+ ps.features.size() + "; Number of features in Initializer: " + initializer.ps.features.size());
			}

			((GPIndividual) individual).trees[1].child.eval(state, threadnum, cs, stack, ((GPIndividual) individual), this);

			// System.out.println("CTC-TREE-SIZE: " + FMUtils.treeSize(((GPIndividual) individual).trees[1].child) + "; " + ((GPIndividual) individual).trees[1].child);

			// System.out.println("Products before CTCs: " + ps.products.size());

			// TODO: remove this for performance: compares my evaluation results with the one from FAMA if available
			Root root = ((Root) ((GPIndividual) individual).trees[0].child);
			if (root.products.size() == ps.products.size() && ps.products.containsAll(root.products)) {
				// state.output.message("[FME-TEST] CORRECT");
			} else if (root.products.size() > 0) {
				// state.output.message("[FME-TEST] ERROR: " + root.products.size() + ";" + ps.products.size() + ";" + root.products + ";" + ps.products);
				state.output.message("[FME-TEST] HINT BEFORE: " + root.products.size() + ";" + ps.products.size());
				if (root.products.size() == ps.products.size()) {
					if (root.products.containsAll(ps.products)) {
						state.output.message("CORRECT!");
					}
				}
			}

			// deal with CTCs
			Iterator<at.jku.isse.fm.data.Product> it = ps.products.iterator();
			while (it.hasNext()) {
				at.jku.isse.fm.data.Product p = it.next();

				for (Constraint c : cs.constraints) {
					boolean satisfied = false;
					for (at.jku.isse.fm.data.Feature f : c.pos) {
						if (p.contains(f)) {
							satisfied = true;
							break;
						}
					}
					if (!satisfied) {
						for (at.jku.isse.fm.data.Feature f : c.neg) {
							if (!p.contains(f)) {
								satisfied = true;
								break;
							}
						}
					}
					if (!satisfied) {
						it.remove();
						break;
					}
				}

			}

			// for (Constraint c : cs.constraints) {
			// System.out.println("POS: " + c.pos + "; NEG: " + c.neg);
			// }

			// TODO: remove this for performance: compares my evaluation results with the one from FAMA if available
			root = ((Root) ((GPIndividual) individual).trees[0].child);
			if (root.products.size() == ps.products.size() && ps.products.containsAll(root.products)) {
				// state.output.message("[FME-TEST] CORRECT");
			} else if (root.products.size() > 0) {
				// state.output.message("[FME-TEST] ERROR: " + root.products.size() + ";" + ps.products.size() + ";" + root.products + ";" + ps.products);
				state.output.message("[FME-TEST] HINT AFTER: " + root.products.size() + ";" + ps.products.size());
				if (root.products.size() == ps.products.size()) {
					if (root.products.containsAll(ps.products)) {
						state.output.message("CORRECT!");
					}
				}
			}

			// TODO: make the concrete evaluation function (/objective function/fitness function) a parameter

			// ########################### COMPUTE METRICS and FITNESS ##############################

			int numContainedProducts = 0;
			for (at.jku.isse.fm.data.Product p : this.ps.products) {
				if (ps.products.contains(p))
					numContainedProducts++;
			}

			double conformance = 0.0;
			for (at.jku.isse.fm.data.Product p : ps.products) {
				for (Dependency dep : this.fmDeps.getDependencies()) {
					if (dep.holdsOn(p))
						conformance += dep.getWeight();
				}
			}
			conformance = conformance / ps.products.size();
			if (ps.products.size() == 0)
				conformance = 0.0;
			if (conformance > 1.0 && conformance < 1.000001)
				conformance = 1.0;

			int numProducts = this.ps.products.size();
			int numProductsFM = ps.products.size();
			float precision = ((float) numContainedProducts) / ((float) numProductsFM);
			float recall = ((float) numContainedProducts) / ((float) numProducts);
			float f2 = (5 * precision * recall) / (4 * precision + recall);
			float f1 = (2 * precision * recall) / (1 * precision + recall);

			if (numContainedProducts == 0) {
				f1 = 0;
				f2 = 0;
				precision = 0;
				recall = 0;
			}

			int relaxed = numContainedProducts;
			int strict = 0;
			if (numProductsFM == numProducts)
				strict = relaxed;

			// TODO: set fitness here!
			// fitness.setFitness(state, f2, false);
			// fitness.setFitness(state, f1, false);
			FMFitness fitness = ((FMFitness) individual.fitness);
			
			fitness.setPrecision(precision);
			fitness.setRecall(recall);
			fitness.setConformance(conformance);
			fitness.setNumberOfCTCs(cs.constraints.size());
			fitness.setNumberOfProducts(ps.products.size());
			fitness.setNumberOfFeatures(ps.features.size());
			fitness.setNumberOfContainedProducts(numContainedProducts);
			fitness.setSizeDiff(Math.abs(numProductsFM - numProducts));
			fitness.setSurplus(numProducts - numContainedProducts);
			fitness.setRelaxed(relaxed);
			fitness.setStrict(strict);
			fitness.setF1(f1);
			fitness.setF2(f2);
			
			double[] objectives = { precision, recall };
			((FMFitness) individual.fitness).setObjectives(state, objectives);
			individual.evaluated = true;

			// -------------------------------------------------------
			// GPIndividual gpInd = ((GPIndividual) individual);
			// double sumWeights = this.fmDeps.getSumOfWeights();
			// int numFeatures = initializer.ps.features.size();
			// double sumWeights = sumFMWeights(gpInd.trees[0].child);
			// int numFeatures = FMUtils.countFeatures( gpInd.trees[0].child );
			// double depFitness = sumWeights/(numFeatures-1); //Minus 1 because of one feature is the root
			// fitness.setConformance(depFitness);
			// System.out.println(sumWeights + " / " + numFeatures + " = " + depFitness);
			// gpInd.trees[0].printTreeForHumans(state, 0);
			// System.out.println(gpInd.trees[0].child.makeCTree(true, true, true));
			// System.exit(0);

		} else {
			//state.output.message("[FME] Individual already evaluated!");
		}
	}

}
