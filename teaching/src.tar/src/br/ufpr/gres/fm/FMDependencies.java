package br.ufpr.gres.fm;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class FMDependencies {
	
	Document dom;
	ArrayList<FMDependency> fmDependencies;
	
	private double sumOfWeights;
	
	public double getSumOfWeights() {
		return this.sumOfWeights;
	}
	
	public static void main(String[] args) {
		FMDependencies fmd = new FMDependencies();
		fmd.extractFMDependencies("fmfiles/DPL.xml");
		
		
		for (int i = 0; i < fmd.fmDependencies.size(); i++) {
			System.out.println(
					"Dependency: " + fmd.fmDependencies.get(i).from + 
					" --> " + fmd.fmDependencies.get(i).to + 
					" [" + fmd.fmDependencies.get(i).weight + "]" );
		}
		
		System.out.println( fmd.getFMDependencyWeight("Line", "Base") );
		System.out.println( fmd.getFMDependencyWeight("Line", "Color") );
	}
	
	
	public void extractFMDependencies(String xmlFile){
		this.fmDependencies = new ArrayList<FMDependency>();
		this.parseXmlFile(xmlFile);
		this.parseDocument();
	}
	
	public double getFMDependencyWeight(String from, String to){
		for (int i = 0; i < this.fmDependencies.size(); i++) {
			if(this.fmDependencies.get(i).from.equalsIgnoreCase(from) && this.fmDependencies.get(i).to.equalsIgnoreCase(to)){
				return this.fmDependencies.get(i).weight;
			}
		}
		return 0.0;
	}
	
	private void parseXmlFile(String xmlFile){
		try {
			//get the factory
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			
			//Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			//parse using builder to get DOM representation of the XML file
			dom = db.parse(xmlFile);
		}catch(ParserConfigurationException pce) {
			pce.printStackTrace();
		}catch(SAXException se) {
			se.printStackTrace();
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	
	private void parseDocument(){
		//get the root elememt
		Element docEle = dom.getDocumentElement();
		
		//get a nodelist of <employee> elements
		NodeList nl = docEle.getElementsByTagName("dependency");
		
		double sumOfWeights = 0.0;
		
		if(nl != null && nl.getLength() > 0) {
			for(int i = 0 ; i < nl.getLength();i++) {
				//get the dependency element
				Element el = (Element)nl.item(i);
				
				FMDependency fmdep = new FMDependency();
				fmdep.from = el.getAttribute("from");
				fmdep.to = el.getAttribute("to");
				fmdep.weight = Double.parseDouble(el.getAttribute("weight"));
				
				sumOfWeights++;
				
				this.fmDependencies.add(fmdep);
			}
			
			this.sumOfWeights = sumOfWeights;
		}
	}
	
	
	private String getTextValue(Element ele, String tagName) {
		String textVal = null;
		NodeList nl = ele.getElementsByTagName(tagName);
		if(nl != null && nl.getLength() > 0) {
			Element el = (Element)nl.item(0);
			textVal = el.getFirstChild().getNodeValue();
		}

		return textVal;
	}
	
}

//---------------------------------------------------------
class FMDependency {
	String from;
	String to;
	double weight;
	
	public FMDependency() {
		this.from = null;
		this.to = null;
		this.weight = 0.0;
	}
}