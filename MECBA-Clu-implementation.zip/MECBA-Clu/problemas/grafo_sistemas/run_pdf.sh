#!/bin/bash  

dot -Tpdf sccmap_OA_AJHotDraw.dot > sccmap_OA_AJHotDraw.pdf
dot -Tpdf sccmap_OA_AJHsqldb.dot > sccmap_OA_AJHsqldb.pdf
dot -Tpdf sccmap_OA_HealthWatcher.dot > sccmap_OA_HealthWatcher.pdf
dot -Tpdf sccmap_OA_TollSystems.dot > sccmap_OA_TollSystems.pdf
dot -Tpdf sccmap_OO_BCEL.dot > sccmap_OO_BCEL.pdf
dot -Tpdf sccmap_OO_JBoss.dot > sccmap_OO_JBoss.pdf
dot -Tpdf sccmap_OO_JHotDraw.dot > sccmap_OO_JHotDraw.pdf
dot -Tpdf sccmap_OO_MyBatis.dot > sccmap_OO_MyBatis.pdf
